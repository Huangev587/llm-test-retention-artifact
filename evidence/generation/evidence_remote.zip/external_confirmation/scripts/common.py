import hashlib
import json
import os
from pathlib import Path
import signal
import subprocess
import time
from config import ROOT, REMOTE, AUTHORIZED, JDK, ENTRY, SOURCE, CACHE, REPO, MODEL


def read(p):
    return json.loads(Path(p).read_text(encoding='utf-8'))


def digest(p):
    return hashlib.sha256(Path(p).read_bytes()).hexdigest()


def write(p, value):
    p = Path(p)
    p.parent.mkdir(parents=True, exist_ok=True)
    with p.open('x', encoding='utf-8', newline='\n') as f:
        json.dump(value, f, ensure_ascii=False, indent=2)
        f.write('\n')
        f.flush()
        os.fsync(f.fileno())


def remote_only():
    assert ROOT == REMOTE and ROOT.resolve(strict=True) == ROOT
    for p in (ROOT, JDK, ENTRY, SOURCE, CACHE, REPO, MODEL):
        assert p.resolve(strict=True) == p and p.is_relative_to(AUTHORIZED)


class Commands:
    def __init__(self, deadline):
        self.deadline = deadline
        self.records = []
        self.env = os.environ.copy()
        for key in ('PYTHONPATH', 'PYTHONHOME', 'CLASSPATH', 'JAVA_TOOL_OPTIONS', '_JAVA_OPTIONS', 'JDK_JAVA_OPTIONS', 'MAVEN_ARGS'):
            self.env.pop(key, None)
        self.env.update(JAVA_HOME=str(JDK), PATH=str(JDK / 'bin') + os.pathsep + self.env.get('PATH', ''),
                        HF_HUB_OFFLINE='1', TRANSFORMERS_OFFLINE='1', PYTHONDONTWRITEBYTECODE='1',
                        MAVEN_OPTS='-Xmx512m -Dfile.encoding=UTF-8')

    def run(self, out, label, cmd, *, cwd=ROOT, limit=45, required=False):
        out = Path(out)
        out.mkdir(parents=True, exist_ok=True)
        timeout = min(limit, self.deadline - time.time() - 2)
        if timeout <= 0:
            raise TimeoutError('Persistent batch deadline exhausted')
        tick = time.monotonic()
        with (out / (label + '.log')).open('xb') as log:
            p = subprocess.Popen(list(map(str, cmd)), cwd=cwd, env=self.env, stdout=log,
                                 stderr=subprocess.STDOUT, start_new_session=False)
            try:
                code = p.wait(timeout=timeout)
            except subprocess.TimeoutExpired:
                p.kill()
                p.wait(timeout=5)
                raise TimeoutError('Command timed out; supervising process will terminate its owned group: ' + label)
        row = dict(label=label, command=list(map(str, cmd)), seconds=time.monotonic() - tick, returncode=code)
        self.records.append(row)
        write(out / (label + '.json'), row)
        if required and code:
            raise RuntimeError('Infrastructure command failed: ' + str(out / (label + '.log')))
        return code, (out / (label + '.log')).read_text(encoding='utf-8', errors='replace')


def verify():
    frozen = read(ROOT / 'freeze.json')
    for relative, expected in frozen['files'].items():
        p = ROOT / relative
        assert p.resolve(strict=True) == p and p.is_relative_to(ROOT), relative
        assert digest(p) == expected, 'Frozen file changed: ' + relative
    identity = read(ENTRY_IDENTITY())
    from config import SOURCE, ENTRY
    assert digest(ENTRY / 'inputs/source.zip') == identity['archive_sha256']
    for relative, expected in identity['source_files'].items():
        path = SOURCE / relative
        assert path.resolve(strict=True) == path and path.is_relative_to(SOURCE), relative
        assert digest(path) == expected, relative
    return frozen


def ENTRY_IDENTITY():
    from config import ENTRY
    return ENTRY / 'evidence/source_identity.json'
