"""Offline Qwen backend and append-only, API-scoped generation budgets.

Only LocalModel construction imports the verified Paper model runtime. Importing
this module and exercising CallLedger requires the Python standard library only.
"""
import hashlib
import json
import math
import os
from pathlib import Path
import re
import time

ARMS = ('generic', 'execution', 'mutation')
SLOTS = ('seed',) + tuple(f'{arm}_{i}' for arm in ARMS for i in (1, 2))
MAX_INPUT_TOKENS = 8192
MAX_NEW_TOKENS = 2048
MAX_TOTAL_CALLS = 42
START_FREE_MIB = 21 * 1024
INFERENCE_FREE_MIB = 4 * 1024

def safe_directory(path):
    path = Path(path).absolute()
    if any(part.is_symlink() or (hasattr(part, 'is_junction') and part.is_junction())
           for part in (path, *path.parents)):
        raise ValueError('Evidence directory cannot traverse a symlink or junction')
    path.mkdir(parents=True, exist_ok=True)
    return path


def sync_directory(path):
    if os.name == 'posix':
        fd = os.open(path, os.O_RDONLY)
        try:
            os.fsync(fd)
        finally:
            os.close(fd)


def write_new(path, value):
    """Append-only evidence: existing results can never be silently replaced."""
    path = Path(path)
    with path.open('x', encoding='utf-8', newline='\n') as out:
        json.dump(value, out, ensure_ascii=False, indent=2)
        out.write('\n')
        out.flush()
        os.fsync(out.fileno())
    sync_directory(path.parent)

class CallLedger:
    def __init__(self, path, *, budget_root=None):
        self.path = Path(path)
        safe_directory(self.path)
        self.budget_root = Path(budget_root) if budget_root is not None else None
        if self.budget_root is not None:
            safe_directory(self.budget_root)
            if self.path.parent.resolve() != self.budget_root.resolve():
                raise ValueError('API ledger must be a direct child of the total budget root')
        if any(p.is_symlink() or p.name not in SLOTS or not p.is_dir() for p in self.path.iterdir()):
            raise ValueError('Unexpected call ledger entry')

    def count(self):
        # An incomplete reservation directory also consumes its slot.
        return sum((self.path / slot).exists() for slot in SLOTS)

    def total_count(self):
        if self.budget_root is None:
            return self.count()
        count = 0
        for api in self.budget_root.iterdir():
            if api.name == '.reservation.lock':
                continue
            if api.is_symlink() or not api.is_dir():
                raise ValueError('Unexpected total call ledger entry')
            for call in api.iterdir():
                if call.is_symlink() or not call.is_dir() or call.name not in SLOTS:
                    raise ValueError('Unexpected API call ledger entry')
                count += 1
        return count

    @staticmethod
    def _request(messages, input_tokens):
        if type(input_tokens) is not int or not 0 < input_tokens <= 8192:
            raise ValueError('Invalid input-token budget')
        if not isinstance(messages, list) or any(
                not isinstance(m, dict) or set(m) != {'role', 'content'} or
                not isinstance(m['role'], str) or not isinstance(m['content'], str)
                for m in messages):
            raise ValueError('Invalid request messages')
        return {'messages': messages, 'input_tokens': input_tokens,
                'max_new_tokens': 2048, 'do_sample': False}

    def _directory(self, slot):
        if slot not in SLOTS:
            raise ValueError('Unknown call slot')
        dest = self.path / slot
        if dest.is_symlink() or (dest.exists() and not dest.is_dir()):
            raise ValueError('Unsafe call slot')
        return dest

    @staticmethod
    def _read(path):
        if path.is_symlink():
            raise ValueError('Ledger evidence cannot be a symlink')
        try:
            value = json.loads(path.read_text(encoding='utf-8'))
        except (OSError, ValueError) as error:
            raise ValueError('Unreadable ledger evidence: ' + path.name) from error
        if not isinstance(value, dict):
            raise ValueError('Invalid ledger evidence: ' + path.name)
        return value

    def _verified_request(self, slot):
        dest = self._directory(slot)
        reservation_path = dest / 'reservation.json'
        if not reservation_path.exists():
            if (dest / 'result.json').exists() or (dest / 'result.sha256').exists():
                raise ValueError('Result has no durable reservation')
            return None
        reservation = self._read(reservation_path)
        request = self._read(dest / 'request.json')
        digest = hashlib.sha256((dest / 'request.json').read_bytes()).hexdigest()
        expected = self._request(request.get('messages'), request.get('input_tokens'))
        if (reservation.get('slot') != slot or reservation.get('request_sha256') != digest or
                request != expected or type(request.get('max_new_tokens')) is not int or
                request.get('do_sample') is not False):
            raise ValueError('Request identity or frozen decoding configuration changed')
        return request, reservation

    @staticmethod
    def _valid_output(response, output_tokens, seconds):
        return (isinstance(response, str) and type(output_tokens) is int and
                0 <= output_tokens <= 2048 and type(seconds) in (float, int) and
                math.isfinite(seconds) and seconds >= 0)

    def _verified_result(self, slot, seen=()):
        if slot in seen:
            raise ValueError('Cyclic cache source')
        verified = self._verified_request(slot)
        if verified is None:
            return None
        request, reservation = verified
        dest = self._directory(slot)
        result_path, checksum_path = dest / 'result.json', dest / 'result.sha256'
        if not result_path.exists() or not checksum_path.exists():
            return None  # Interrupted writes never qualify as completed calls.
        if checksum_path.is_symlink():
            raise ValueError('Ledger checksum cannot be a symlink')
        result = self._read(result_path)
        digest = hashlib.sha256(result_path.read_bytes()).hexdigest()
        if checksum_path.read_text(encoding='ascii').strip() != digest:
            raise ValueError('Result checksum mismatch')
        if (result.get('slot') != slot or result.get('request_sha256') != reservation['request_sha256'] or
                result.get('status') not in ('RETURNED', 'CACHED') or
                not self._valid_output(result.get('response'), result.get('output_tokens'), result.get('seconds'))):
            raise ValueError('Result identity or generation metadata mismatch')
        if result['status'] == 'CACHED':
            source_slot = result.get('cache_source')
            source = self._verified_result(source_slot, (*seen, slot))
            if source is None:
                raise ValueError('Cached result references an unfinished source')
            source_request, source_reservation = self._verified_request(source_slot)
            source_digest = hashlib.sha256((self.path / source_slot / 'result.json').read_bytes()).hexdigest()
            if (source_request != request or source_reservation['request_sha256'] != reservation['request_sha256'] or
                    result.get('cache_source_result_sha256') != source_digest or result['seconds'] != 0.0 or
                    result['response'] != source['response'] or result['output_tokens'] != source['output_tokens']):
                raise ValueError('Cached result does not match its verified source')
        return result

    def find_cached(self, messages, input_tokens):
        """Only this subject's finished, hash-verified identical request can hit.

        The enclosing run binding freezes source/model/configuration. There is
        deliberately no global cache or sharing between subject directories.
        Validate all evidence before returning so a valid earlier hit cannot
        conceal a damaged later cache chain.
        """
        request = self._request(messages, input_tokens)
        digest = hashlib.sha256((json.dumps(request, ensure_ascii=False, indent=2) + '\n').encode('utf-8')).hexdigest()
        found = None
        for slot in SLOTS:
            if not self._directory(slot).exists():
                continue
            result = self._verified_result(slot)
            verified = self._verified_request(slot)
            if verified is not None:
                recorded, reservation = verified
                if recorded == request and result is None:
                    raise ValueError('Identical request was interrupted; inference retries are forbidden')
                if found is None and result is not None and recorded == request and reservation['request_sha256'] == digest:
                    found = slot, result
        return found

    def cache_count(self):
        return sum(result is not None and result['status'] == 'CACHED'
                   for slot in SLOTS if self._directory(slot).exists()
                   for result in (self._verified_result(slot),))

    def actual_count(self):
        # Anything not proved to be a completed cache hit may have inferred.
        return self.count() - self.cache_count()

    def reserve(self, slot, messages, input_tokens):
        # One exclusive file serializes the global counter and durable claim.
        # An abruptly killed owner leaves it behind and fails closed.
        if self.budget_root is None:
            return self._reserve(slot, messages, input_tokens)
        lock = self.budget_root / '.reservation.lock'
        try:
            with lock.open('x', encoding='ascii') as out:
                out.write(str(os.getpid()) + '\n')
                out.flush()
                os.fsync(out.fileno())
        except FileExistsError as error:
            raise ValueError('Global reservation is active or interrupted; do not retry') from error
        sync_directory(self.budget_root)
        try:
            return self._reserve(slot, messages, input_tokens)
        finally:
            lock.unlink()
            sync_directory(self.budget_root)

    def _reserve(self, slot, messages, input_tokens):
        request = self._request(messages, input_tokens)
        dest = self._directory(slot)
        if dest.exists():
            raise ValueError('Call was already reserved; interruption does not permit retry')
        # A differently named slot must not become an inference retry either.
        self.find_cached(messages, input_tokens)
        parent = None if slot == 'seed' else ('seed' if slot.endswith('_1') else slot[:-1] + '1')
        if parent and self._verified_result(parent) is None:
            raise ValueError('Previous call did not finish')
        if self.count() >= 7:
            raise ValueError('Subject call budget exhausted')
        if self.total_count() >= MAX_TOTAL_CALLS:
            raise ValueError('Total 42-call budget exhausted')
        dest.mkdir()  # Atomic exclusive claim, even with concurrent launchers.
        sync_directory(self.path)
        write_new(dest / 'request.json', request)
        request_sha = hashlib.sha256((dest / 'request.json').read_bytes()).hexdigest()
        write_new(dest / 'reservation.json', {'slot': slot, 'reserved_at_unix': time.time(),
                                              'request_sha256': request_sha,
                                              'count_semantics': 'Reserved before inference; interruption still counts'})
        return dest

    def finish(self, slot, response, output_tokens, seconds):
        if not self._valid_output(response, output_tokens, seconds):
            raise ValueError('Invalid generation result or output budget')
        verified = self._verified_request(slot)
        if verified is None:
            raise ValueError('Cannot finish an unreserved call')
        _, reservation = verified
        self._write_result(slot, {'slot': slot, 'status': 'RETURNED', 'response': response,
                                 'request_sha256': reservation['request_sha256'],
                                 'output_tokens': output_tokens, 'seconds': seconds})

    def _write_result(self, slot, result):
        dest = self._directory(slot)
        write_new(dest / 'result.json', result)
        digest = hashlib.sha256((dest / 'result.json').read_bytes()).hexdigest()
        with (dest / 'result.sha256').open('x', encoding='ascii', newline='\n') as out:
            out.write(digest + '\n')
            out.flush()
            os.fsync(out.fileno())
        sync_directory(dest)

    def finish_cached(self, slot, source_slot):
        if slot == source_slot:
            raise ValueError('A cached call cannot be its own source')
        verified = self._verified_request(slot)
        source = self._verified_result(source_slot)
        if verified is None or source is None:
            raise ValueError('Cache requires a reserved destination and finished source')
        request, reservation = verified
        source_request, source_reservation = self._verified_request(source_slot)
        if request != source_request or reservation['request_sha256'] != source_reservation['request_sha256']:
            raise ValueError('Cache request identity differs from source')
        self._write_result(slot, {'slot': slot, 'status': 'CACHED', 'response': source['response'],
                                 'request_sha256': reservation['request_sha256'],
                                 'output_tokens': source['output_tokens'], 'seconds': 0.0,
                                 'cache_source': source_slot,
                                 'cache_source_result_sha256': hashlib.sha256(
                                     (self.path / source_slot / 'result.json').read_bytes()).hexdigest()})


Ledger = CallLedger


def check_deadline(deadline):
    if type(deadline) not in (int, float) or not math.isfinite(deadline):
        raise ValueError('A finite persistent deadline is required')
    remaining = deadline - time.time()
    if remaining <= 0:
        raise ValueError('Persistent batch deadline reached')
    return remaining


def bind_deadline(run_dir, deadline):
    """Freeze the caller's absolute Unix deadline, including across restarts."""
    check_deadline(deadline)
    run_dir = safe_directory(run_dir)
    path = run_dir / 'model_deadline.json'
    expected = {'deadline_unix': float(deadline)}
    if path.exists():
        if CallLedger._read(path) != expected:
            raise ValueError('Persistent deadline changed; extensions are forbidden')
    else:
        write_new(path, expected)
    return float(deadline)


def _gpu_state(torch):
    free, total = torch.cuda.mem_get_info(0)
    return {'device': 0, 'free_mib': int(free // 1024**2),
            'total_mib': int(total // 1024**2)}


def tokenizer_probe(model_path, contexts):
    """Tokenize supplied chat-message lists offline without loading a model."""
    from transformers import AutoTokenizer
    tokenizer = AutoTokenizer.from_pretrained(str(model_path), local_files_only=True,
                                            trust_remote_code=False)
    result = []
    for messages in contexts:
        rendered = tokenizer.apply_chat_template(messages, tokenize=False, add_generation_prompt=True)
        result.append(len(tokenizer(rendered)['input_ids']))
    return result


class LocalModel:
    """One BF16 model instance for the whole bounded external confirmation."""

    def __init__(self, run_dir, deadline, model_path):
        self.run_dir = safe_directory(run_dir)
        self.deadline = bind_deadline(self.run_dir, deadline)
        self.model_path = Path(model_path).resolve(strict=True)
        if not self.model_path.is_dir():
            raise ValueError('Existing local model directory is required')
        self.calls = safe_directory(self.run_dir / 'calls')
        # An exclusive load marker prevents a second worker from loading too.
        write_new(self.run_dir / 'model_load_started.json', {
            'started_at_unix': time.time(), 'deadline_unix': self.deadline,
            'model_path': str(self.model_path), 'pid': os.getpid()})
        check_deadline(self.deadline)
        os.environ['HF_HUB_OFFLINE'] = '1'
        os.environ['TRANSFORMERS_OFFLINE'] = '1'
        import torch
        import transformers
        from transformers import AutoModelForCausalLM, AutoTokenizer, StoppingCriteria, TextStreamer
        if torch.__version__ != '2.5.1+cu124' or transformers.__version__ != '4.57.6':
            raise ValueError('Existing verified Paper runtime versions changed')
        torch.set_num_threads(2)
        torch.manual_seed(0)
        self.torch = torch
        self.streamer_base = TextStreamer
        self.stopping_base = StoppingCriteria
        before = _gpu_state(torch)
        if before['free_mib'] < START_FREE_MIB:
            raise ValueError(f'Less than {START_FREE_MIB} MiB free before model load')
        check_deadline(self.deadline)
        self.tokenizer = AutoTokenizer.from_pretrained(str(self.model_path), local_files_only=True,
                                                      trust_remote_code=False)
        check_deadline(self.deadline)
        tick = time.monotonic()
        self.model = AutoModelForCausalLM.from_pretrained(
            str(self.model_path), local_files_only=True, trust_remote_code=False,
            dtype=torch.bfloat16, device_map={'': 0}, low_cpu_mem_usage=True,
            use_safetensors=True, attn_implementation='sdpa').eval()
        torch.cuda.synchronize()
        self.versions = {
            'torch': torch.__version__, 'transformers': transformers.__version__,
            'cuda': torch.version.cuda, 'dtype': 'bfloat16',
            'model_path': str(self.model_path), 'gpu_before': before,
            'gpu_after_load': _gpu_state(torch), 'load_seconds': time.monotonic() - tick,
            'start_free_mib': START_FREE_MIB, 'inference_free_mib': INFERENCE_FREE_MIB,
            'max_input_tokens': MAX_INPUT_TOKENS, 'max_new_tokens': MAX_NEW_TOKENS,
            'do_sample': False, 'num_beams': 1, 'deadline_unix': self.deadline,
            'finished_before_deadline': time.time() < self.deadline}
        write_new(self.run_dir / 'model.json', self.versions)
        check_deadline(self.deadline)

    def ledger(self, api_id):
        if not isinstance(api_id, str) or re.fullmatch(r'[A-Za-z0-9][A-Za-z0-9_.-]{0,159}', api_id) is None:
            raise ValueError('Invalid API ID for call ledger')
        return CallLedger(self.calls / api_id, budget_root=self.calls)

    @staticmethod
    def _returned(slot, result, input_tokens):
        cached = result['status'] == 'CACHED'
        return {'response': result['response'], 'input_tokens': 0 if cached else input_tokens,
                'output_tokens': 0 if cached else result['output_tokens'],
                'logical_input_tokens': input_tokens,
                'logical_output_tokens': result['output_tokens'],
                'seconds': result['seconds'], 'cached': cached, 'slot': slot}

    def generate(self, api_id, slot, messages):
        check_deadline(self.deadline)
        ledger = self.ledger(api_id)
        ledger._directory(slot)  # Reject invalid slots before tokenization.
        rendered = self.tokenizer.apply_chat_template(messages, tokenize=False, add_generation_prompt=True)
        inputs = self.tokenizer(rendered, return_tensors='pt')
        count = int(inputs['input_ids'].shape[1])
        if count > MAX_INPUT_TOKENS or count + MAX_NEW_TOKENS > self.model.config.max_position_embeddings:
            raise ValueError('Input exceeds frozen token budget')
        check_deadline(self.deadline)
        cached = ledger.find_cached(messages, count)
        if cached is not None:
            source_slot, _ = cached
            output = ledger.reserve(slot, messages, count)
            write_new(output / 'rendered_prompt.json', {
                'text': rendered, 'sha256': hashlib.sha256(rendered.encode('utf-8')).hexdigest()})
            check_deadline(self.deadline)
            ledger.finish_cached(slot, source_slot)
            check_deadline(self.deadline)
            return self._returned(slot, ledger._verified_result(slot), count)
        free, _ = self.torch.cuda.mem_get_info(0)
        if free < INFERENCE_FREE_MIB * 1024**2:
            raise ValueError(f'Less than {INFERENCE_FREE_MIB} MiB free before inference')
        inputs = inputs.to('cuda:0')
        check_deadline(self.deadline)
        output = ledger.reserve(slot, messages, count)
        write_new(output / 'rendered_prompt.json', {
            'text': rendered, 'sha256': hashlib.sha256(rendered.encode('utf-8')).hexdigest()})
        partial = output / 'response.partial.txt'
        deadline = self.deadline

        class Progress(self.streamer_base):
            def on_finalized_text(self, text, stream_end=False):
                if text:
                    with partial.open('a', encoding='utf-8') as out:
                        out.write(text)
                        out.flush()
                        os.fsync(out.fileno())

        class DeadlineStop(self.stopping_base):
            def __call__(self, input_ids, scores, **kwargs):
                return time.time() >= deadline

        with partial.open('x', encoding='utf-8') as out:
            out.flush()
            os.fsync(out.fileno())
        sync_directory(output)
        tick = time.monotonic()
        check_deadline(self.deadline)
        with self.torch.inference_mode():
            generated = self.model.generate(
                **inputs, max_new_tokens=MAX_NEW_TOKENS, do_sample=False, num_beams=1,
                num_return_sequences=1,
                pad_token_id=(self.tokenizer.pad_token_id if self.tokenizer.pad_token_id is not None
                              else self.tokenizer.eos_token_id),
                streamer=Progress(self.tokenizer, skip_prompt=True, skip_special_tokens=True),
                stopping_criteria=[DeadlineStop()])
        self.torch.cuda.synchronize()
        seconds = time.monotonic() - tick
        check_deadline(self.deadline)
        output_tokens = int(generated.shape[1] - count)
        response = self.tokenizer.decode(generated[0, count:], skip_special_tokens=True)
        check_deadline(self.deadline)
        ledger.finish(slot, response, output_tokens, seconds)
        check_deadline(self.deadline)
        del inputs, generated
        return self._returned(slot, ledger._verified_result(slot), count)

