import base64
import hashlib
import json
import os
from pathlib import Path
import shutil
import tempfile
import time
from xml.sax.saxutils import escape
from common import Commands, digest, read, write
from config import ROOT, SOURCE, JDK, CACHE, REPO, APIS, SEED
from methods import method_body_key
from pit_report import parse_report
from protocol_boundary import partition

JUNIT = REPO / 'junit/junit/4.12/junit-4.12.jar'
HAMCREST = REPO / 'org/hamcrest/hamcrest-core/1.3/hamcrest-core-1.3.jar'


class Runtime:
    def __init__(self, command, base=None):
        self.command = command
        self.base = base or ROOT / 'setup/runtime'
        self.production = self.base / 'classes'
        self.helpers = self.base / 'helpers'
        self.reference = self.base / 'reference'
        self.methods = {}

    def compile_base(self):
        self.base.mkdir(parents=True)
        for name in ('classes', 'helpers', 'reference'):
            (self.base / name).mkdir()
        source_files = sorted((SOURCE / 'src/main/java').rglob('*.java'))
        args = self.base / 'sources.args'
        args.write_text('\n'.join(map(str, source_files)) + '\n')
        self.command.run(self.base, 'production', [JDK / 'bin/javac', '--release', '7', '-encoding', 'UTF-8',
                         '-d', self.production, '@' + str(args)], required=True)
        java = sorted((ROOT / 'java/entry').glob('*.java')) + [ROOT / 'java/CodecGuard.java']
        cp = os.pathsep.join(map(str, (self.production, JUNIT, HAMCREST)))
        self.command.run(self.base, 'helpers', [JDK / 'bin/javac', '-encoding', 'UTF-8', '-cp', cp,
                         '-d', self.helpers, *java], required=True)
        cp = str(self.helpers) + os.pathsep + cp
        self.command.run(self.base, 'reference', [JDK / 'bin/javac', '-encoding', 'UTF-8', '-cp', cp,
                         '-d', self.reference, *sorted((ROOT / 'java/reference').rglob('*.java'))], required=True)

    def cp(self, tests=None, reference=False):
        entries = ([self.reference] if reference else []) + [self.helpers, self.production, JUNIT, HAMCREST]
        if tests is not None:
            entries.insert(0, tests)
        return os.pathsep.join(map(str, entries))

    def guard(self, api, source, out):
        out.mkdir(parents=True)
        path = out / 'response.txt'
        path.write_text(source, encoding='utf-8')
        code, log = self.command.run(out, 'guard', [JDK / 'bin/java', '-cp', self.helpers, 'CodecGuard', path, api])
        if code:
            return {'structure_pass': False, 'total_methods': 0, 'methods': [], 'original_feedback': log[:1024]}
        methods, total = [], None
        for line in log.splitlines():
            parts = line.split('\t')
            if parts[0] == 'TOTAL' and len(parts) == 2:
                total = int(parts[1])
                continue
            assert parts[0] in ('METHOD', 'REJECT') and len(parts) == 3, line
            index = int(parts[1])
            assert index == len(methods) and index < 8
            text = base64.b64decode(parts[2], validate=True).decode()
            methods.append({'index': index, 'source': text} if parts[0] == 'METHOD' else
                           {'index': index, 'status': 'GUARD_REJECTED', 'diagnostic': text})
        assert total is not None and len(methods) == min(total, 8)
        return dict(structure_pass=True, total_methods=total, methods=methods)

    def validate(self, api, response, out, cache):
        tick = time.monotonic()
        result = self.guard(api, response, out)
        for position, row in enumerate(result['methods']):
            if 'source' not in row:
                continue
            key = hashlib.sha256(json.dumps(method_body_key(row['source']), separators=(',', ':')).encode()).hexdigest()
            key = hashlib.sha256((api + key).encode()).hexdigest()[:32]
            folder = cache / key
            if folder.exists():
                saved = read(folder / 'result.json')
                assert method_body_key(saved['source']) == method_body_key(row['source'])
            else:
                folder.mkdir(parents=True)
                saved = dict(id=key, source=row['source'], index=row['index'], class_name='entry.Case_' + key)
                classes = folder / 'classes'
                classes.mkdir()
                java = folder / ('Case_' + key + '.java')
                java.write_text('package entry;\nimport org.junit.Test;\nimport org.junit.Assert;\n'
                    'import static org.junit.Assert.*;\nimport java.nio.charset.StandardCharsets;\n'
                    'import org.apache.commons.codec.binary.Hex;\nimport org.apache.commons.codec.binary.Base64;\n'
                    'import org.apache.commons.codec.net.URLCodec;\npublic class Case_' + key + ' {\n' + row['source'] + '\n}\n', encoding='utf-8')
                started = time.monotonic()
                code, log = self.command.run(folder, 'compile', [JDK / 'bin/javac', '-encoding', 'UTF-8',
                                             '-cp', self.cp(), '-d', classes, java])
                saved.update(status='COMPILE_FAILURE', original_pass=False, original_feedback=log[:1024])
                if code == 0:
                    runs = {}
                    for reference in (True, False):
                        name = 'reference' if reference else 'original'
                        code, log = self.command.run(folder, name, [JDK / 'bin/java', '-Xmx256m', '-cp',
                            self.cp(classes, reference), 'entry.CheckOne', saved['class_name'], name], limit=15)
                        lines = [s.split('\t', 1)[1] for s in log.splitlines() if s.startswith('CHECK_RESULT\t')]
                        if len(lines) != 1:
                            raise RuntimeError('JUnit telemetry missing: ' + str(folder / (name + '.log')))
                        stats = json.loads(lines[0])
                        assert type(stats['run_count']) is int and type(stats['failures']) is int
                        runs[name] = dict(**stats, returncode=code)
                        if not reference:
                            saved.update(original_pass=code == 0 and stats['run_count'] == 1 and stats['failures'] == 0,
                                         original_feedback=log[:1024] if code or stats['run_count'] != 1 else 'Original program passed.')
                    ref = runs['reference']
                    if ref['out_of_domain']:
                        status = 'OUT_OF_DOMAIN'
                    elif ref['run_count'] != 1 or runs['original']['run_count'] != 1:
                        status = 'TEST_DISCOVERY_FAILURE'
                    elif not ref['calls']:
                        status = 'NO_TARGET_CALL'
                    elif not saved['original_pass']:
                        status = 'ORIGINAL_FAILURE'
                    elif ref['returncode'] or ref['failures']:
                        status = 'REFERENCE_FAILURE'
                    else:
                        status = 'PASS'
                    saved.update(status=status, junit=runs)
                saved['validation_seconds'] = time.monotonic() - started
                write(folder / 'result.json', saved)
            self.methods[key] = (saved, folder)
            result['methods'][position] = {**saved, 'index': row['index']}
        result['extraction_and_validation_seconds'] = time.monotonic() - tick
        # Only original-program information from the first four positions can enter E/M.
        result['original_feedback'] = [{'index': m['index'], 'diagnostic': m.get('original_feedback',
            m.get('diagnostic', 'Original program outcome unavailable.'))} for m in result['methods'][:4]] if result['structure_pass'] else result['original_feedback']
        write(out / 'result.json', result)
        return result

    def pit(self, api, ids, out, *, check=True):
        target = APIS[api]['target']
        out.mkdir(parents=True)
        work_parent = ROOT / '.work'
        work_parent.mkdir(exist_ok=True)
        with tempfile.TemporaryDirectory(prefix='pit-', dir=work_parent) as temp:
            work = Path(temp)
            shutil.copytree(self.production, work / 'target/classes')
            tests = work / 'target/test-classes/entry'
            tests.mkdir(parents=True)
            src = work / 'src/test/java/entry'
            src.mkdir(parents=True)
            for key in ids:
                record, folder = self.methods[key]
                assert record['status'] == 'PASS'
                short = record['class_name'].split('.')[-1]
                shutil.copy2(folder / (short + '.java'), src / (short + '.java'))
                shutil.copy2(folder / 'classes/entry' / (short + '.class'), tests / (short + '.class'))
            if not ids:
                java = src / 'Case_empty.java'
                java.write_text('package entry; public class Case_empty { @org.junit.Test public void empty(){ org.junit.Assert.assertTrue(true); }}')
                self.command.run(out, 'empty_compile', [JDK / 'bin/javac', '-cp', self.cp(), '-d', work / 'target/test-classes', java], required=True)
            raw = out / 'raw'
            pom = f'''<project xmlns="http://maven.apache.org/POM/4.0.0"><modelVersion>4.0.0</modelVersion>
<groupId>local.codec</groupId><artifactId>selection</artifactId><version>1</version>
<dependencies><dependency><groupId>junit</groupId><artifactId>junit</artifactId><version>4.12</version><scope>test</scope></dependency></dependencies>
<build><sourceDirectory>{escape(str(SOURCE/'src/main/java'))}</sourceDirectory><plugins><plugin><groupId>org.pitest</groupId><artifactId>pitest-maven</artifactId><version>1.14.4</version><configuration>
<targetClasses><param>{target}</param></targetClasses><targetTests><param>entry.Case_*</param></targetTests>
<mutators><mutator>DEFAULTS</mutator></mutators><features><feature>-CLASSLIMIT</feature></features>
<threads>1</threads><outputFormats><param>XML</param></outputFormats><timestampedReports>false</timestampedReports>
<reportsDirectory>{escape(str(raw))}</reportsDirectory><failWhenNoMutations>true</failWhenNoMutations>
<timeoutConstant>1000</timeoutConstant><mutationThreshold>0</mutationThreshold><coverageThreshold>0</coverageThreshold>
<jvm>{escape(str(JDK/'bin/java'))}</jvm><jvmArgs><param>-Xmx256m</param></jvmArgs>
</configuration></plugin></plugins></build></project>'''
            (work / 'pom.xml').write_text(pom)
            (out / 'evaluation_pom.xml').write_text(pom)
            self.command.run(out, 'pit', ['mvn', '-B', '-o', '-f', work / 'pom.xml', '-s', CACHE / 'maven_settings.xml',
                '-gs', CACHE / 'maven_settings.xml', '-Dmaven.repo.local=' + str(REPO),
                'org.pitest:pitest-maven:1.14.4:mutationCoverage'], cwd=work, limit=90, required=True)
            rows = parse_report((raw / 'mutations.xml').read_bytes(), target)
        if check:
            assert partition(rows, SEED) == read(ROOT / 'setup' / (APIS[api]['family'] + '_partition.json')), 'Mutant universe changed'
        write(out / 'mutants.json', rows)
        return rows
