import argparse
from collections import Counter
import gc
import hashlib
import importlib.metadata as md
import json
import os
from pathlib import Path
import shutil
import signal
import subprocess
import sys
import time

sys.path.insert(0, str(Path(__file__).resolve().parent))
from common import Commands, digest, read, remote_only, verify, write
from config import ROOT, APIS, ARMS, MODEL, SOURCE, JDK, PYTHON, SEED, source_context
from runtime import Runtime
from protocol_boundary import partition
from selection import prefix_ids, matched, suite_hash
from messages import build, compact_feedback

GOOD = {
 'hex_encode': '@Test public void sample(){ assertEquals("66", Hex.encodeHexString(new byte[]{102})); }',
 'hex_decode': '@Test public void sample() throws Exception { assertArrayEquals(new byte[]{102}, Hex.decodeHex("66")); }',
 'base64_encode': '@Test public void sample(){ assertEquals("Zg==", Base64.encodeBase64String(new byte[]{102})); }',
 'base64_decode': '@Test public void sample(){ assertArrayEquals(new byte[]{102}, Base64.decodeBase64("Zg==")); }',
 'form_encode': '@Test public void sample() throws Exception { assertEquals("a+b", new URLCodec().encode("a b", "UTF-8")); }',
 'form_decode': '@Test public void sample() throws Exception { assertEquals("a b", new URLCodec().decode("a+b", "UTF-8")); }',
}


def model_identity():
    assert MODEL.resolve(strict=True) == MODEL
    result = {}
    for p in sorted(MODEL.iterdir()):
        assert not p.is_symlink()
        if p.is_file() and not p.name.startswith('.'):
            st = p.stat()
            result[p.name] = {'bytes': st.st_size, 'mtime_ns': st.st_mtime_ns}
            if st.st_size < 20000000:
                result[p.name]['sha256'] = digest(p)
    assert len([k for k in result if k.endswith('.safetensors')]) == 4
    return result


def prepare_worker(deadline):
    remote_only()
    assert md.version('torch') == '2.5.1+cu124' and md.version('transformers') == '4.57.6'
    command = Commands(deadline)
    ROOT.joinpath('setup').mkdir()
    runtime = Runtime(command)
    runtime.compile_base()
    check = ROOT / 'setup/checks'
    checks, good_ids = {}, {}
    for api, body in GOOD.items():
        print(json.dumps({'stage': 'PREPARE_API', 'api': api}), flush=True)
        calibration = []
        for ref in (False, True):
            name = 'reference' if ref else 'original'
            _, log = command.run(check / api, 'calibration_' + name,
                [JDK / 'bin/java', '-cp', runtime.cp(reference=ref), 'entry.Calibration', api], required=True)
            calibration.append([s for s in log.splitlines() if s.startswith('CALIBRATION\t')])
        assert len(calibration[0]) == 1 and calibration[0] == calibration[1], 'Independent calibration disagreement: ' + api
        result = runtime.validate(api, body, check / api / 'good', check / 'methods')
        assert result['methods'][0]['status'] == 'PASS', (api, result)
        good_ids[api] = result['methods'][0]['id']
        # Different input bytes/string are never rewritten to fit a generated assertion.
        bad = body.replace('"66"', '"67"') if api == 'hex_encode' else (
              body.replace('new byte[]{102}', 'new byte[]{103}') if api in ('hex_decode', 'base64_decode') else
              body.replace('"Zg=="', '"Zw=="') if api == 'base64_encode' else
              body.replace('assertEquals("a+b"', 'assertEquals("a%20b"') if api == 'form_encode' else
              body.replace('assertEquals("a b"', 'assertEquals("a+b"'))
        wrong = runtime.validate(api, bad, check / api / 'wrong', check / 'methods')
        assert wrong['methods'][0]['status'] != 'PASS', 'Incorrect assertion admitted'
        # Locals avoid overload ambiguity without admitting extra cast syntax.
        if api in ('hex_encode', 'base64_encode'):
            nul = body.replace('assertEquals(', 'byte[] absent = null; assertEquals(', 1).replace('new byte[]{102}', 'absent')
        elif api in ('hex_decode', 'base64_decode'):
            nul = body.replace('assertArrayEquals(', 'String absent = null; assertArrayEquals(', 1)
            nul = nul.replace('Hex.decodeHex("66")', 'Hex.decodeHex(absent)').replace('Base64.decodeBase64("Zg==")', 'Base64.decodeBase64(absent)')
        else:
            nul = body.replace('assertEquals(', 'String absent = null; assertEquals(', 1)
            nul = nul.replace('.encode("a b",', '.encode(absent,').replace('.decode("a+b",', '.decode(absent,')
        outside = runtime.validate(api, nul, check / api / 'null', check / 'methods')
        assert outside['methods'][0]['status'] == 'OUT_OF_DOMAIN', (api, outside)
        checks[api] = {'valid': 'PASS', 'wrong': wrong['methods'][0]['status'], 'null': 'OUT_OF_DOMAIN',
                       'calibration': calibration[0][0]}
    # Verify zero JUnit discovery without treating an empty suite as valid.
    zero = check / 'zero'
    zero.mkdir()
    p = zero / 'Zero.java'
    p.write_text('package entry; @org.junit.runner.RunWith(org.junit.runners.Suite.class) '
                 '@org.junit.runners.Suite.SuiteClasses({}) public class Zero {}')
    command.run(zero, 'compile', [JDK / 'bin/javac', '-cp', runtime.cp(), '-d', zero, p], required=True)
    _, log = command.run(zero, 'junit', [JDK / 'bin/java', '-cp', runtime.cp(zero), 'entry.CheckOne', 'entry.Zero', 'original'])
    telemetry = json.loads(next(s.split('\t', 1)[1] for s in log.splitlines() if s.startswith('CHECK_RESULT\t')))
    assert telemetry['run_count'] == 0
    for family, api in (('hex', 'hex_encode'), ('base64', 'base64_encode'), ('form', 'form_encode')):
        rows = runtime.pit(api, [], check / family / 'empty_pit', check=False)
        split = partition(rows, SEED)
        assert split['status'] == 'PARTITIONED'
        write(ROOT / 'setup' / (family + '_partition.json'), split)
        runtime.pit(api, [good_ids[api]], check / family / 'nonempty_pit')
    os.environ.update(HF_HUB_OFFLINE='1', TRANSFORMERS_OFFLINE='1')
    from transformers import AutoTokenizer
    tokenizer = AutoTokenizer.from_pretrained(str(MODEL), local_files_only=True, trust_remote_code=False)
    tokens = {}
    for api in APIS:
        context = source_context(api)
        p = ROOT / 'inputs/contexts' / (api + '.txt')
        p.parent.mkdir(parents=True, exist_ok=True)
        p.write_text(context, encoding='utf-8')
        messages = build(api, context, [], 'seed')
        count = len(tokenizer.apply_chat_template(messages, tokenize=True, add_generation_prompt=True))
        family = APIS[api]['family']
        rows = read(check / family / 'empty_pit/mutants.json')
        m = build(api, context, [], 'mutation', [], rows, read(ROOT / 'setup' / (family + '_partition.json')))
        feedback_tokens = len(tokenizer.apply_chat_template(m, tokenize=True, add_generation_prompt=True))
        assert feedback_tokens + 4096 <= 8192, 'Context/complete visible feedback cannot fit two previous output budgets: ' + api
        tokens[api] = {'seed_input_tokens': count, 'mutation_empty_suite_input_tokens': feedback_tokens,
                       'two_previous_output_token_reserve': 4096}
    write(ROOT / 'setup/model_identity.json', model_identity())
    write(ROOT / 'setup/context_tokens.json', tokens)
    write(ROOT / 'protocol.json', {'status': 'FROZEN_BEFORE_NEW_INFERENCE', 'apis': APIS, 'seed': SEED,
          'model': MODEL.name, 'max_logical_calls': 42, 'max_output_tokens': 2048, 'max_input_tokens': 8192,
          'methods_requested': 8, 'trajectory_positions': 4, 'random_repeats': 5, 'wall_seconds': 10800,
          'max_final_logical_evaluations': 162, 'max_generation_feedback_pit': 12,
          'statistical_unit': 'Six paired API observations nested in three behavior families and one project',
          'holdout': 'Class/method/descriptor/source-line site; evaluation metadata withheld; not whole-method isolation'})
    write(ROOT / 'setup/preparation.json', {'status': 'PASS', 'checks': checks, 'zero_test_discovery_detected': True,
          'model_calls': 0, 'commands_seconds': sum(r['seconds'] for r in command.records),
          'protocol_basis_sha256': digest(ROOT.parent / 'external_java_entry/README.md')})
    files = {}
    for directory in ('scripts', 'java', 'inputs/contexts', 'setup'):
        for path in sorted((ROOT / directory).rglob('*')):
            if path.is_file():
                files[path.relative_to(ROOT).as_posix()] = digest(path)
    files['protocol.json'] = digest(ROOT / 'protocol.json')
    write(ROOT / 'freeze.json', {'files': files})
    print(json.dumps({'status': 'PREPARED_ZERO_MODEL_CALLS', 'frozen_files': len(files), 'tokens': tokens}), flush=True)


def worker(deadline):
    verify()
    assert model_identity() == read(ROOT / 'setup/model_identity.json')
    from model_backend import LocalModel
    out = ROOT / 'outputs/run'
    command = Commands(deadline)
    runtime = Runtime(command)
    model = LocalModel(out, deadline, MODEL)
    checkpoints = {}
    for api in APIS:
        print(json.dumps({'stage': 'GENERATING_API', 'api': api, 'remaining_seconds': deadline - time.time()}), flush=True)
        cp = {}
        context = (ROOT / 'inputs/contexts' / (api + '.txt')).read_text()
        cache = out / 'methods' / api
        previous = []
        for arm in ('seed', *ARMS):
            suite, errors = ([], None) if arm == 'seed' else (cp['seed']['suite'], cp['seed']['original_feedback'])
            for round_no in ((0,) if arm == 'seed' else (1, 2)):
                slot = 'seed' if arm == 'seed' else arm + '_' + str(round_no)
                rows = None
                split = read(ROOT / 'setup' / (APIS[api]['family'] + '_partition.json'))
                if arm == 'mutation':
                    rows = runtime.pit(api, [m['id'] for m in suite], out / 'feedback' / api / slot)
                response = model.generate(api, slot, build(api, context, suite, arm, errors, rows, split))
                val = runtime.validate(api, response['response'], out / 'responses' / api / slot, cache)
                ids = list(dict.fromkeys([m['id'] for m in suite] + prefix_ids([val['methods']], 4)))
                suite = [runtime.methods[i][0] for i in ids]
                errors = val['original_feedback']
                cp[slot] = dict(validation=val, suite=suite, original_feedback=errors)
        checkpoints[api] = cp
        write(out / 'checkpoints' / (api + '.json'), cp)
    del model
    gc.collect()
    import torch
    torch.cuda.empty_cache()
    # Freeze every selection before reading any final evaluation outcomes.
    plans = {}
    for api, cp in checkpoints.items():
        prefix, pools, rows = {}, {}, []
        for arm in ARMS:
            responses = [cp[s]['validation']['methods'] for s in ('seed', arm + '_1', arm + '_2')]
            for limit in (1, 4, 8):
                ids = prefix_ids(responses, limit)
                rows.append(dict(arm=arm, rule='positions_' + str(limit), ids=ids))
                if limit == 4:
                    prefix[arm] = ids
                if limit == 8:
                    pools[arm] = ids
        match = matched(api, prefix, pools)
        for arm in ARMS:
            rows.append(dict(arm=arm, rule='matched_prefix', ids=match['arms'][arm]['prefix']))
            for n, ids in enumerate(match['arms'][arm]['random']):
                rows.append(dict(arm=arm, rule='matched_random_' + str(n), ids=ids))
        plans[api] = {'k': match['k'], 'rows': rows}
    write(out / 'plans.json', plans)
    results, actual_pit = {}, 0
    for api, plan in plans.items():
        reports, scored = {}, []
        split = read(ROOT / 'setup' / (APIS[api]['family'] + '_partition.json'))
        evaluation = set(split['evaluation_ids'])
        for row in plan['rows']:
            key = suite_hash(row['ids'])
            if key not in reports:
                print(json.dumps({'stage': 'SCORING', 'api': api, 'suite': key[:10], 'remaining_seconds': deadline - time.time()}), flush=True)
                reports[key] = runtime.pit(api, row['ids'], out / 'pit' / api / key)
                actual_pit += 1
            report = reports[key]
            selected = [r for r in report if r['id'] in evaluation]
            scored.append(dict(**row, suite_hash=key, valid_methods=len(row['ids']),
                evaluation_mutants=len(selected), killed_ids=sorted(r['id'] for r in selected if r['status'] == 'KILLED'),
                statuses=dict(Counter(r['status'] for r in selected))))
        results[api] = dict(family=APIS[api]['family'], k=plan['k'], rows=scored)
    write(out / 'results.json', {'status': 'COMPLETE_VALUE_REVIEW_PENDING', 'apis': results,
          'logical_comparisons': sum(len(p['rows']) for p in plans.values()), 'actual_final_pit_runs': actual_pit,
          'generation_feedback_pit_runs': 12, 'freeze_sha256': digest(ROOT / 'freeze.json'),
          'command_seconds': sum(r['seconds'] for r in command.records), 'next_owner': 'GPT-6 Astra'})


def supervise(prepare):
    remote_only()
    if prepare:
        budget = ROOT / 'preparation_budget.json'
        old = read(budget) if budget.exists() else {'spent_seconds': 0, 'attempts': [], 'local_short_check_charge_seconds': 120}
        if old.get('active'):
            raise RuntimeError('Inspect the active preparation record before restarting')
        if (ROOT / 'freeze.json').exists():
            verify()
            print('ALREADY_PREPARED')
            return
        if (ROOT / 'setup').exists():
            prior = ROOT / ('failed_preparation_' + str(len(old['attempts'])))
            assert not prior.exists() and (ROOT / 'setup').resolve() == ROOT / 'setup'
            shutil.move(str(ROOT / 'setup'), prior)
        limit = min(450, 598 - old['local_short_check_charge_seconds'] - old['spent_seconds'])
        assert limit > 5, 'Preparation short-check budget exhausted'
        logdir = ROOT / 'preparation_logs' / str(len(old['attempts']))
    else:
        verify()
        assert model_identity() == read(ROOT / 'setup/model_identity.json')
        logdir = ROOT / 'outputs/run'
        assert not logdir.exists(), 'Run already started; inspect retained results instead of resetting budget'
        limit = 10800
    logdir.mkdir(parents=True)
    started = time.time()
    deadline = started + limit
    state = dict(status='RUNNING', started_unix=started, deadline_unix=deadline, wall_cap_seconds=limit,
                 freeze_sha256=digest(ROOT / 'freeze.json') if not prepare else None)
    write(logdir / 'start.json', state)
    if prepare:
        old['active'] = state
        budget.write_text(json.dumps(old, indent=2) + '\n')
    print(json.dumps({'status': 'PREPARING' if prepare else 'RUNNING', 'wall_cap_seconds': limit, 'log': str(logdir / 'worker.log')}), flush=True)
    code, killed = None, False
    try:
        with (logdir / 'worker.log').open('xb') as log:
            p = subprocess.Popen([str(PYTHON), '-I', '-B', str(Path(__file__).resolve()),
                '--prepare-worker' if prepare else '--worker', '--deadline', str(deadline - 3)],
                cwd=ROOT, stdout=log, stderr=subprocess.STDOUT, start_new_session=True)
            while p.poll() is None:
                try:
                    p.wait(timeout=min(10, max(0.1, deadline - time.time())))
                except subprocess.TimeoutExpired:
                    print(json.dumps({'status': 'PREPARING' if prepare else 'RUNNING', 'remaining_seconds': round(deadline - time.time(), 1)}), flush=True)
                if time.time() >= deadline and p.poll() is None:
                    os.killpg(p.pid, signal.SIGKILL)
                    killed = True
            code = p.wait()
            expected = ROOT / 'setup/preparation.json' if prepare else logdir / 'results.json'
            expected_status = 'PASS' if prepare else 'COMPLETE_VALUE_REVIEW_PENDING'
            if code == 0 and (not expected.is_file() or read(expected).get('status') != expected_status):
                code = 1
    finally:
        if 'p' in locals():
            try:
                os.killpg(p.pid, signal.SIGKILL)
            except ProcessLookupError:
                pass
        elapsed = time.time() - started
        result = dict(status='PREPARED' if prepare and code == 0 else 'COMPLETE_VALUE_REVIEW_PENDING' if code == 0 else 'INCOMPLETE',
                      returncode=code, killed=killed, wall_seconds=elapsed, wall_cap_seconds=limit,
                      result=str(ROOT / 'setup/preparation.json' if prepare else logdir / 'results.json'))
        write(logdir / 'completion.json', result)
        if prepare:
            old['active'] = None
            old['spent_seconds'] += elapsed
            old['attempts'].append(result)
            budget.write_text(json.dumps(old, indent=2) + '\n')
        print(json.dumps(result), flush=True)
    if code != 0 or killed:
        raise SystemExit(1)


def main():
    parser = argparse.ArgumentParser()
    mode = parser.add_mutually_exclusive_group(required=True)
    for flag in ('prepare', 'prepare-worker', 'run', 'worker', 'preflight'):
        mode.add_argument('--' + flag, action='store_true')
    parser.add_argument('--deadline', type=float)
    args = parser.parse_args()
    if args.prepare_worker:
        prepare_worker(args.deadline)
    elif args.worker:
        worker(args.deadline)
    elif args.preflight:
        remote_only()
        frozen = verify()
        assert model_identity() == read(ROOT / 'setup/model_identity.json')
        print(json.dumps({'status': 'READY_FOR_MANUAL_RUN', 'apis': len(APIS), 'files_verified': len(frozen['files']),
                          'model_calls': 0, 'max_logical_calls': 42, 'wall_cap_seconds': 10800,
                          'freeze_sha256': digest(ROOT / 'freeze.json')}))
    else:
        supervise(args.prepare)


if __name__ == '__main__':
    main()
