from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
REMOTE = Path('/root/autodl-tmp/LSH/mutgen_budget_pilot_20261111/revision/external_confirmation')
AUTHORIZED = Path('/root/autodl-tmp/LSH')
ENTRY = ROOT.parent / 'external_java_entry'
SOURCE = ENTRY / 'inputs/source'
JDK = AUTHORIZED / 'cdd_weighted_pilot_20261021/tools/jdk17'
CACHE = AUTHORIZED / 'dcaware_sfc_sample0_20261110'
REPO = CACHE / 'm2_repository'
MODEL = AUTHORIZED / 'models/Qwen2.5-Coder-7B-Instruct'
PYTHON = AUTHORIZED / 'conda/envs/Paper/bin/python'
SEED = 'commons-codec-selection-20261113-v1'
ARMS = ('generic', 'execution', 'mutation')
APIS = {
 'hex_encode': dict(family='hex', target='org.apache.commons.codec.binary.Hex', call='Hex.encodeHexString(byte[])',
  marker='public static String encodeHexString(final byte[] data)',
  domain='Non-null byte arrays, 0 to 256 bytes. Return lowercase hexadecimal.'),
 'hex_decode': dict(family='hex', target='org.apache.commons.codec.binary.Hex', call='Hex.decodeHex(String)',
  marker='public static byte[] decodeHex(final String data)',
  domain='Non-null ASCII hexadecimal strings only (0-9a-fA-F), even length 0 to 512, no separators.'),
 'base64_encode': dict(family='base64', target='org.apache.commons.codec.binary.Base64', call='Base64.encodeBase64String(byte[])',
  marker='public static String encodeBase64String(final byte[] binaryData)',
  domain='Non-null byte arrays, 0 to 256 bytes. Basic standard Base64 alphabet with normal padding and no line wrapping.'),
 'base64_decode': dict(family='base64', target='org.apache.commons.codec.binary.Base64', call='Base64.decodeBase64(String)',
  marker='public static byte[] decodeBase64(final String base64String)',
  domain='Non-null canonical basic standard Base64 strings, no whitespace or URL-safe alphabet. Correct padding where required; empty string allowed. At most 256 decoded bytes. Re-encoding must equal the input.'),
 'form_encode': dict(family='form', target='org.apache.commons.codec.net.URLCodec', call='new URLCodec().encode(String, "UTF-8")',
  marker='public String encode(final String str, final String charsetName)',
  domain='Non-null well-formed Unicode strings without unpaired surrogates, UTF-8 length at most 256 bytes. Use charset "UTF-8" only. HTML form encoding: space becomes +.'),
 'form_decode': dict(family='form', target='org.apache.commons.codec.net.URLCodec', call='new URLCodec().decode(String, "UTF-8")',
  marker='public String decode(final String str, final String charsetName)',
  domain='Non-null canonical HTML form encoded strings produced by the UTF-8 form encoder: decode then re-encode must equal the input. Decoded text is well-formed Unicode with at most 256 UTF-8 bytes. Use charset "UTF-8" only.'),
}


def source_context(api):
    spec = APIS[api]
    path = SOURCE / 'src/main/java' / (spec['target'].replace('.', '/') + '.java')
    text = path.read_text(encoding='utf-8')
    start = text.index(spec['marker'])
    opening = text.index('{', start)
    depth, end = 1, opening + 1
    while depth:
        depth += (text[end] == '{') - (text[end] == '}')
        end += 1
    start = text.rfind('/**', 0, start)
    return 'Target API: ' + spec['call'] + '\nFixed focal method and Javadoc:\n' + text[start:end] + '\nInput domain:\n' + spec['domain']
