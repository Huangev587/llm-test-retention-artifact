package entry;

import java.net.URLDecoder;
import java.net.URLEncoder;
import java.nio.charset.StandardCharsets;

/** Sticky, process-local accounting for the predeclared common input domain. */
public final class Domain {
    public static volatile long calls;
    public static volatile boolean outOfDomain;

    private Domain() { }

    public static synchronized void reset() {
        calls = 0L;
        outOfDomain = false;
    }

    /** Every facade method calls this before inspecting its arguments. */
    public static synchronized void touch() {
        calls++;
    }

    public static synchronized IllegalArgumentException reject(String reason) {
        outOfDomain = true;
        return new IllegalArgumentException("OUT_OF_DOMAIN: " + reason);
    }

    public static void requireBytes(byte[] input) {
        if (input == null || input.length > 256) {
            throw reject("non-null byte array of length 0..256 required");
        }
    }

    public static void requireHex(String input) {
        if (input == null || input.length() > 512 || (input.length() & 1) != 0) {
            throw reject("non-null even-length ASCII hex of length 0..512 required");
        }
        for (int i = 0; i < input.length(); i++) {
            char value = input.charAt(i);
            if (!((value >= '0' && value <= '9') || (value >= 'a' && value <= 'f')
                    || (value >= 'A' && value <= 'F'))) {
                throw reject("ASCII hex digits required");
            }
        }
    }

    public static byte[] decodeCanonicalBase64(String input) {
        if (input == null || input.length() > 344) {
            throw reject("non-null canonical Base64 of at most 256 decoded bytes required");
        }
        byte[] decoded;
        try {
            decoded = java.util.Base64.getDecoder().decode(input);
        } catch (IllegalArgumentException invalid) {
            throw reject("standard padded Base64 without whitespace required");
        }
        if (decoded.length > 256 || !java.util.Base64.getEncoder().encodeToString(decoded).equals(input)) {
            throw reject("canonical Base64 re-encoding equality and decoded length 0..256 required");
        }
        return decoded;
    }

    public static void requireUnicode(String input) {
        if (input == null || input.length() > 256) {
            throw reject("non-null valid Unicode of at most 256 UTF-8 bytes required");
        }
        for (int i = 0; i < input.length(); i++) {
            char value = input.charAt(i);
            if (Character.isHighSurrogate(value)) {
                if (i + 1 >= input.length() || !Character.isLowSurrogate(input.charAt(i + 1))) {
                    throw reject("isolated surrogate is outside the Unicode domain");
                }
                i++;
            } else if (Character.isLowSurrogate(value)) {
                throw reject("isolated surrogate is outside the Unicode domain");
            }
        }
        if (input.getBytes(StandardCharsets.UTF_8).length > 256) {
            throw reject("at most 256 UTF-8 bytes required");
        }
    }

    public static void requireUtf8(String charsetName) {
        if (!"UTF-8".equals(charsetName)) {
            throw reject("the fixed UTF-8 charset argument is required");
        }
    }

    public static String decodeCanonicalForm(String input) {
        if (input == null || input.length() > 768) {
            throw reject("non-null canonical ASCII form encoding required");
        }
        for (int i = 0; i < input.length(); i++) {
            if (input.charAt(i) > 0x7f) {
                throw reject("canonical form encoding must be ASCII");
            }
        }
        String decoded;
        try {
            decoded = URLDecoder.decode(input, StandardCharsets.UTF_8);
        } catch (IllegalArgumentException invalid) {
            throw reject("valid form escape sequences required");
        }
        requireUnicode(decoded);
        if (!URLEncoder.encode(decoded, StandardCharsets.UTF_8).equals(input)) {
            throw reject("canonical form re-encoding equality required");
        }
        return decoded;
    }
}
