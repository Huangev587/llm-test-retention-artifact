package entry;

import org.junit.runner.JUnitCore;
import org.junit.runner.Result;
import org.junit.runner.notification.Failure;
import org.junit.runner.notification.RunListener;

/** Runs one frozen generated class under whichever binding the classpath selects. */
public final class CheckOne {
    private CheckOne() { }

    public static void main(String[] args) {
        Domain.reset();
        int runCount = 0;
        int failures = 0;
        int ignored = 0;
        final int[] assumptions = {0};
        String status = "RUNNER_ERROR";
        String mode = args.length > 1 ? args[1] : "reference";
        boolean accepted = false;
        try {
            if (args.length < 1 || args.length > 2
                    || !("reference".equals(mode) || "original".equals(mode))) {
                throw new IllegalArgumentException("Usage: CheckOne <className> [reference|original]");
            }
            JUnitCore core = new JUnitCore();
            core.addListener(new RunListener() {
                @Override
                public void testAssumptionFailure(Failure failure) {
                    assumptions[0]++;
                    System.err.println(failure.getTrace());
                }
            });
            Result result = core.run(Class.forName(args[0]));
            runCount = result.getRunCount();
            failures = result.getFailureCount();
            ignored = result.getIgnoreCount();
            for (Failure failure : result.getFailures()) {
                System.err.println(failure.getTrace());
            }
            if (Domain.outOfDomain) {
                status = "OUT_OF_DOMAIN";
            } else if (runCount == 0) {
                status = "NO_TESTS";
            } else if (failures > 0) {
                status = "JUNIT_FAILURE";
            } else if (ignored > 0 || assumptions[0] > 0) {
                status = "SKIPPED_TEST";
            } else if ("reference".equals(mode) && Domain.calls == 0L) {
                status = "NO_REFERENCE_CALLS";
            } else {
                status = "PASS";
                accepted = true;
            }
        } catch (Throwable failure) {
            failures++;
            failure.printStackTrace(System.err);
            status = Domain.outOfDomain ? "OUT_OF_DOMAIN" : "RUNNER_ERROR";
        }
        // No inputs, expectations, or reference outputs are printed in this record.
        System.out.println("CHECK_RESULT\t{\"run_count\":" + runCount
                + ",\"failures\":" + failures
                + ",\"calls\":" + Domain.calls
                + ",\"out_of_domain\":" + Domain.outOfDomain
                + ",\"ignored_count\":" + ignored
                + ",\"assumption_failures\":" + assumptions[0]
                + ",\"status\":\"" + status + "\"}");
        System.exit(accepted ? 0 : 1);
    }
}
