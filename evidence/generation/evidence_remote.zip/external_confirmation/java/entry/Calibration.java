package entry;

import java.nio.charset.StandardCharsets;
import java.security.MessageDigest;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.HexFormat;
import java.util.List;
import java.util.Locale;
import java.util.Random;
import org.apache.commons.codec.binary.Base64;
import org.apache.commons.codec.binary.Hex;
import org.apache.commons.codec.net.URLCodec;

/** Fixed preparation checks. Its corpus and outputs are never generation feedback. */
public final class Calibration {
    private static final long SEED = 20261113L;
    private static final int[] LENGTHS = {0, 1, 2, 3, 4, 7, 8, 31, 32, 63, 64, 255, 256};
    private static final String[] RFC_TEXT = {"", "f", "fo", "foo", "foob", "fooba", "foobar"};
    private static final String[] RFC_HEX = {
        "", "66", "666f", "666f6f", "666f6f62", "666f6f6261", "666f6f626172"
    };
    private static final String[] RFC_BASE64 = {
        "", "Zg==", "Zm8=", "Zm9v", "Zm9vYg==", "Zm9vYmE=", "Zm9vYmFy"
    };

    private Calibration() { }

    public static void main(String[] args) throws Exception {
        if (args.length < 1 || args.length > 2
                || (args.length == 2 && !"--negative".equals(args[1]))) {
            throw new IllegalArgumentException("Usage: Calibration <apiId> [--negative]");
        }
        String api = args[0];
        validateApi(api);
        if (args.length == 2) {
            int count = checkNegative(api);
            System.out.println("CALIBRATION_NEGATIVE\t" + api + "\t" + count);
            return;
        }
        MessageDigest digest = MessageDigest.getInstance("SHA-256");
        frame(digest, api.getBytes(StandardCharsets.US_ASCII));
        checkRfc(api, digest);
        if (api.startsWith("form_")) {
            checkFormVectors(api, digest);
            for (String input : unicodeCorpus()) {
                checkForm(api, input, digest);
            }
        } else {
            for (byte[] input : binaryCorpus()) {
                checkBinary(api, input, digest);
            }
        }
        System.out.println("CALIBRATION\t" + api + "\t" + HexFormat.of().formatHex(digest.digest()));
    }

    private static void validateApi(String api) {
        switch (api) {
            case "hex_encode": case "hex_decode":
            case "base64_encode": case "base64_decode":
            case "form_encode": case "form_decode":
                return;
            default:
                throw new IllegalArgumentException("Unknown apiId");
        }
    }

    private static void checkRfc(String api, MessageDigest digest) throws Exception {
        for (int i = 0; i < RFC_TEXT.length; i++) {
            byte[] bytes = RFC_TEXT[i].getBytes(StandardCharsets.US_ASCII);
            switch (api) {
                case "hex_encode":
                    checkAndRecord(digest, bytes, RFC_HEX[i], Hex.encodeHexString(bytes));
                    break;
                case "hex_decode":
                    checkAndRecord(digest, RFC_HEX[i], bytes, Hex.decodeHex(RFC_HEX[i]));
                    String upper = RFC_HEX[i].toUpperCase(Locale.ROOT);
                    checkAndRecord(digest, upper, bytes, Hex.decodeHex(upper));
                    break;
                case "base64_encode":
                    checkAndRecord(digest, bytes, RFC_BASE64[i], Base64.encodeBase64String(bytes));
                    break;
                case "base64_decode":
                    checkAndRecord(digest, RFC_BASE64[i], bytes, Base64.decodeBase64(RFC_BASE64[i]));
                    break;
                default:
                    // RFC 4648 vectors describe Base16/Base64, not form encoding.
                    break;
            }
        }
    }

    private static List<byte[]> binaryCorpus() {
        List<byte[]> corpus = new ArrayList<byte[]>();
        for (int value = 0; value < 256; value++) {
            corpus.add(new byte[] {(byte) value});
        }
        Random random = new Random(SEED);
        for (int length : LENGTHS) {
            for (int repeat = 0; repeat < 4; repeat++) {
                byte[] bytes = new byte[length];
                random.nextBytes(bytes);
                corpus.add(bytes);
            }
        }
        byte[] allValues = new byte[256];
        byte[] ones = new byte[256];
        Arrays.fill(ones, (byte) 0xff);
        for (int i = 0; i < allValues.length; i++) {
            allValues[i] = (byte) i;
        }
        corpus.add(allValues);
        corpus.add(new byte[256]);
        corpus.add(ones);
        return corpus;
    }

    private static void checkBinary(String api, byte[] input, MessageDigest digest) throws Exception {
        if ("hex_encode".equals(api)) {
            checkAndRecord(digest, input, HexFormat.of().formatHex(input), Hex.encodeHexString(input));
        } else if ("hex_decode".equals(api)) {
            String lower = HexFormat.of().formatHex(input);
            String upper = lower.toUpperCase(Locale.ROOT);
            StringBuilder mixed = new StringBuilder(lower);
            for (int i = 0; i < mixed.length(); i += 2) {
                mixed.setCharAt(i, Character.toUpperCase(mixed.charAt(i)));
            }
            for (String encoded : new String[] {lower, upper, mixed.toString()}) {
                checkAndRecord(digest, encoded, input, Hex.decodeHex(encoded));
            }
        } else if ("base64_encode".equals(api)) {
            checkAndRecord(digest, input, java.util.Base64.getEncoder().encodeToString(input),
                    Base64.encodeBase64String(input));
        } else if ("base64_decode".equals(api)) {
            String encoded = java.util.Base64.getEncoder().encodeToString(input);
            checkAndRecord(digest, encoded, input, Base64.decodeBase64(encoded));
        } else {
            throw new AssertionError("Wrong binary calibration API");
        }
    }

    private static List<String> unicodeCorpus() {
        List<String> corpus = new ArrayList<String>();
        corpus.addAll(Arrays.asList("", " ", "+", "%", "*.-_", "~!()'/:?&=#",
                "a b+c%20", "\u4e2d\u6587", "\u00e9e\u0301", "\ud83d\ude00",
                "\u0000\t\n\r\u007f", "\ud800\udc00", "\udbff\udfff"));
        for (int value = 0; value < 256; value++) {
            corpus.add(String.valueOf((char) value));
        }
        int[] codePoints = {'a', ' ', '+', '%', '*', '~', 0, 127,
                0x80, 0x7ff, 0x800, 0x4e2d, 0xffff, 0x10000, 0x1f600, 0x10ffff};
        Random random = new Random(SEED);
        for (int length : LENGTHS) {
            corpus.add("a".repeat(length));
            for (int repeat = 0; repeat < 4; repeat++) {
                StringBuilder input = new StringBuilder();
                int bytes = 0;
                while (bytes < length) {
                    int codePoint = codePoints[random.nextInt(codePoints.length)];
                    String next = new String(Character.toChars(codePoint));
                    int width = next.getBytes(StandardCharsets.UTF_8).length;
                    if (bytes + width > length) {
                        next = "a";
                        width = 1;
                    }
                    input.append(next);
                    bytes += width;
                }
                corpus.add(input.toString());
            }
        }
        return corpus;
    }

    private static void checkFormVectors(String api, MessageDigest digest) throws Exception {
        String[] plain = {"", "a b+c%", "\u4e2d\u6587", "\ud83d\ude00", "~", "*.-_"};
        String[] encoded = {"", "a+b%2Bc%25", "%E4%B8%AD%E6%96%87", "%F0%9F%98%80", "%7E", "*.-_"};
        URLCodec codec = new URLCodec();
        for (int i = 0; i < plain.length; i++) {
            if ("form_encode".equals(api)) {
                checkAndRecord(digest, plain[i].getBytes(StandardCharsets.UTF_8), encoded[i],
                        codec.encode(plain[i], "UTF-8"));
            } else {
                checkAndRecord(digest, encoded[i].getBytes(StandardCharsets.US_ASCII), plain[i],
                        codec.decode(encoded[i], "UTF-8"));
            }
        }
    }

    private static void checkForm(String api, String input, MessageDigest digest) throws Exception {
        URLCodec codec = new URLCodec();
        String encoded = java.net.URLEncoder.encode(input, StandardCharsets.UTF_8);
        if ("form_encode".equals(api)) {
            checkAndRecord(digest, input.getBytes(StandardCharsets.UTF_8), encoded,
                    codec.encode(input, "UTF-8"));
        } else {
            checkAndRecord(digest, encoded.getBytes(StandardCharsets.US_ASCII), input,
                    codec.decode(encoded, "UTF-8"));
        }
    }

    private static void checkAndRecord(MessageDigest digest, byte[] input,
            String expected, String actual) {
        if (!expected.equals(actual)) {
            throw new AssertionError("Calibration output mismatch");
        }
        frame(digest, input);
        frame(digest, actual.getBytes(StandardCharsets.UTF_8));
    }

    private static void checkAndRecord(MessageDigest digest, String input,
            byte[] expected, byte[] actual) {
        if (!Arrays.equals(expected, actual)) {
            throw new AssertionError("Calibration byte output mismatch");
        }
        frame(digest, input.getBytes(StandardCharsets.US_ASCII));
        frame(digest, actual);
    }

    private static void frame(MessageDigest digest, byte[] bytes) {
        int length = bytes.length;
        digest.update((byte) (length >>> 24));
        digest.update((byte) (length >>> 16));
        digest.update((byte) (length >>> 8));
        digest.update((byte) length);
        digest.update(bytes);
    }

    private interface ThrowingCall {
        void run() throws Exception;
    }

    private static int checkNegative(String api) throws Exception {
        List<ThrowingCall> calls = new ArrayList<ThrowingCall>();
        switch (api) {
            case "hex_encode":
                calls.add(() -> Hex.encodeHexString((byte[]) null));
                calls.add(() -> Hex.encodeHexString(new byte[257]));
                break;
            case "hex_decode":
                for (String input : new String[] {null, "0", "gg", "\uff26\uff26", "00\n", "0x", "0".repeat(514)}) {
                    calls.add(() -> Hex.decodeHex(input));
                }
                break;
            case "base64_encode":
                calls.add(() -> Base64.encodeBase64String(null));
                calls.add(() -> Base64.encodeBase64String(new byte[257]));
                break;
            case "base64_decode":
                for (String input : new String[] {null, "Zg", "Zg=", "Zg===", "Zh==", "Zg==\n",
                        "SGVsbG8_", "=", "%%%%", java.util.Base64.getEncoder().encodeToString(new byte[257])}) {
                    calls.add(() -> Base64.decodeBase64(input));
                }
                break;
            case "form_encode":
                for (String input : new String[] {null, "\ud800", "\udc00", "a\ud800x", "\ud800\ud800",
                        "a".repeat(257), "\u4e2d".repeat(86)}) {
                    calls.add(() -> new URLCodec().encode(input, "UTF-8"));
                }
                calls.add(() -> new URLCodec().encode("a", "ISO-8859-1"));
                calls.add(() -> new URLCodec().encode("a", null));
                break;
            case "form_decode":
                for (String input : new String[] {null, "%", "%GG", "%ff", "%FF", "%41", "%20", "%2b",
                        "\u00e9", "\ud800", "%C0%AF", "a".repeat(257), "%".repeat(769)}) {
                    calls.add(() -> new URLCodec().decode(input, "UTF-8"));
                }
                calls.add(() -> new URLCodec().decode("a", "ISO-8859-1"));
                calls.add(() -> new URLCodec().decode("a", null));
                break;
            default:
                throw new AssertionError("Unknown negative calibration API");
        }
        Class<?> domain = Class.forName("entry.Domain");
        for (ThrowingCall call : calls) {
            domain.getMethod("reset").invoke(null);
            boolean thrown = false;
            try {
                call.run();
            } catch (Exception expected) {
                thrown = true;
            }
            if (!thrown || !domain.getField("outOfDomain").getBoolean(null)
                    || domain.getField("calls").getLong(null) != 1L) {
                throw new AssertionError("Invalid input did not set exactly one reference call and sticky domain flag");
            }
        }
        return calls.size();
    }
}
