package org.apache.commons.codec.net;

import entry.Domain;
import java.io.UnsupportedEncodingException;
import java.net.URLEncoder;
import java.nio.charset.StandardCharsets;
import org.apache.commons.codec.DecoderException;

/** Restricted reference for form encoding, with the original checked signatures. */
public final class URLCodec {
    public URLCodec() { }

    public String encode(String input, String charsetName) throws UnsupportedEncodingException {
        Domain.touch();
        Domain.requireUtf8(charsetName);
        Domain.requireUnicode(input);
        return URLEncoder.encode(input, StandardCharsets.UTF_8);
    }

    public String decode(String input, String charsetName)
            throws DecoderException, UnsupportedEncodingException {
        Domain.touch();
        Domain.requireUtf8(charsetName);
        return Domain.decodeCanonicalForm(input);
    }
}
