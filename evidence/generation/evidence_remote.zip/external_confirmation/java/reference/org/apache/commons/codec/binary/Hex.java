package org.apache.commons.codec.binary;

import entry.Domain;
import java.util.HexFormat;
import org.apache.commons.codec.DecoderException;

/** Restricted JDK reference facade; only the two frozen target signatures exist. */
public final class Hex {
    private Hex() { }

    public static String encodeHexString(byte[] input) {
        Domain.touch();
        Domain.requireBytes(input);
        return HexFormat.of().formatHex(input);
    }

    public static byte[] decodeHex(String input) throws DecoderException {
        Domain.touch();
        Domain.requireHex(input);
        return HexFormat.of().parseHex(input);
    }
}
