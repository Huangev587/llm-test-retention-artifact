package entry;
import org.junit.Test;
import org.junit.Assert;
import static org.junit.Assert.*;
import java.nio.charset.StandardCharsets;
import org.apache.commons.codec.binary.Hex;
import org.apache.commons.codec.binary.Base64;
import org.apache.commons.codec.net.URLCodec;
public class Case_028435aacb5826c7e0515395a1865c4d {
@Test
public void testEncodeSingleByte() throws Exception {
    byte[] input = {72};
    String result = Base64.encodeBase64URLSafeString(input);
    assertEquals("aA", result);
}
}
