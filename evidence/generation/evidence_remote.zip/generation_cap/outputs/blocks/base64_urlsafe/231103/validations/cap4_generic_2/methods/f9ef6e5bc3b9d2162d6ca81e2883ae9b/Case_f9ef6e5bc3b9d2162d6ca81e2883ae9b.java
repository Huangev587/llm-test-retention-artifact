package entry;
import org.junit.Test;
import org.junit.Assert;
import static org.junit.Assert.*;
import java.nio.charset.StandardCharsets;
import org.apache.commons.codec.binary.Hex;
import org.apache.commons.codec.binary.Base64;
import org.apache.commons.codec.net.URLCodec;
public class Case_f9ef6e5bc3b9d2162d6ca81e2883ae9b {
@Test
public void testEncodeMultipleBytes() throws Exception {
    byte[] input = "Hello, World!".getBytes(StandardCharsets.UTF_8);
    String result = Base64.encodeBase64URLSafeString(input);
    assertEquals("SGVsbG8sIFdvcmxkIQ", result);
}
}
