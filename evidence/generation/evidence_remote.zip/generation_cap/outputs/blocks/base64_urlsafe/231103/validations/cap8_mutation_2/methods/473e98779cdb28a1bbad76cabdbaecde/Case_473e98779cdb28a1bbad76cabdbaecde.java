package entry;
import org.junit.Test;
import org.junit.Assert;
import static org.junit.Assert.*;
import java.nio.charset.StandardCharsets;
import org.apache.commons.codec.binary.Hex;
import org.apache.commons.codec.binary.Base64;
import org.apache.commons.codec.net.URLCodec;
public class Case_473e98779cdb28a1bbad76cabdbaecde {
@Test
public void testEncodeMixedCharacters() throws Exception {
    byte[] input = {72, 101, 108, 108, 111, 32, 87, 111, 114, 108, 100};
    String result = Base64.encodeBase64URLSafeString(input);
    assertEquals("SGVsbG8gV29ybGQ=", result);
}
}
