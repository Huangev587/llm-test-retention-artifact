package entry;
import org.junit.Test;
import org.junit.Assert;
import static org.junit.Assert.*;
import java.nio.charset.StandardCharsets;
import org.apache.commons.codec.binary.Hex;
import org.apache.commons.codec.binary.Base64;
import org.apache.commons.codec.net.URLCodec;
public class Case_d51d6c88ca78301412759bad5364ae93 {
@Test
public void testEncodeLargePositiveValues() throws Exception {
    byte[] input = new byte[]{127, 128, 129, 130, 131};
    String result = Base64.encodeBase64URLSafeString(input);
    assertEquals("w7c=", result);
}
}
