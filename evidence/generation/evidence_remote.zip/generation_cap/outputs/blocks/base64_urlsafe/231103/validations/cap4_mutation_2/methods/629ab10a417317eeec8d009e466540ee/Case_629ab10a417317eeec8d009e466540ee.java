package entry;
import org.junit.Test;
import org.junit.Assert;
import static org.junit.Assert.*;
import java.nio.charset.StandardCharsets;
import org.apache.commons.codec.binary.Hex;
import org.apache.commons.codec.binary.Base64;
import org.apache.commons.codec.net.URLCodec;
public class Case_629ab10a417317eeec8d009e466540ee {
@Test
public void testEncodeNegativeValues() throws Exception {
    byte[] input = {-1, -2, -3, -4, -5, -6, -7, -8, -9, -10};
    String result = Base64.encodeBase64URLSafeString(input);
    assertEquals("/+ADwQEBAUHCAkP/w==", result);
}
}
