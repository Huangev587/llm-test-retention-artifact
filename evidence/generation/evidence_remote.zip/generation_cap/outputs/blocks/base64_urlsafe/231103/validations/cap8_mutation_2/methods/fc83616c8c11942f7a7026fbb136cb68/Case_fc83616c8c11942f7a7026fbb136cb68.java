package entry;
import org.junit.Test;
import org.junit.Assert;
import static org.junit.Assert.*;
import java.nio.charset.StandardCharsets;
import org.apache.commons.codec.binary.Hex;
import org.apache.commons.codec.binary.Base64;
import org.apache.commons.codec.net.URLCodec;
public class Case_fc83616c8c11942f7a7026fbb136cb68 {
@Test
public void testEncodeRandomValues() throws Exception {
    byte[] input = {10, 255, 128, 64, 32};
    String result = Base64.encodeBase64URLSafeString(input);
    assertEquals("Kw==_AIA", result);
}
}
