package entry;
import org.junit.Test;
import org.junit.Assert;
import static org.junit.Assert.*;
import java.nio.charset.StandardCharsets;
import org.apache.commons.codec.binary.Hex;
import org.apache.commons.codec.binary.Base64;
import org.apache.commons.codec.net.URLCodec;
public class Case_e76ee5f18da0addbae1c68bf6ea3be1b {
@Test
public void testEncodeMultipleBytes() throws Exception {
    byte[] input = {10, 20, 30};
    String result = Base64.encodeBase64URLSafeString(input);
    assertEquals("JDA=", result);
}
}
