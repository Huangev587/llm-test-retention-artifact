package entry;
import org.junit.Test;
import org.junit.Assert;
import static org.junit.Assert.*;
import java.nio.charset.StandardCharsets;
import org.apache.commons.codec.binary.Hex;
import org.apache.commons.codec.binary.Base64;
import org.apache.commons.codec.net.URLCodec;
public class Case_178b1c82116c4f7e569242289399051f {
@Test
public void testEncodeMixedValues() throws Exception {
    byte[] input = new byte[]{1, -2, 3, -4, 5};
    String result = Base64.encodeBase64URLSafeString(input);
    assertEquals("AQIADgE=", result);
}
}
