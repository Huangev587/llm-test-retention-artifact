package entry;
import org.junit.Test;
import org.junit.Assert;
import static org.junit.Assert.*;
import java.nio.charset.StandardCharsets;
import org.apache.commons.codec.binary.Hex;
import org.apache.commons.codec.binary.Base64;
import org.apache.commons.codec.net.URLCodec;
public class Case_75ccd0d67799d6078157357f59deb7c8 {
@Test
public void testEncodeSingleByte() throws Exception {
    byte[] input = {10};
    String result = Base64.encodeBase64URLSafeString(input);
    assertEquals("KQ", result);
}
}
