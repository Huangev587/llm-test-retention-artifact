package entry;
import org.junit.Test;
import org.junit.Assert;
import static org.junit.Assert.*;
import java.nio.charset.StandardCharsets;
import org.apache.commons.codec.binary.Hex;
import org.apache.commons.codec.binary.Base64;
import org.apache.commons.codec.net.URLCodec;
public class Case_8cdef8ba9193b7075c33517458191b39 {
@Test
public void testSingleByte() {
    byte[] input = {65};
    assertEquals("A", Base64.encodeBase64URLSafeString(input));
}
}
