package entry;
import org.junit.Test;
import org.junit.Assert;
import static org.junit.Assert.*;
import java.nio.charset.StandardCharsets;
import org.apache.commons.codec.binary.Hex;
import org.apache.commons.codec.binary.Base64;
import org.apache.commons.codec.net.URLCodec;
public class Case_90807d4afef88da1bb9dc289a447a9fb {
@Test
public void testNineBytes() {
    byte[] input = {10, 11, 12, 13, 14, 15, 16, 17, 18};
    assertEquals("AQIIIAIIIAQ", Base64.encodeBase64URLSafeString(input));
}
}
