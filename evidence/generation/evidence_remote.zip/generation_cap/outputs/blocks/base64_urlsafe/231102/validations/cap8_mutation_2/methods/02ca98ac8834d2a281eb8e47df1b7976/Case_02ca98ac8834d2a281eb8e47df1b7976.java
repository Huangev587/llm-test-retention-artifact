package entry;
import org.junit.Test;
import org.junit.Assert;
import static org.junit.Assert.*;
import java.nio.charset.StandardCharsets;
import org.apache.commons.codec.binary.Hex;
import org.apache.commons.codec.binary.Base64;
import org.apache.commons.codec.net.URLCodec;
public class Case_02ca98ac8834d2a281eb8e47df1b7976 {
@Test
public void testFourBytes() {
    byte[] input = {10, 11, 12, 13};
    assertEquals("AQIII", Base64.encodeBase64URLSafeString(input));
}
}
