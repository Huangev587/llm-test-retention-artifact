package entry;
import org.junit.Test;
import org.junit.Assert;
import static org.junit.Assert.*;
import java.nio.charset.StandardCharsets;
import org.apache.commons.codec.binary.Hex;
import org.apache.commons.codec.binary.Base64;
import org.apache.commons.codec.net.URLCodec;
public class Case_c93e8d896fe35946d8285518bbd687a8 {
@Test
public void testTwoBytes() {
    byte[] input = {0, 1};
    assertEquals("AA", Base64.encodeBase64URLSafeString(input));
}
}
