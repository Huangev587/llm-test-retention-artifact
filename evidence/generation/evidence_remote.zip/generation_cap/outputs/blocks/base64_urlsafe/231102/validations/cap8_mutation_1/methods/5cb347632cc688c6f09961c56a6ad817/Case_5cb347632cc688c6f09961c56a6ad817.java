package entry;
import org.junit.Test;
import org.junit.Assert;
import static org.junit.Assert.*;
import java.nio.charset.StandardCharsets;
import org.apache.commons.codec.binary.Hex;
import org.apache.commons.codec.binary.Base64;
import org.apache.commons.codec.net.URLCodec;
public class Case_5cb347632cc688c6f09961c56a6ad817 {
@Test
public void testFourBytes() {
    byte[] input = {65, 66, 67, 68};
    assertEquals("ABCD", Base64.encodeBase64URLSafeString(input));
}
}
