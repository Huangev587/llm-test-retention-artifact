package entry;
import org.junit.Test;
import org.junit.Assert;
import static org.junit.Assert.*;
import java.nio.charset.StandardCharsets;
import org.apache.commons.codec.binary.Hex;
import org.apache.commons.codec.binary.Base64;
import org.apache.commons.codec.net.URLCodec;
public class Case_cedecadd0294e12f5bd20fc6b541d054 {
@Test
public void testNineBytes() {
    byte[] input = {0, 1, 2, 3, 4, 5, 6, 7, 8};
    assertEquals("AAAAAAAAA", Base64.encodeBase64URLSafeString(input));
}
}
