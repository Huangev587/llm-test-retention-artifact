package entry;
import org.junit.Test;
import org.junit.Assert;
import static org.junit.Assert.*;
import java.nio.charset.StandardCharsets;
import org.apache.commons.codec.binary.Hex;
import org.apache.commons.codec.binary.Base64;
import org.apache.commons.codec.net.URLCodec;
public class Case_a69c23ec8d0069bf758072aa0667f11d {
@Test
public void testSingleByte() {
    byte[] input = { 0 };
    assertEquals("A", Base64.encodeBase64URLSafeString(input));
}
}
