package entry;
import org.junit.Test;
import org.junit.Assert;
import static org.junit.Assert.*;
import java.nio.charset.StandardCharsets;
import org.apache.commons.codec.binary.Hex;
import org.apache.commons.codec.binary.Base64;
import org.apache.commons.codec.net.URLCodec;
public class Case_916f6c8db69e62b67492f0ff38c984de {
@Test
public void testMixedValues() {
    byte[] input = { -128, -64, 0, 63, 127 };
    assertEquals("-_ABc", Base64.encodeBase64URLSafeString(input));
}
}
