package entry;
import org.junit.Test;
import org.junit.Assert;
import static org.junit.Assert.*;
import java.nio.charset.StandardCharsets;
import org.apache.commons.codec.binary.Hex;
import org.apache.commons.codec.binary.Base64;
import org.apache.commons.codec.net.URLCodec;
public class Case_bf001fe04737b6a083beaa2ed0638395 {
@Test
public void testFourBytes() throws Exception {
    byte[] input = { 0, 1, 2, 3 };
    assertEquals("AAECAwQ=", Base64.encodeBase64URLSafeString(input));
}
}
