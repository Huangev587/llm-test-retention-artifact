package entry;
import org.junit.Test;
import org.junit.Assert;
import static org.junit.Assert.*;
import java.nio.charset.StandardCharsets;
import org.apache.commons.codec.binary.Hex;
import org.apache.commons.codec.binary.Base64;
import org.apache.commons.codec.net.URLCodec;
public class Case_547f76384237c85d42f4d3c52e9e3f07 {
@Test
public void testTwoBytes() {
    byte[] input = {65, 66};
    assertEquals("AB", Base64.encodeBase64URLSafeString(input));
}
}
