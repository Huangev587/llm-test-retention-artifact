package entry;
import org.junit.Test;
import org.junit.Assert;
import static org.junit.Assert.*;
import java.nio.charset.StandardCharsets;
import org.apache.commons.codec.binary.Hex;
import org.apache.commons.codec.binary.Base64;
import org.apache.commons.codec.net.URLCodec;
public class Case_0da20b810b21c1be7c0ff96ce26337b4 {
@Test
public void testRandomBytes() throws Exception {
    byte[] input = { (byte) 123, (byte) 45, (byte) 67, (byte) 89, (byte) 10, (byte) 11, (byte) 12, (byte) 13 };
    assertEquals("CjU1Ng==", Base64.encodeBase64URLSafeString(input));
}
}
