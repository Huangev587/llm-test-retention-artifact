package entry;
import org.junit.Test;
import org.junit.Assert;
import static org.junit.Assert.*;
import java.nio.charset.StandardCharsets;
import org.apache.commons.codec.binary.Hex;
import org.apache.commons.codec.binary.Base64;
import org.apache.commons.codec.net.URLCodec;
public class Case_77c70f6013dcf565334a243b4e4b9254 {
@Test
public void testThreeBytes() {
    byte[] input = {0, 1, 2};
    assertEquals("AAA", Base64.encodeBase64URLSafeString(input));
}
}
