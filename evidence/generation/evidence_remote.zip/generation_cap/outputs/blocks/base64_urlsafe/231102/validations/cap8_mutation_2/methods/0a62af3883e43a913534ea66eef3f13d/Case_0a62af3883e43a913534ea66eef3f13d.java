package entry;
import org.junit.Test;
import org.junit.Assert;
import static org.junit.Assert.*;
import java.nio.charset.StandardCharsets;
import org.apache.commons.codec.binary.Hex;
import org.apache.commons.codec.binary.Base64;
import org.apache.commons.codec.net.URLCodec;
public class Case_0a62af3883e43a913534ea66eef3f13d {
@Test
public void testOneByte() {
    byte[] input = {10};
    assertEquals("AA", Base64.encodeBase64URLSafeString(input));
}
}
