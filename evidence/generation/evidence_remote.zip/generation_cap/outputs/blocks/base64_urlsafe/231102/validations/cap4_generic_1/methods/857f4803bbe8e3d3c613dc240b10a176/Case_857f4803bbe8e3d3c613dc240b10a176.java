package entry;
import org.junit.Test;
import org.junit.Assert;
import static org.junit.Assert.*;
import java.nio.charset.StandardCharsets;
import org.apache.commons.codec.binary.Hex;
import org.apache.commons.codec.binary.Base64;
import org.apache.commons.codec.net.URLCodec;
public class Case_857f4803bbe8e3d3c613dc240b10a176 {
@Test
public void testThreeBytes() {
    byte[] input = { 0, 1, 2 };
    assertEquals("AAECBA==", Base64.encodeBase64URLSafeString(input));
}
}
