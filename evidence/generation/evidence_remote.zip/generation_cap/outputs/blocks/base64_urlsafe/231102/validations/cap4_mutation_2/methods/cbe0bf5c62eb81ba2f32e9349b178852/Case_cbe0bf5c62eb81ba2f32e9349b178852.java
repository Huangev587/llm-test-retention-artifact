package entry;
import org.junit.Test;
import org.junit.Assert;
import static org.junit.Assert.*;
import java.nio.charset.StandardCharsets;
import org.apache.commons.codec.binary.Hex;
import org.apache.commons.codec.binary.Base64;
import org.apache.commons.codec.net.URLCodec;
public class Case_cbe0bf5c62eb81ba2f32e9349b178852 {
@Test
public void testThreeBytes() throws Exception {
    byte[] input = { 0, 1, 2 };
    assertEquals("AAECBA", Base64.encodeBase64URLSafeString(input));
}
}
