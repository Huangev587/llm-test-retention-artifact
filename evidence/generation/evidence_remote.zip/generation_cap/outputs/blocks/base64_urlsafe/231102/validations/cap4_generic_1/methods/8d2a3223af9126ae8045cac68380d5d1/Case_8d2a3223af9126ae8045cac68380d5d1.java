package entry;
import org.junit.Test;
import org.junit.Assert;
import static org.junit.Assert.*;
import java.nio.charset.StandardCharsets;
import org.apache.commons.codec.binary.Hex;
import org.apache.commons.codec.binary.Base64;
import org.apache.commons.codec.net.URLCodec;
public class Case_8d2a3223af9126ae8045cac68380d5d1 {
@Test
public void testMultipleBytes() {
    byte[] input = "Hello, World!".getBytes(StandardCharsets.UTF_8);
    assertEquals("SGVsbG8sIFdvcmxkIQ==", Base64.encodeBase64URLSafeString(input));
}
}
