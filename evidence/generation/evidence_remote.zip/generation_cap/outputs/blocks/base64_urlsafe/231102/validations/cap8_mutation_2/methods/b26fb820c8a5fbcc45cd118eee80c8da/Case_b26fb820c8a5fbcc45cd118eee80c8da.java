package entry;
import org.junit.Test;
import org.junit.Assert;
import static org.junit.Assert.*;
import java.nio.charset.StandardCharsets;
import org.apache.commons.codec.binary.Hex;
import org.apache.commons.codec.binary.Base64;
import org.apache.commons.codec.net.URLCodec;
public class Case_b26fb820c8a5fbcc45cd118eee80c8da {
@Test
public void testThreeBytes() {
    byte[] input = {10, 11, 12};
    assertEquals("AQII", Base64.encodeBase64URLSafeString(input));
}
}
