package entry;
import org.junit.Test;
import org.junit.Assert;
import static org.junit.Assert.*;
import java.nio.charset.StandardCharsets;
import org.apache.commons.codec.binary.Hex;
import org.apache.commons.codec.binary.Base64;
import org.apache.commons.codec.net.URLCodec;
public class Case_b7f4e61ca98d2f95b259eb9777682529 {
@Test
public void testNineBytes() {
    byte[] input = {65, 66, 67, 68, 69, 70, 71, 72, 73};
    assertEquals("ABCDEFGH", Base64.encodeBase64URLSafeString(input));
}
}
