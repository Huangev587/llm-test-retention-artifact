package entry;
import org.junit.Test;
import org.junit.Assert;
import static org.junit.Assert.*;
import java.nio.charset.StandardCharsets;
import org.apache.commons.codec.binary.Hex;
import org.apache.commons.codec.binary.Base64;
import org.apache.commons.codec.net.URLCodec;
public class Case_c173b03fdb058cde01f345a50ae03ed0 {
@Test
public void testTwoBytes() {
    byte[] input = {10, 11};
    assertEquals("AQI", Base64.encodeBase64URLSafeString(input));
}
}
