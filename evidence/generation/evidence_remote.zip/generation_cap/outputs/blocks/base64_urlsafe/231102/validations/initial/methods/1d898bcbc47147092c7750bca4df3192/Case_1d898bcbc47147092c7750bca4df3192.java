package entry;
import org.junit.Test;
import org.junit.Assert;
import static org.junit.Assert.*;
import java.nio.charset.StandardCharsets;
import org.apache.commons.codec.binary.Hex;
import org.apache.commons.codec.binary.Base64;
import org.apache.commons.codec.net.URLCodec;
public class Case_1d898bcbc47147092c7750bca4df3192 {
@Test
public void testEmptyArray() {
    byte[] input = {};
    assertEquals("", Base64.encodeBase64URLSafeString(input));
}
}
