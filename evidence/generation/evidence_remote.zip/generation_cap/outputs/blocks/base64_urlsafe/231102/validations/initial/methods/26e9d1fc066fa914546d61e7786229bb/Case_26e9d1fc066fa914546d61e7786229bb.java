package entry;
import org.junit.Test;
import org.junit.Assert;
import static org.junit.Assert.*;
import java.nio.charset.StandardCharsets;
import org.apache.commons.codec.binary.Hex;
import org.apache.commons.codec.binary.Base64;
import org.apache.commons.codec.net.URLCodec;
public class Case_26e9d1fc066fa914546d61e7786229bb {
@Test
public void testFourBytes() {
    byte[] input = {0, 1, 2, 3};
    assertEquals("AAAA", Base64.encodeBase64URLSafeString(input));
}
}
