package entry;
import org.junit.Test;
import org.junit.Assert;
import static org.junit.Assert.*;
import java.nio.charset.StandardCharsets;
import org.apache.commons.codec.binary.Hex;
import org.apache.commons.codec.binary.Base64;
import org.apache.commons.codec.net.URLCodec;
public class Case_2988ef793f0c0de27545bfbff39f6979 {
@Test
public void testTwoBytes() {
    byte[] input = { 0, 1 };
    assertEquals("AAE", Base64.encodeBase64URLSafeString(input));
}
}
