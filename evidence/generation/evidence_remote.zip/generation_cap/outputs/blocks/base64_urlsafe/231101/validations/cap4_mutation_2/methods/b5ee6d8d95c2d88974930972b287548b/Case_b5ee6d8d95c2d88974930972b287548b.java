package entry;
import org.junit.Test;
import org.junit.Assert;
import static org.junit.Assert.*;
import java.nio.charset.StandardCharsets;
import org.apache.commons.codec.binary.Hex;
import org.apache.commons.codec.binary.Base64;
import org.apache.commons.codec.net.URLCodec;
public class Case_b5ee6d8d95c2d88974930972b287548b {
@Test public void testEncodeSixBytes() { 
    final byte[] input = new byte[]{7, 8, 9, 10, 11, 12}; 
    assertEquals("BwMDAA==", Base64.encodeBase64URLSafeString(input)); 
}
}
