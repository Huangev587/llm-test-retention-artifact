package entry;
import org.junit.Test;
import org.junit.Assert;
import static org.junit.Assert.*;
import java.nio.charset.StandardCharsets;
import org.apache.commons.codec.binary.Hex;
import org.apache.commons.codec.binary.Base64;
import org.apache.commons.codec.net.URLCodec;
public class Case_932a0dd7feaa359cc328c520931af4e7 {
@Test public void testEncodeTwoBytes() throws Exception {
    byte[] input = { 0x41, 0x42 };
    assertEquals("QkI", Base64.encodeBase64URLSafeString(input));
}
}
