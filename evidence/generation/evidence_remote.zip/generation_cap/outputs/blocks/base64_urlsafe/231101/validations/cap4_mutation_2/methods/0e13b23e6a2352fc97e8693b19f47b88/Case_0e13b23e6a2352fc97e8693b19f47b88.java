package entry;
import org.junit.Test;
import org.junit.Assert;
import static org.junit.Assert.*;
import java.nio.charset.StandardCharsets;
import org.apache.commons.codec.binary.Hex;
import org.apache.commons.codec.binary.Base64;
import org.apache.commons.codec.net.URLCodec;
public class Case_0e13b23e6a2352fc97e8693b19f47b88 {
@Test public void testEncodeTwentyBytes() { 
    final byte[] input = new byte[]{23, 24, 25, 26, 27, 28, 29, 30, 31, 32, 33, 34, 35, 36, 37, 38, 39, 40, 41, 42}; 
    assertEquals("EQFGHIAAAAAAAAAAAAAAAA==", Base64.encodeBase64URLSafeString(input)); 
}
}
