package entry;
import org.junit.Test;
import org.junit.Assert;
import static org.junit.Assert.*;
import java.nio.charset.StandardCharsets;
import org.apache.commons.codec.binary.Hex;
import org.apache.commons.codec.binary.Base64;
import org.apache.commons.codec.net.URLCodec;
public class Case_cba3ebb20d506086b37179730ccec5f7 {
@Test public void testEncodeLongerArray() throws Exception {
    byte[] input = "Hello, World!".getBytes(StandardCharsets.UTF_8);
    assertEquals("SGVsbG8sIFdvcmxkIQ", Base64.encodeBase64URLSafeString(input));
}
}
