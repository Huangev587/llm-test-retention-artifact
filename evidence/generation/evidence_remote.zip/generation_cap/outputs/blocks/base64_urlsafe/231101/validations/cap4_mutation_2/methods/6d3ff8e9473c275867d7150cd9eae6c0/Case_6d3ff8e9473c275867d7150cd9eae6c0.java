package entry;
import org.junit.Test;
import org.junit.Assert;
import static org.junit.Assert.*;
import java.nio.charset.StandardCharsets;
import org.apache.commons.codec.binary.Hex;
import org.apache.commons.codec.binary.Base64;
import org.apache.commons.codec.net.URLCodec;
public class Case_6d3ff8e9473c275867d7150cd9eae6c0 {
@Test public void testEncodeSingleByte() { 
    final byte[] input = new byte[]{0}; 
    assertEquals("A", Base64.encodeBase64URLSafeString(input)); 
}
}
