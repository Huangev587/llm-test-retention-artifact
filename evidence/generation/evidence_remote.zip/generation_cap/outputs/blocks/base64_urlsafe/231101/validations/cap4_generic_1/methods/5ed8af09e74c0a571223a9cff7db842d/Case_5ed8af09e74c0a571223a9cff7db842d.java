package entry;
import org.junit.Test;
import org.junit.Assert;
import static org.junit.Assert.*;
import java.nio.charset.StandardCharsets;
import org.apache.commons.codec.binary.Hex;
import org.apache.commons.codec.binary.Base64;
import org.apache.commons.codec.net.URLCodec;
public class Case_5ed8af09e74c0a571223a9cff7db842d {
@Test public void testEncodeSmallArray() throws Exception {
    byte[] input = { 0x41, 0x42, 0x43 };
    assertEquals("QmMj", Base64.encodeBase64URLSafeString(input));
}
}
