package entry;
import org.junit.Test;
import org.junit.Assert;
import static org.junit.Assert.*;
import java.nio.charset.StandardCharsets;
import org.apache.commons.codec.binary.Hex;
import org.apache.commons.codec.binary.Base64;
import org.apache.commons.codec.net.URLCodec;
public class Case_eb3268021628a599096ba536cb5ea584 {
@Test public void testEncodeNegativeBytes() throws Exception {
    byte[] input = { -1, -2, -3 };
    assertEquals("-_-", Base64.encodeBase64URLSafeString(input));
}
}
