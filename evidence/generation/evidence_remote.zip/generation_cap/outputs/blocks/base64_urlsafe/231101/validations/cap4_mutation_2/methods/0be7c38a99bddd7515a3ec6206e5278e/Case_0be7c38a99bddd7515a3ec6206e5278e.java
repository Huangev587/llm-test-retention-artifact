package entry;
import org.junit.Test;
import org.junit.Assert;
import static org.junit.Assert.*;
import java.nio.charset.StandardCharsets;
import org.apache.commons.codec.binary.Hex;
import org.apache.commons.codec.binary.Base64;
import org.apache.commons.codec.net.URLCodec;
public class Case_0be7c38a99bddd7515a3ec6206e5278e {
@Test public void testEncodeTenBytes() { 
    final byte[] input = new byte[]{13, 14, 15, 16, 17, 18, 19, 20, 21, 22}; 
    assertEquals("DQEFCQ==", Base64.encodeBase64URLSafeString(input)); 
}
}
