package entry;
import org.junit.Test;
import org.junit.Assert;
import static org.junit.Assert.*;
import java.nio.charset.StandardCharsets;
import org.apache.commons.codec.binary.Hex;
import org.apache.commons.codec.binary.Base64;
import org.apache.commons.codec.net.URLCodec;
public class Case_fa555686f7af4c730da97e1ffb01d604 {
@Test public void testEncodeFourBytes() { 
    final byte[] input = new byte[]{3, 4, 5, 6}; 
    assertEquals("AwEBAg==", Base64.encodeBase64URLSafeString(input)); 
}
}
