package entry;
import org.junit.Test;
import org.junit.Assert;
import static org.junit.Assert.*;
import java.nio.charset.StandardCharsets;
import org.apache.commons.codec.binary.Hex;
import org.apache.commons.codec.binary.Base64;
import org.apache.commons.codec.net.URLCodec;
public class Case_8ae7995b2a74568757ba6064647145d8 {
@Test public void testEncodeMixedBytes() throws Exception {
    byte[] input = { 0x00, 0x7F, (byte) 0x80, (byte) 0xFF };
    assertEquals("AA7fCg==", Base64.encodeBase64URLSafeString(input));
}
}
