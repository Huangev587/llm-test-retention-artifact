package entry;
import org.junit.Test;
import org.junit.Assert;
import static org.junit.Assert.*;
import java.nio.charset.StandardCharsets;
import org.apache.commons.codec.binary.Hex;
import org.apache.commons.codec.binary.Base64;
import org.apache.commons.codec.net.URLCodec;
public class Case_9b4048dd390cb73626126c9d9558c19f {
@Test public void testEncodeThreeBytes() throws Exception {
    byte[] input = { 0x41, 0x42, 0x43 };
    assertEquals("QklD", Base64.encodeBase64URLSafeString(input));
}
}
