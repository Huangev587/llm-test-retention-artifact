package entry;
import org.junit.Test;
import org.junit.Assert;
import static org.junit.Assert.*;
import java.nio.charset.StandardCharsets;
import org.apache.commons.codec.binary.Hex;
import org.apache.commons.codec.binary.Base64;
import org.apache.commons.codec.net.URLCodec;
public class Case_83fd0e286be7762435b808bdec5022c3 {
@Test public void testEncodeTwoBytes() { 
    final byte[] input = new byte[]{1, 2}; 
    assertEquals("AQI", Base64.encodeBase64URLSafeString(input)); 
}
}
