package entry;
import org.junit.Test;
import org.junit.Assert;
import static org.junit.Assert.*;
import java.nio.charset.StandardCharsets;
import org.apache.commons.codec.binary.Hex;
import org.apache.commons.codec.binary.Base64;
import org.apache.commons.codec.net.URLCodec;
public class Case_73338760f308cd19f5efe3a61598faed {
@Test public void testEncodeSingleByte() throws Exception {
    byte[] input = { 0x41 };
    assertEquals("QQ", Base64.encodeBase64URLSafeString(input));
}
}
