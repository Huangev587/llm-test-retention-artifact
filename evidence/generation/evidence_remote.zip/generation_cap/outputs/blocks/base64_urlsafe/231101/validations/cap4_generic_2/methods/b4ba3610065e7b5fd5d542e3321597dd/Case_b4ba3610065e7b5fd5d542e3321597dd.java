package entry;
import org.junit.Test;
import org.junit.Assert;
import static org.junit.Assert.*;
import java.nio.charset.StandardCharsets;
import org.apache.commons.codec.binary.Hex;
import org.apache.commons.codec.binary.Base64;
import org.apache.commons.codec.net.URLCodec;
public class Case_b4ba3610065e7b5fd5d542e3321597dd {
@Test public void testEncodeFourBytes() throws Exception {
    byte[] input = { 0x41, 0x42, 0x43, 0x44 };
    assertEquals("QklEMQ", Base64.encodeBase64URLSafeString(input));
}
}
