package entry;
import org.junit.Test;
import org.junit.Assert;
import static org.junit.Assert.*;
import java.nio.charset.StandardCharsets;
import org.apache.commons.codec.binary.Hex;
import org.apache.commons.codec.binary.Base64;
import org.apache.commons.codec.net.URLCodec;
public class Case_a1e9bed2d0cf27a34eb761421746a089 {
@Test public void testEncodeThirtyBytes() { 
    final byte[] input = new byte[]{43, 44, 45, 46, 47, 48, 49, 50, 51, 52, 53, 54, 55, 56, 57, 58, 59, 60, 61, 62, 63, 64, 65}; 
    assertEquals("FQIGJkLMNOPQRSTUVWXYZ_", Base64.encodeBase64URLSafeString(input)); 
}
}
