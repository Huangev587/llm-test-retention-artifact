package entry;
import org.junit.Test;
import org.junit.Assert;
import static org.junit.Assert.*;
import java.nio.charset.StandardCharsets;
import org.apache.commons.codec.binary.Hex;
import org.apache.commons.codec.binary.Base64;
import org.apache.commons.codec.net.URLCodec;
public class Case_eb137bc583052225ee2940576180cf31 {
@Test public void testEncodeMixedBytes() throws Exception {
    byte[] input = { 0x41, -1, 0x42 };
    assertEquals("QQ-AB", Base64.encodeBase64URLSafeString(input));
}
}
