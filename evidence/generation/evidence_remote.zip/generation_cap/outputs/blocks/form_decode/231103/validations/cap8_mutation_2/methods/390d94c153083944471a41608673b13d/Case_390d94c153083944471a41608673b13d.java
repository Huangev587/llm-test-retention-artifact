package entry;
import org.junit.Test;
import org.junit.Assert;
import static org.junit.Assert.*;
import java.nio.charset.StandardCharsets;
import org.apache.commons.codec.binary.Hex;
import org.apache.commons.codec.binary.Base64;
import org.apache.commons.codec.net.URLCodec;
public class Case_390d94c153083944471a41608673b13d {
@Test
public void testDecodeLeadingPlusSign() throws Exception {
    assertEquals("+leading", new URLCodec().decode("+leading", "UTF-8"));
}
}
