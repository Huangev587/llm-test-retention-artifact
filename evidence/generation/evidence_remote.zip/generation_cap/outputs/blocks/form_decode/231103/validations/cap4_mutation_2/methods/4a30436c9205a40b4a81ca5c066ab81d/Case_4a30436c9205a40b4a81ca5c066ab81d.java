package entry;
import org.junit.Test;
import org.junit.Assert;
import static org.junit.Assert.*;
import java.nio.charset.StandardCharsets;
import org.apache.commons.codec.binary.Hex;
import org.apache.commons.codec.binary.Base64;
import org.apache.commons.codec.net.URLCodec;
public class Case_4a30436c9205a40b4a81ca5c066ab81d {
@Test
public void testDecodeWhitespace() throws Exception {
    assertEquals(" ", new URLCodec().decode("%20", "UTF-8"));
}
}
