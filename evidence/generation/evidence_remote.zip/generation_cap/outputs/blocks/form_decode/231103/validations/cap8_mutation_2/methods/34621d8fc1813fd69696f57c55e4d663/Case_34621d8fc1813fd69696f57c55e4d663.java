package entry;
import org.junit.Test;
import org.junit.Assert;
import static org.junit.Assert.*;
import java.nio.charset.StandardCharsets;
import org.apache.commons.codec.binary.Hex;
import org.apache.commons.codec.binary.Base64;
import org.apache.commons.codec.net.URLCodec;
public class Case_34621d8fc1813fd69696f57c55e4d663 {
@Test
public void testDecodeControlCharacters() throws Exception {
    assertEquals("\u0000\u001F", new URLCodec().decode("%00%1F", "UTF-8"));
}
}
