package entry;
import org.junit.Test;
import org.junit.Assert;
import static org.junit.Assert.*;
import java.nio.charset.StandardCharsets;
import org.apache.commons.codec.binary.Hex;
import org.apache.commons.codec.binary.Base64;
import org.apache.commons.codec.net.URLCodec;
public class Case_388e41adbfced6762c34ca404c2a6444 {
@Test
public void testDecodeURLWithUnicode() throws Exception {
    assertEquals("\u00e9\u00f9\u0111\u0163\u017d", new URLCodec().decode("%C3%A9%C3%B9%C4%8F%C4%8B%C5%BD", "UTF-8"));
}
}
