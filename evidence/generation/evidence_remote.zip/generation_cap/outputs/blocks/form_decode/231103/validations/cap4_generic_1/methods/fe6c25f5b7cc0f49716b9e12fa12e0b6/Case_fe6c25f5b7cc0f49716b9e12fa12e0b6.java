package entry;
import org.junit.Test;
import org.junit.Assert;
import static org.junit.Assert.*;
import java.nio.charset.StandardCharsets;
import org.apache.commons.codec.binary.Hex;
import org.apache.commons.codec.binary.Base64;
import org.apache.commons.codec.net.URLCodec;
public class Case_fe6c25f5b7cc0f49716b9e12fa12e0b6 {
@Test
public void testDecodeURLWithConsecutivePlusSigns() throws Exception {
    assertEquals("consecutive++signs", new URLCodec().decode("consecutive%2B%2Bsigns", "UTF-8"));
}
}
