package entry;
import org.junit.Test;
import org.junit.Assert;
import static org.junit.Assert.*;
import java.nio.charset.StandardCharsets;
import org.apache.commons.codec.binary.Hex;
import org.apache.commons.codec.binary.Base64;
import org.apache.commons.codec.net.URLCodec;
public class Case_a675ad01464374d27cfecf05f4f4a9ef {
@Test
public void testDecodeNumericString() throws Exception {
    assertEquals("1234567890", new URLCodec().decode("1234567890", "UTF-8"));
}
}
