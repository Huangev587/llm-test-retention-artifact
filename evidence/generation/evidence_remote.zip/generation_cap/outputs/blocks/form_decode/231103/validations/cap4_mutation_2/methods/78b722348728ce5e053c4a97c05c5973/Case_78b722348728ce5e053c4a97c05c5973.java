package entry;
import org.junit.Test;
import org.junit.Assert;
import static org.junit.Assert.*;
import java.nio.charset.StandardCharsets;
import org.apache.commons.codec.binary.Hex;
import org.apache.commons.codec.binary.Base64;
import org.apache.commons.codec.net.URLCodec;
public class Case_78b722348728ce5e053c4a97c05c5973 {
@Test
public void testDecodeMixedContent() throws Exception {
    assertEquals("mixed content: http://example.com/resource?param=value", new URLCodec().decode("mixed%20content:%20http%3A%2F%2Fexample.com%2Fresource%3Fparam%3Dvalue", "UTF-8"));
}
}
