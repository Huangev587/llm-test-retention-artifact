package entry;
import org.junit.Test;
import org.junit.Assert;
import static org.junit.Assert.*;
import java.nio.charset.StandardCharsets;
import org.apache.commons.codec.binary.Hex;
import org.apache.commons.codec.binary.Base64;
import org.apache.commons.codec.net.URLCodec;
public class Case_ba4fb88873fc554e080e43b443bc975f {
@Test
public void testDecodeURLWithSpecialCharacters() throws Exception {
    assertEquals("test@#&*()", new URLCodec().decode("test%40%23%26*()", "UTF-8"));
}
}
