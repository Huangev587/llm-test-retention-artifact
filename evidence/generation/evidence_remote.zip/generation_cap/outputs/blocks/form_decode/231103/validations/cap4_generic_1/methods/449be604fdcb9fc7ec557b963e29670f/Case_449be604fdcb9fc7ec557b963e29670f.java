package entry;
import org.junit.Test;
import org.junit.Assert;
import static org.junit.Assert.*;
import java.nio.charset.StandardCharsets;
import org.apache.commons.codec.binary.Hex;
import org.apache.commons.codec.binary.Base64;
import org.apache.commons.codec.net.URLCodec;
public class Case_449be604fdcb9fc7ec557b963e29670f {
@Test
public void testDecodeURLWithSpace() throws Exception {
    assertEquals("Hello World", new URLCodec().decode("Hello%20World", "UTF-8"));
}
}
