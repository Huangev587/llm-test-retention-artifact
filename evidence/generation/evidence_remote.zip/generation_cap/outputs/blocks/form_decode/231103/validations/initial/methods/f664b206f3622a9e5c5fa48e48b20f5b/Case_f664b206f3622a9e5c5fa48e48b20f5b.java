package entry;
import org.junit.Test;
import org.junit.Assert;
import static org.junit.Assert.*;
import java.nio.charset.StandardCharsets;
import org.apache.commons.codec.binary.Hex;
import org.apache.commons.codec.binary.Base64;
import org.apache.commons.codec.net.URLCodec;
public class Case_f664b206f3622a9e5c5fa48e48b20f5b {
@Test
public void testDecodeSingleCharacter() throws Exception {
    assertEquals("a", new URLCodec().decode("a", "UTF-8"));
}
}
