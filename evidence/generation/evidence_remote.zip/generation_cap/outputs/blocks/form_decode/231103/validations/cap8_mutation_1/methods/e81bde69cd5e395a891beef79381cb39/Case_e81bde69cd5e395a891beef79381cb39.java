package entry;
import org.junit.Test;
import org.junit.Assert;
import static org.junit.Assert.*;
import java.nio.charset.StandardCharsets;
import org.apache.commons.codec.binary.Hex;
import org.apache.commons.codec.binary.Base64;
import org.apache.commons.codec.net.URLCodec;
public class Case_e81bde69cd5e395a891beef79381cb39 {
@Test
public void testDecodeURLSafeString() throws Exception {
    assertEquals("safe&string", new URLCodec().decode("safe%26string", "UTF-8"));
}
}
