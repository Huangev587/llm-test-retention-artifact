package entry;
import org.junit.Test;
import org.junit.Assert;
import static org.junit.Assert.*;
import java.nio.charset.StandardCharsets;
import org.apache.commons.codec.binary.Hex;
import org.apache.commons.codec.binary.Base64;
import org.apache.commons.codec.net.URLCodec;
public class Case_d4fece0daddd6edd255ddb6842950014 {
@Test
public void testDecodeSingleByteCharacter() throws Exception {
    assertEquals("©", new URLCodec().decode("%C2%A9", "UTF-8"));
}
}
