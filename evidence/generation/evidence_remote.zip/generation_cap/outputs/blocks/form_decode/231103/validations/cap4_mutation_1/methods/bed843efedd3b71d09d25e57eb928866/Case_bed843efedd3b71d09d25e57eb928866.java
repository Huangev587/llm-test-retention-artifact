package entry;
import org.junit.Test;
import org.junit.Assert;
import static org.junit.Assert.*;
import java.nio.charset.StandardCharsets;
import org.apache.commons.codec.binary.Hex;
import org.apache.commons.codec.binary.Base64;
import org.apache.commons.codec.net.URLCodec;
public class Case_bed843efedd3b71d09d25e57eb928866 {
@Test
public void testDecodeMixedCase() throws Exception {
    assertEquals("HelloWorld", new URLCodec().decode("HelloWorld", "UTF-8"));
}
}
