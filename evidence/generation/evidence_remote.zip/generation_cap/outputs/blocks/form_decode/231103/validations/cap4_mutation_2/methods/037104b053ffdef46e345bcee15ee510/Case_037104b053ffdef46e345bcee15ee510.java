package entry;
import org.junit.Test;
import org.junit.Assert;
import static org.junit.Assert.*;
import java.nio.charset.StandardCharsets;
import org.apache.commons.codec.binary.Hex;
import org.apache.commons.codec.binary.Base64;
import org.apache.commons.codec.net.URLCodec;
public class Case_037104b053ffdef46e345bcee15ee510 {
@Test
public void testDecodePercentSign() throws Exception {
    assertEquals("%%", new URLCodec().decode("%25%25", "UTF-8"));
}
}
