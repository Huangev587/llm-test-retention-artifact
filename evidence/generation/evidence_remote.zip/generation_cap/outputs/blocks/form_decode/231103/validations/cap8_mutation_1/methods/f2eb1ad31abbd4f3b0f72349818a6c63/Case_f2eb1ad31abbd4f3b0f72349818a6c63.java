package entry;
import org.junit.Test;
import org.junit.Assert;
import static org.junit.Assert.*;
import java.nio.charset.StandardCharsets;
import org.apache.commons.codec.binary.Hex;
import org.apache.commons.codec.binary.Base64;
import org.apache.commons.codec.net.URLCodec;
public class Case_f2eb1ad31abbd4f3b0f72349818a6c63 {
@Test
public void testDecodeMixedCase() throws Exception {
    assertEquals("MixedCase", new URLCodec().decode("MixedCase", "UTF-8"));
}
}
