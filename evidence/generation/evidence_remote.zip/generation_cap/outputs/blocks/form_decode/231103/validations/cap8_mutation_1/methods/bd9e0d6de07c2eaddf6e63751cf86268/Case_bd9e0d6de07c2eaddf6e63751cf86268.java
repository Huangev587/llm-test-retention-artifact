package entry;
import org.junit.Test;
import org.junit.Assert;
import static org.junit.Assert.*;
import java.nio.charset.StandardCharsets;
import org.apache.commons.codec.binary.Hex;
import org.apache.commons.codec.binary.Base64;
import org.apache.commons.codec.net.URLCodec;
public class Case_bd9e0d6de07c2eaddf6e63751cf86268 {
@Test
public void testDecodeWhitespace() throws Exception {
    assertEquals("%20%20%20", new URLCodec().decode("   ", "UTF-8"));
}
}
