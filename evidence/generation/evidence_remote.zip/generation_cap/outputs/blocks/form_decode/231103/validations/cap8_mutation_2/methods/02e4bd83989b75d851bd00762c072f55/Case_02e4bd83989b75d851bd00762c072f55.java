package entry;
import org.junit.Test;
import org.junit.Assert;
import static org.junit.Assert.*;
import java.nio.charset.StandardCharsets;
import org.apache.commons.codec.binary.Hex;
import org.apache.commons.codec.binary.Base64;
import org.apache.commons.codec.net.URLCodec;
public class Case_02e4bd83989b75d851bd00762c072f55 {
@Test
public void testDecodeMultiByteCharacter() throws Exception {
    assertEquals("😊", new URLCodec().decode("%F0%9F%98%8A", "UTF-8"));
}
}
