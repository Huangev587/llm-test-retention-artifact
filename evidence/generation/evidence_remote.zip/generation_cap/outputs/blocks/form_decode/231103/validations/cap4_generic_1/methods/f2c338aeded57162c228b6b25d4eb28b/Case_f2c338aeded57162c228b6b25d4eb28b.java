package entry;
import org.junit.Test;
import org.junit.Assert;
import static org.junit.Assert.*;
import java.nio.charset.StandardCharsets;
import org.apache.commons.codec.binary.Hex;
import org.apache.commons.codec.binary.Base64;
import org.apache.commons.codec.net.URLCodec;
public class Case_f2c338aeded57162c228b6b25d4eb28b {
@Test
public void testDecodeURLWithNonASCIICharacters() throws Exception {
    assertEquals("こんにちは", new URLCodec().decode("%E3%81%93%E3%82%93%E3%81%AB%E3%81%A1%E3%81%AF%E3%81%97%E3%81%A6", "UTF-8"));
}
}
