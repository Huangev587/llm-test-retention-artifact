package entry;
import org.junit.Test;
import org.junit.Assert;
import static org.junit.Assert.*;
import java.nio.charset.StandardCharsets;
import org.apache.commons.codec.binary.Hex;
import org.apache.commons.codec.binary.Base64;
import org.apache.commons.codec.net.URLCodec;
public class Case_f5650e41bcbb1115f58be85452018bd6 {
@Test
public void testDecodeURLWithTrailingPlusSign() throws Exception {
    assertEquals("trailing+", new URLCodec().decode("trailing+", "UTF-8"));
}
}
