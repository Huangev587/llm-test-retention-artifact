package entry;
import org.junit.Test;
import org.junit.Assert;
import static org.junit.Assert.*;
import java.nio.charset.StandardCharsets;
import org.apache.commons.codec.binary.Hex;
import org.apache.commons.codec.binary.Base64;
import org.apache.commons.codec.net.URLCodec;
public class Case_dc8dbbb141d4b4ed464c890fdac161f6 {
@Test
public void testDecodeUnicodeCharacters() throws Exception {
    assertEquals("😊", new URLCodec().decode("%F0%9F%98%B1", "UTF-8"));
}
}
