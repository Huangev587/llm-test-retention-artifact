package entry;
import org.junit.Test;
import org.junit.Assert;
import static org.junit.Assert.*;
import java.nio.charset.StandardCharsets;
import org.apache.commons.codec.binary.Hex;
import org.apache.commons.codec.binary.Base64;
import org.apache.commons.codec.net.URLCodec;
public class Case_750e5d8ed960e20121a7dcf5d5fa96d5 {
@Test
public void testDecodeUnicodeEscapes() throws Exception {
    assertEquals("\u20AC\u2122\u2122\u20A0\u20A2", new URLCodec().decode("%E2%82%AC%E2%84%A2%E2%84%A2%E2%82%B0%E2%82%B2", "UTF-8"));
}
}
