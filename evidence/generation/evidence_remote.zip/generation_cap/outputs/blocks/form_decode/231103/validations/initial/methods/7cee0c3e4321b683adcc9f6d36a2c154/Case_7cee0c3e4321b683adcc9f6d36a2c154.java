package entry;
import org.junit.Test;
import org.junit.Assert;
import static org.junit.Assert.*;
import java.nio.charset.StandardCharsets;
import org.apache.commons.codec.binary.Hex;
import org.apache.commons.codec.binary.Base64;
import org.apache.commons.codec.net.URLCodec;
public class Case_7cee0c3e4321b683adcc9f6d36a2c154 {
@Test
public void testDecodeWithSpaces() throws Exception {
    assertEquals(" hello world ", new URLCodec().decode("%20hello+world%20", "UTF-8"));
}
}
