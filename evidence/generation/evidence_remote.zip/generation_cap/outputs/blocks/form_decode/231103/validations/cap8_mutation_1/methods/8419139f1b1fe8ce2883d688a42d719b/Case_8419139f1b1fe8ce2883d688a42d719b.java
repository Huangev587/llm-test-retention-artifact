package entry;
import org.junit.Test;
import org.junit.Assert;
import static org.junit.Assert.*;
import java.nio.charset.StandardCharsets;
import org.apache.commons.codec.binary.Hex;
import org.apache.commons.codec.binary.Base64;
import org.apache.commons.codec.net.URLCodec;
public class Case_8419139f1b1fe8ce2883d688a42d719b {
@Test
public void testDecodeEscapedCharacters() throws Exception {
    assertEquals("escaped+characters", new URLCodec().decode("escaped%2Bcharacters", "UTF-8"));
}
}
