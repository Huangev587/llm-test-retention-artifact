package entry;
import org.junit.Test;
import org.junit.Assert;
import static org.junit.Assert.*;
import java.nio.charset.StandardCharsets;
import org.apache.commons.codec.binary.Hex;
import org.apache.commons.codec.binary.Base64;
import org.apache.commons.codec.net.URLCodec;
public class Case_d462aaad19ca4210d93730a233eba583 {
@Test
public void testDecodeUnicodeEscapeSequence() throws Exception {
    assertEquals("\u263A", new URLCodec().decode("%E2%98%BA", "UTF-8"));
}
}
