package entry;
import org.junit.Test;
import org.junit.Assert;
import static org.junit.Assert.*;
import java.nio.charset.StandardCharsets;
import org.apache.commons.codec.binary.Hex;
import org.apache.commons.codec.binary.Base64;
import org.apache.commons.codec.net.URLCodec;
public class Case_b13a7eb86e73f0fbd1993dff8f3bc012 {
@Test
public void testDecodeSpecialCharacters() throws Exception {
    assertEquals("~!@#$%^&*()-_=+[]{}|;:',.<>?/", new URLCodec().decode("~%21%40%23%24%25%5E%26*%28-%29_%3D%2B%5B%5D%7B%7D%7C%3B%27%2C.%3C%3E%3F%2F", "UTF-8"));
}
}
