package entry;
import org.junit.Test;
import org.junit.Assert;
import static org.junit.Assert.*;
import java.nio.charset.StandardCharsets;
import org.apache.commons.codec.binary.Hex;
import org.apache.commons.codec.binary.Base64;
import org.apache.commons.codec.net.URLCodec;
public class Case_afa7494d332e8538588d8bcccc9f7e69 {
@Test
public void testDecodeReservedCharacters() throws Exception {
    assertEquals("<>&\"'", new URLCodec().decode("%3C%3E%26%22%27", "UTF-8"));
}
}
