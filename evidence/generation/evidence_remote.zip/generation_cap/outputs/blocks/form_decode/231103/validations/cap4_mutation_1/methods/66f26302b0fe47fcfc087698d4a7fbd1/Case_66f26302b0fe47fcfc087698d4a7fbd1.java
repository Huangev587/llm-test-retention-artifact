package entry;
import org.junit.Test;
import org.junit.Assert;
import static org.junit.Assert.*;
import java.nio.charset.StandardCharsets;
import org.apache.commons.codec.binary.Hex;
import org.apache.commons.codec.binary.Base64;
import org.apache.commons.codec.net.URLCodec;
public class Case_66f26302b0fe47fcfc087698d4a7fbd1 {
@Test
public void testDecodeUnicodeCharacters() throws Exception {
    assertEquals("©®™€£¥%", new URLCodec().decode("%C2%A9%C2%AE%E2%84%A2%E2%82%AC%E2%82%BF%25", "UTF-8"));
}
}
