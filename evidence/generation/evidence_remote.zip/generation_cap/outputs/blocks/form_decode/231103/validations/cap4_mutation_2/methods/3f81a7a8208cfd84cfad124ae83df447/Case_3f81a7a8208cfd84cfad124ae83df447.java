package entry;
import org.junit.Test;
import org.junit.Assert;
import static org.junit.Assert.*;
import java.nio.charset.StandardCharsets;
import org.apache.commons.codec.binary.Hex;
import org.apache.commons.codec.binary.Base64;
import org.apache.commons.codec.net.URLCodec;
public class Case_3f81a7a8208cfd84cfad124ae83df447 {
@Test
public void testDecodeEscapedURL() throws Exception {
    assertEquals("http://example.com/search?q=keyword", new URLCodec().decode("http%3A%2F%2Fexample.com%2Fsearch%3Fq%3Dkeyword", "UTF-8"));
}
}
