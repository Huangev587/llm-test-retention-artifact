package entry;
import org.junit.Test;
import org.junit.Assert;
import static org.junit.Assert.*;
import java.nio.charset.StandardCharsets;
import org.apache.commons.codec.binary.Hex;
import org.apache.commons.codec.binary.Base64;
import org.apache.commons.codec.net.URLCodec;
public class Case_dabbb35f16c728e6c7f764828b81d5ef {
@Test
public void testDecodeURLSpecialChars() throws Exception {
    assertEquals("http://example.com/search?q=keyword&sort=asc", new URLCodec().decode("http%3A//example\\.com/search%3Fq%3Dkeyword%26sort%3Dasc", "UTF-8"));
}
}
