package entry;
import org.junit.Test;
import org.junit.Assert;
import static org.junit.Assert.*;
import java.nio.charset.StandardCharsets;
import org.apache.commons.codec.binary.Hex;
import org.apache.commons.codec.binary.Base64;
import org.apache.commons.codec.net.URLCodec;
public class Case_7bb15dbc28f47772edd7cd1ba8d8e9c3 {
@Test
public void testDecodeURLSafeString() throws Exception {
    assertEquals("example.com/path/to/resource", new URLCodec().decode("example\\.com\\/path\\/to\\/resource", "UTF-8"));
}
}
