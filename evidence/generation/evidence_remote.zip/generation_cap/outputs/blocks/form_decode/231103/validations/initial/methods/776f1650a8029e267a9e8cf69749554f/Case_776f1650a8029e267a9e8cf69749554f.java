package entry;
import org.junit.Test;
import org.junit.Assert;
import static org.junit.Assert.*;
import java.nio.charset.StandardCharsets;
import org.apache.commons.codec.binary.Hex;
import org.apache.commons.codec.binary.Base64;
import org.apache.commons.codec.net.URLCodec;
public class Case_776f1650a8029e267a9e8cf69749554f {
@Test
public void testDecodeMixedCharacters() throws Exception {
    assertEquals("a😊b", new URLCodec().decode("a%F0%9F%98%B1b", "UTF-8"));
}
}
