package entry;
import org.junit.Test;
import org.junit.Assert;
import static org.junit.Assert.*;
import java.nio.charset.StandardCharsets;
import org.apache.commons.codec.binary.Hex;
import org.apache.commons.codec.binary.Base64;
import org.apache.commons.codec.net.URLCodec;
public class Case_8ecf03d15d46782fb7bff74ccfd9796a {
@Test
public void testDecodeMixedEncoding() throws Exception {
    assertEquals("a+b+c", new URLCodec().decode("a%2Bb%2Bc", "UTF-8"));
}
}
