package entry;
import org.junit.Test;
import org.junit.Assert;
import static org.junit.Assert.*;
import java.nio.charset.StandardCharsets;
import org.apache.commons.codec.binary.Hex;
import org.apache.commons.codec.binary.Base64;
import org.apache.commons.codec.net.URLCodec;
public class Case_91e81e2cef63c3b583712191d8922a85 {
@Test
public void testDecodeNumericValues() throws Exception {
    assertEquals("12345", new URLCodec().decode("12345", "UTF-8"));
}
}
