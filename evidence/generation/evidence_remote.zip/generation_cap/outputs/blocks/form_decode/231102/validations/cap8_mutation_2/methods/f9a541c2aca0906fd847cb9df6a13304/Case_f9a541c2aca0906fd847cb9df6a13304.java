package entry;
import org.junit.Test;
import org.junit.Assert;
import static org.junit.Assert.*;
import java.nio.charset.StandardCharsets;
import org.apache.commons.codec.binary.Hex;
import org.apache.commons.codec.binary.Base64;
import org.apache.commons.codec.net.URLCodec;
public class Case_f9a541c2aca0906fd847cb9df6a13304 {
@Test
public void testDecodeWithMultipleSpaces() throws Exception {
    assertEquals("a   b", new URLCodec().decode("a+++b", "UTF-8"));
}
}
