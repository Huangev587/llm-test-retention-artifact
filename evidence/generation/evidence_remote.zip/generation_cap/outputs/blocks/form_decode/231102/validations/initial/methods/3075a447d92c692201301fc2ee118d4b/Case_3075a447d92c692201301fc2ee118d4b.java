package entry;
import org.junit.Test;
import org.junit.Assert;
import static org.junit.Assert.*;
import java.nio.charset.StandardCharsets;
import org.apache.commons.codec.binary.Hex;
import org.apache.commons.codec.binary.Base64;
import org.apache.commons.codec.net.URLCodec;
public class Case_3075a447d92c692201301fc2ee118d4b {
@Test
public void testDecodeUnicodeEscapes() throws Exception {
    assertEquals("\u00E4\u00F6\u00FC", new URLCodec().decode("%C3%A4%C3%B6%C3%BC", "UTF-8"));
}
}
