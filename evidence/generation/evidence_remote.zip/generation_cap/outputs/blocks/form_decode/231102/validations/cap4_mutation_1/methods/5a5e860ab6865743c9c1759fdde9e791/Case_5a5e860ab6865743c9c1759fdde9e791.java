package entry;
import org.junit.Test;
import org.junit.Assert;
import static org.junit.Assert.*;
import java.nio.charset.StandardCharsets;
import org.apache.commons.codec.binary.Hex;
import org.apache.commons.codec.binary.Base64;
import org.apache.commons.codec.net.URLCodec;
public class Case_5a5e860ab6865743c9c1759fdde9e791 {
@Test
public void testDecodeControlCharacters() throws Exception {
    assertEquals("\t\n\r", new URLCodec().decode("%09%0A%0D", "UTF-8"));
}
}
