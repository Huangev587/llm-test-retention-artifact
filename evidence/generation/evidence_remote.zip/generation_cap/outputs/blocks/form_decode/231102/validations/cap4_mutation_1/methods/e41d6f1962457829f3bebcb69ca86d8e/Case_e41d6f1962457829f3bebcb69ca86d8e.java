package entry;
import org.junit.Test;
import org.junit.Assert;
import static org.junit.Assert.*;
import java.nio.charset.StandardCharsets;
import org.apache.commons.codec.binary.Hex;
import org.apache.commons.codec.binary.Base64;
import org.apache.commons.codec.net.URLCodec;
public class Case_e41d6f1962457829f3bebcb69ca86d8e {
@Test
public void testDecodeMixedCharacters() throws Exception {
    assertEquals("Hello, World! €", new URLCodec().decode("Hello%2C+World%21+%E2%82%AC", "UTF-8"));
}
}
