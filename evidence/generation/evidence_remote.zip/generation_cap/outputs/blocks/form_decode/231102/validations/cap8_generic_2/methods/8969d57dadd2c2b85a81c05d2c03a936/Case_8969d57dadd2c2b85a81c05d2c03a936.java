package entry;
import org.junit.Test;
import org.junit.Assert;
import static org.junit.Assert.*;
import java.nio.charset.StandardCharsets;
import org.apache.commons.codec.binary.Hex;
import org.apache.commons.codec.binary.Base64;
import org.apache.commons.codec.net.URLCodec;
public class Case_8969d57dadd2c2b85a81c05d2c03a936 {
@Test
public void testDecodeWhitespaceOnly() throws Exception {
    assertEquals("   ", new URLCodec().decode("+   +", "UTF-8"));
}
}
