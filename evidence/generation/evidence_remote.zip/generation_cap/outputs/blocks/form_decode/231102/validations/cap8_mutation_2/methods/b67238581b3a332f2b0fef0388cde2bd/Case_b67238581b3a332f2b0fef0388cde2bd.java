package entry;
import org.junit.Test;
import org.junit.Assert;
import static org.junit.Assert.*;
import java.nio.charset.StandardCharsets;
import org.apache.commons.codec.binary.Hex;
import org.apache.commons.codec.binary.Base64;
import org.apache.commons.codec.net.URLCodec;
public class Case_b67238581b3a332f2b0fef0388cde2bd {
@Test
public void testDecodeWithLowercaseHexEscapes() throws Exception {
    assertEquals("\u00E4\u00F6\u00FC", new URLCodec().decode("%c3%84%c3%96%c3%9c", "UTF-8"));
}
}
