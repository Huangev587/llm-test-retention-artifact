package entry;
import org.junit.Test;
import org.junit.Assert;
import static org.junit.Assert.*;
import java.nio.charset.StandardCharsets;
import org.apache.commons.codec.binary.Hex;
import org.apache.commons.codec.binary.Base64;
import org.apache.commons.codec.net.URLCodec;
public class Case_07db2dfeb54a6d3afc1ea32ee2d10e47 {
@Test
public void testDecodeSpecialUnicodeCharacters() throws Exception {
    assertEquals("\uD83D\uDE00", new URLCodec().decode("%F0%9F%98%80", "UTF-8"));
}
}
