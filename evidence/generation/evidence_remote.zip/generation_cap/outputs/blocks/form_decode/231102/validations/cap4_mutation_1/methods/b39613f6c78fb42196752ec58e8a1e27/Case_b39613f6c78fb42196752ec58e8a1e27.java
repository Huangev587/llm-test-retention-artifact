package entry;
import org.junit.Test;
import org.junit.Assert;
import static org.junit.Assert.*;
import java.nio.charset.StandardCharsets;
import org.apache.commons.codec.binary.Hex;
import org.apache.commons.codec.binary.Base64;
import org.apache.commons.codec.net.URLCodec;
public class Case_b39613f6c78fb42196752ec58e8a1e27 {
@Test
public void testDecodeHexadecimalEscapes() throws Exception {
    assertEquals("A B C", new URLCodec().decode("A+B+C", "UTF-8"));
}
}
