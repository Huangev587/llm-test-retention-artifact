package entry;
import org.junit.Test;
import org.junit.Assert;
import static org.junit.Assert.*;
import java.nio.charset.StandardCharsets;
import org.apache.commons.codec.binary.Hex;
import org.apache.commons.codec.binary.Base64;
import org.apache.commons.codec.net.URLCodec;
public class Case_e7994f8c3fa8f7b9d05b6122f72145d2 {
@Test
public void testDecodeLeadingTrailingSpaces() throws Exception {
    assertEquals(" hello world ", new URLCodec().decode("+hello+world+", "UTF-8"));
}
}
