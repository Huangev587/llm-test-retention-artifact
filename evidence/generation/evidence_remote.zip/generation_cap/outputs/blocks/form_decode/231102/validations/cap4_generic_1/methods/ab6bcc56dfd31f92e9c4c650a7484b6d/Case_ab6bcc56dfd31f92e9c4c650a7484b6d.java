package entry;
import org.junit.Test;
import org.junit.Assert;
import static org.junit.Assert.*;
import java.nio.charset.StandardCharsets;
import org.apache.commons.codec.binary.Hex;
import org.apache.commons.codec.binary.Base64;
import org.apache.commons.codec.net.URLCodec;
public class Case_ab6bcc56dfd31f92e9c4c650a7484b6d {
@Test
public void testDecodeSingleCharacter() throws Exception {
    assertEquals("€", new URLCodec().decode("%E2%82%AC", "UTF-8"));
}
}
