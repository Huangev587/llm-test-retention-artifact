package entry;
import org.junit.Test;
import org.junit.Assert;
import static org.junit.Assert.*;
import java.nio.charset.StandardCharsets;
import org.apache.commons.codec.binary.Hex;
import org.apache.commons.codec.binary.Base64;
import org.apache.commons.codec.net.URLCodec;
public class Case_b2849e17089c2f0fc2542dfd75ba476c {
@Test
public void testDecodeWhitespaceOnly() throws Exception {
    assertEquals("   ", new URLCodec().decode("+%20%20%20", "UTF-8"));
}
}
