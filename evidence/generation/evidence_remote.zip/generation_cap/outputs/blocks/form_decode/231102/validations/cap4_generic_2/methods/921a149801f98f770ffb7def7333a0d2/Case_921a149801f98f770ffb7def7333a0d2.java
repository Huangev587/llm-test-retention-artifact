package entry;
import org.junit.Test;
import org.junit.Assert;
import static org.junit.Assert.*;
import java.nio.charset.StandardCharsets;
import org.apache.commons.codec.binary.Hex;
import org.apache.commons.codec.binary.Base64;
import org.apache.commons.codec.net.URLCodec;
public class Case_921a149801f98f770ffb7def7333a0d2 {
@Test
public void testDecodeNullInput() throws Exception {
    assertNull(new URLCodec().decode(null, "UTF-8"));
}
}
