package entry;
import org.junit.Test;
import org.junit.Assert;
import static org.junit.Assert.*;
import java.nio.charset.StandardCharsets;
import org.apache.commons.codec.binary.Hex;
import org.apache.commons.codec.binary.Base64;
import org.apache.commons.codec.net.URLCodec;
public class Case_95b326f7c0bad866d9387a2c3e873f9a {
@Test
public void testDecodeURLReservedCharacters() throws Exception {
    assertEquals("?&=", new URLCodec().decode("%3F%26%3D", "UTF-8"));
}
}
