package entry;
import org.junit.Test;
import org.junit.Assert;
import static org.junit.Assert.*;
import java.nio.charset.StandardCharsets;
import org.apache.commons.codec.binary.Hex;
import org.apache.commons.codec.binary.Base64;
import org.apache.commons.codec.net.URLCodec;
public class Case_332b3e7f61b86611a11a294ef908b7d9 {
@Test
public void testDecodeUnicodeEscapeSequences() throws Exception {
    assertEquals("\u00A9\u2122\u2122", new URLCodec().decode("%C2%A9%C2%B2%C2%B2", "UTF-8"));
}
}
