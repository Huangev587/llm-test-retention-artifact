package entry;
import org.junit.Test;
import org.junit.Assert;
import static org.junit.Assert.*;
import java.nio.charset.StandardCharsets;
import org.apache.commons.codec.binary.Hex;
import org.apache.commons.codec.binary.Base64;
import org.apache.commons.codec.net.URLCodec;
public class Case_27cacf2ee3d7cf25b50eefe83e7faffd {
@Test
public void testDecodeWhitespaceOnly() throws Exception {
    assertEquals("   ", new URLCodec().decode("+%20+%20+", "UTF-8"));
}
}
