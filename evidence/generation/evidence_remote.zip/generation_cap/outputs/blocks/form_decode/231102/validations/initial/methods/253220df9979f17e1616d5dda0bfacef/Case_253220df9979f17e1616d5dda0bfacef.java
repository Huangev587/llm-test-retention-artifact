package entry;
import org.junit.Test;
import org.junit.Assert;
import static org.junit.Assert.*;
import java.nio.charset.StandardCharsets;
import org.apache.commons.codec.binary.Hex;
import org.apache.commons.codec.binary.Base64;
import org.apache.commons.codec.net.URLCodec;
public class Case_253220df9979f17e1616d5dda0bfacef {
@Test
public void testDecodeSingleCharacter() throws Exception {
    assertEquals("A", new URLCodec().decode("A", "UTF-8"));
}
}
