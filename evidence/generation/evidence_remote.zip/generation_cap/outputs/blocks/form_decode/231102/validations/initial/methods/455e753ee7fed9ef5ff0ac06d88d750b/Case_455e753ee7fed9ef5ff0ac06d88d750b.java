package entry;
import org.junit.Test;
import org.junit.Assert;
import static org.junit.Assert.*;
import java.nio.charset.StandardCharsets;
import org.apache.commons.codec.binary.Hex;
import org.apache.commons.codec.binary.Base64;
import org.apache.commons.codec.net.URLCodec;
public class Case_455e753ee7fed9ef5ff0ac06d88d750b {
@Test
public void testDecodeSimpleString() throws Exception {
    assertEquals("hello", new URLCodec().decode("hello", "UTF-8"));
}
}
