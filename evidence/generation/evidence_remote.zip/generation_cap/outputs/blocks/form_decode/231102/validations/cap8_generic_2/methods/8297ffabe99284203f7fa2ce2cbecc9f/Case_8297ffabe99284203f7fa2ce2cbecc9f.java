package entry;
import org.junit.Test;
import org.junit.Assert;
import static org.junit.Assert.*;
import java.nio.charset.StandardCharsets;
import org.apache.commons.codec.binary.Hex;
import org.apache.commons.codec.binary.Base64;
import org.apache.commons.codec.net.URLCodec;
public class Case_8297ffabe99284203f7fa2ce2cbecc9f {
@Test
public void testDecodeMixedCase() throws Exception {
    assertEquals("Hello World", new URLCodec().decode("Hello+World", "UTF-8"));
}
}
