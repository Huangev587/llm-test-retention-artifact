package entry;
import org.junit.Test;
import org.junit.Assert;
import static org.junit.Assert.*;
import java.nio.charset.StandardCharsets;
import org.apache.commons.codec.binary.Hex;
import org.apache.commons.codec.binary.Base64;
import org.apache.commons.codec.net.URLCodec;
public class Case_4ae140646c684ce238239f28e41cacc8 {
@Test
public void testDecodeUnicodeEscapes() throws Exception {
    assertEquals("\u00A0", new URLCodec().decode("%C2%A0", "UTF-8"));
}
}
