package entry;
import org.junit.Test;
import org.junit.Assert;
import static org.junit.Assert.*;
import java.nio.charset.StandardCharsets;
import org.apache.commons.codec.binary.Hex;
import org.apache.commons.codec.binary.Base64;
import org.apache.commons.codec.net.URLCodec;
public class Case_fd33216bfe4fbe44238507a4f91a2437 {
@Test
public void testDecodeWithPunctuation() throws Exception {
    assertEquals("!@#$%^&*()", new URLCodec().decode("!%40%23%24%25%5E%26%2A%28%29", "UTF-8"));
}
}
