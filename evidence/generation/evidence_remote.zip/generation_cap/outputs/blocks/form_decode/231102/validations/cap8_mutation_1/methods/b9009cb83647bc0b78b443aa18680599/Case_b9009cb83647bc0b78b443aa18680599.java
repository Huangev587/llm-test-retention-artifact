package entry;
import org.junit.Test;
import org.junit.Assert;
import static org.junit.Assert.*;
import java.nio.charset.StandardCharsets;
import org.apache.commons.codec.binary.Hex;
import org.apache.commons.codec.binary.Base64;
import org.apache.commons.codec.net.URLCodec;
public class Case_b9009cb83647bc0b78b443aa18680599 {
@Test
public void testDecodeWithTrailingSpaces() throws Exception {
    assertEquals("hello ", new URLCodec().decode("hello%20", "UTF-8"));
}
}
