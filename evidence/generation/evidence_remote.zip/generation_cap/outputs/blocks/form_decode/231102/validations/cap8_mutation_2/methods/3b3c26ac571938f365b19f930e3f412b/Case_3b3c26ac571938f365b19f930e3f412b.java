package entry;
import org.junit.Test;
import org.junit.Assert;
import static org.junit.Assert.*;
import java.nio.charset.StandardCharsets;
import org.apache.commons.codec.binary.Hex;
import org.apache.commons.codec.binary.Base64;
import org.apache.commons.codec.net.URLCodec;
public class Case_3b3c26ac571938f365b19f930e3f412b {
@Test
public void testDecodeWithNonASCIICharacters() throws Exception {
    assertEquals("©®[™]", new URLCodec().decode("%C2%A9%C2%AE[%C2%B2]", "UTF-8"));
}
}
