package entry;
import org.junit.Test;
import org.junit.Assert;
import static org.junit.Assert.*;
import java.nio.charset.StandardCharsets;
import org.apache.commons.codec.binary.Hex;
import org.apache.commons.codec.binary.Base64;
import org.apache.commons.codec.net.URLCodec;
public class Case_43385b5808a6d4f1692b056a6f91b1c7 {
@Test
public void testDecodeMixedCharacters() throws Exception {
    assertEquals("foo bar baz!", new URLCodec().decode("foo+bar+baz%21", "UTF-8"));
}
}
