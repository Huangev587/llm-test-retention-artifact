package entry;
import org.junit.Test;
import org.junit.Assert;
import static org.junit.Assert.*;
import java.nio.charset.StandardCharsets;
import org.apache.commons.codec.binary.Hex;
import org.apache.commons.codec.binary.Base64;
import org.apache.commons.codec.net.URLCodec;
public class Case_7757309f4497d01b8817134e78428219 {
@Test
public void testDecodeWithLeadingSpaces() throws Exception {
    assertEquals(" hello", new URLCodec().decode("%20hello", "UTF-8"));
}
}
