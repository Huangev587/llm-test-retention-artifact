package entry;
import org.junit.Test;
import org.junit.Assert;
import static org.junit.Assert.*;
import java.nio.charset.StandardCharsets;
import org.apache.commons.codec.binary.Hex;
import org.apache.commons.codec.binary.Base64;
import org.apache.commons.codec.net.URLCodec;
public class Case_69012a16b2b17af01ed92bb9c4f6d2ca {
@Test
public void testDecodeMultiByteEscaped() throws Exception {
    assertEquals("\u00E4", new URLCodec().decode("%C3%A4", "UTF-8"));
}
}
