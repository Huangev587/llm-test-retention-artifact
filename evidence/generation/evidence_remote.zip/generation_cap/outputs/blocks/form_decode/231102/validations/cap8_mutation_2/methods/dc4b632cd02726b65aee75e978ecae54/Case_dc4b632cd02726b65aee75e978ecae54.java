package entry;
import org.junit.Test;
import org.junit.Assert;
import static org.junit.Assert.*;
import java.nio.charset.StandardCharsets;
import org.apache.commons.codec.binary.Hex;
import org.apache.commons.codec.binary.Base64;
import org.apache.commons.codec.net.URLCodec;
public class Case_dc4b632cd02726b65aee75e978ecae54 {
@Test
public void testDecodeWithSpecialCharacters() throws Exception {
    assertEquals("abc!@#$%^&*()", new URLCodec().decode("abc!@#$%^&*()", "UTF-8"));
}
}
