package entry;
import org.junit.Test;
import org.junit.Assert;
import static org.junit.Assert.*;
import java.nio.charset.StandardCharsets;
import org.apache.commons.codec.binary.Hex;
import org.apache.commons.codec.binary.Base64;
import org.apache.commons.codec.net.URLCodec;
public class Case_29ccf0e6528af1da3d345945a2ab95cc {
@Test
public void testDecodeEdgeCaseCharacters() throws Exception {
    assertEquals("\u007F\u0080\uFFFF", new URLCodec().decode("%7F%C2%80%EF%BF%BD", "UTF-8"));
}
}
