package entry;
import org.junit.Test;
import org.junit.Assert;
import static org.junit.Assert.*;
import java.nio.charset.StandardCharsets;
import org.apache.commons.codec.binary.Hex;
import org.apache.commons.codec.binary.Base64;
import org.apache.commons.codec.net.URLCodec;
public class Case_ca3989fd97dbd1b65730197c8163f05a {
@Test
public void testDecodeMixedEscapedAndUnescaped() throws Exception {
    assertEquals("foo bar&baz", new URLCodec().decode("foo+bar&baz", "UTF-8"));
}
}
