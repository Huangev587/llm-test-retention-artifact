package entry;
import org.junit.Test;
import org.junit.Assert;
import static org.junit.Assert.*;
import java.nio.charset.StandardCharsets;
import org.apache.commons.codec.binary.Hex;
import org.apache.commons.codec.binary.Base64;
import org.apache.commons.codec.net.URLCodec;
public class Case_69dc1c23657a2202046445d7c60b3fe9 {
@Test
public void testDecodeNonUrlSafeCharacters() throws Exception {
    assertEquals("!@#$%^&*()", new URLCodec().decode("!@#$%^&*()", "UTF-8"));
}
}
