package entry;
import org.junit.Test;
import org.junit.Assert;
import static org.junit.Assert.*;
import java.nio.charset.StandardCharsets;
import org.apache.commons.codec.binary.Hex;
import org.apache.commons.codec.binary.Base64;
import org.apache.commons.codec.net.URLCodec;
public class Case_cad4f8527494738b5e7857f51edb5354 {
@Test
public void testDecodeSingleByteEscaped() throws Exception {
    assertEquals("\u00FF", new URLCodec().decode("%C3%BF", "UTF-8"));
}
}
