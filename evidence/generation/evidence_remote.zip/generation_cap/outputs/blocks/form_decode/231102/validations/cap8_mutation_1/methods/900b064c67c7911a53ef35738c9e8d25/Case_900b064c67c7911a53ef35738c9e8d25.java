package entry;
import org.junit.Test;
import org.junit.Assert;
import static org.junit.Assert.*;
import java.nio.charset.StandardCharsets;
import org.apache.commons.codec.binary.Hex;
import org.apache.commons.codec.binary.Base64;
import org.apache.commons.codec.net.URLCodec;
public class Case_900b064c67c7911a53ef35738c9e8d25 {
@Test
public void testDecodeWithMixedCase() throws Exception {
    assertEquals("Hello World!", new URLCodec().decode("Hello+World%21", "UTF-8"));
}
}
