package entry;
import org.junit.Test;
import org.junit.Assert;
import static org.junit.Assert.*;
import java.nio.charset.StandardCharsets;
import org.apache.commons.codec.binary.Hex;
import org.apache.commons.codec.binary.Base64;
import org.apache.commons.codec.net.URLCodec;
public class Case_17dc5cc963c7a6028fbb4aa5a41097cb {
@Test
public void testDecodeTrailingPlusSign() throws Exception {
    assertEquals("+", new URLCodec().decode("++", "UTF-8"));
}
}
