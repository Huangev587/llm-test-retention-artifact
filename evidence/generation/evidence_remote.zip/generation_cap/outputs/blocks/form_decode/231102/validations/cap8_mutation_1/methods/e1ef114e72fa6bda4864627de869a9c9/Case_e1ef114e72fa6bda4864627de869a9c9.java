package entry;
import org.junit.Test;
import org.junit.Assert;
import static org.junit.Assert.*;
import java.nio.charset.StandardCharsets;
import org.apache.commons.codec.binary.Hex;
import org.apache.commons.codec.binary.Base64;
import org.apache.commons.codec.net.URLCodec;
public class Case_e1ef114e72fa6bda4864627de869a9c9 {
@Test
public void testDecodeWithNonASCIICharacters() throws Exception {
    assertEquals("©®™", new URLCodec().decode("%C2%A9%C2%AE%C2%B2", "UTF-8"));
}
}
