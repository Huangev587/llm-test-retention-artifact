package entry;
import org.junit.Test;
import org.junit.Assert;
import static org.junit.Assert.*;
import java.nio.charset.StandardCharsets;
import org.apache.commons.codec.binary.Hex;
import org.apache.commons.codec.binary.Base64;
import org.apache.commons.codec.net.URLCodec;
public class Case_c9240f3cca53d31613a6662a77feeafe {
@Test
public void testDecodeEmptyString() throws Exception {
    assertEquals("", new URLCodec().decode("", "UTF-8"));
}
}
