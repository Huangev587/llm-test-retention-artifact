package entry;
import org.junit.Test;
import org.junit.Assert;
import static org.junit.Assert.*;
import java.nio.charset.StandardCharsets;
import org.apache.commons.codec.binary.Hex;
import org.apache.commons.codec.binary.Base64;
import org.apache.commons.codec.net.URLCodec;
public class Case_405bb4af5ce709bc716969ac7f50e3d5 {
@Test
public void testDecodeWithTrailingPlusSign() throws Exception {
    assertEquals("hello+", new URLCodec().decode("hello+", "UTF-8"));
}
}
