package entry;
import org.junit.Test;
import org.junit.Assert;
import static org.junit.Assert.*;
import java.nio.charset.StandardCharsets;
import org.apache.commons.codec.binary.Hex;
import org.apache.commons.codec.binary.Base64;
import org.apache.commons.codec.net.URLCodec;
public class Case_26b589d0d76d990402cb225ce288f187 {
@Test
public void testDecodeWithLeadingPlusSign() throws Exception {
    assertEquals("+hello", new URLCodec().decode("+hello", "UTF-8"));
}
}
