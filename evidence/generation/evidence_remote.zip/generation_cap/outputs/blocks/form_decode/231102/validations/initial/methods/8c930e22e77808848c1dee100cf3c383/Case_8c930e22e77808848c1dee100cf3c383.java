package entry;
import org.junit.Test;
import org.junit.Assert;
import static org.junit.Assert.*;
import java.nio.charset.StandardCharsets;
import org.apache.commons.codec.binary.Hex;
import org.apache.commons.codec.binary.Base64;
import org.apache.commons.codec.net.URLCodec;
public class Case_8c930e22e77808848c1dee100cf3c383 {
@Test
public void testDecodeSpecialCharacters() throws Exception {
    assertEquals("©®™", new URLCodec().decode("%C2%A9%C2%B0%C2%B9", "UTF-8"));
}
}
