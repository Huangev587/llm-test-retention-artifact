package entry;
import org.junit.Test;
import org.junit.Assert;
import static org.junit.Assert.*;
import java.nio.charset.StandardCharsets;
import org.apache.commons.codec.binary.Hex;
import org.apache.commons.codec.binary.Base64;
import org.apache.commons.codec.net.URLCodec;
public class Case_5812fbbd4ef55cc9bcb48f54c0d56310 {
@Test
public void testDecodeHexEncodedBytes() throws Exception {
    assertEquals("FF", new URLCodec().decode("%46%46", "UTF-8"));
}
}
