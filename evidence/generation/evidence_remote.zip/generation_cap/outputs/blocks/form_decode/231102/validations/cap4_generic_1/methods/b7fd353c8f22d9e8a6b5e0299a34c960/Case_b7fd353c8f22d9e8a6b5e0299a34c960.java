package entry;
import org.junit.Test;
import org.junit.Assert;
import static org.junit.Assert.*;
import java.nio.charset.StandardCharsets;
import org.apache.commons.codec.binary.Hex;
import org.apache.commons.codec.binary.Base64;
import org.apache.commons.codec.net.URLCodec;
public class Case_b7fd353c8f22d9e8a6b5e0299a34c960 {
@Test
public void testDecodeUnicodeEscapeSequence() throws Exception {
    assertEquals("\uD83D\uDE0A", new URLCodec().decode("%F0%9F%98%AA", "UTF-8"));
}
}
