package entry;
import org.junit.Test;
import org.junit.Assert;
import static org.junit.Assert.*;
import java.nio.charset.StandardCharsets;
import org.apache.commons.codec.binary.Hex;
import org.apache.commons.codec.binary.Base64;
import org.apache.commons.codec.net.URLCodec;
public class Case_32ca88abcfb72d6778206952e3379d37 {
@Test
public void testDecodeNonASCIICharacters() throws Exception {
    assertEquals("😊", new URLCodec().decode("%F0%9F%98%B8", "UTF-8"));
}
}
