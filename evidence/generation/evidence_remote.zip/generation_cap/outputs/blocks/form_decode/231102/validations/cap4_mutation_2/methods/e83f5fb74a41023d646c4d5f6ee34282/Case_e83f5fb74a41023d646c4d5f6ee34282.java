package entry;
import org.junit.Test;
import org.junit.Assert;
import static org.junit.Assert.*;
import java.nio.charset.StandardCharsets;
import org.apache.commons.codec.binary.Hex;
import org.apache.commons.codec.binary.Base64;
import org.apache.commons.codec.net.URLCodec;
public class Case_e83f5fb74a41023d646c4d5f6ee34282 {
@Test
public void testDecodeReservedCharacters() throws Exception {
    assertEquals("&=+", new URLCodec().decode("%26%3D%2B", "UTF-8"));
}
}
