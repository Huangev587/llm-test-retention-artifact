package entry;
import org.junit.Test;
import org.junit.Assert;
import static org.junit.Assert.*;
import java.nio.charset.StandardCharsets;
import org.apache.commons.codec.binary.Hex;
import org.apache.commons.codec.binary.Base64;
import org.apache.commons.codec.net.URLCodec;
public class Case_4d0838b1fdbe15bf2d9c7f89a0d734e8 {
@Test
public void testDecodePunctuation() throws Exception {
    assertEquals(",.<>/?;':\"\\|[]{}~`", new URLCodec().decode(",.<>/?;':\"\\|[]{}~`", "UTF-8"));
}
}
