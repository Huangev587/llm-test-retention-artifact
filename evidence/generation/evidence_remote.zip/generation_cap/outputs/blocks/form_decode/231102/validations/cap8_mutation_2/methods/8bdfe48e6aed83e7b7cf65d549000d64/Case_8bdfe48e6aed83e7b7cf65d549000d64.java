package entry;
import org.junit.Test;
import org.junit.Assert;
import static org.junit.Assert.*;
import java.nio.charset.StandardCharsets;
import org.apache.commons.codec.binary.Hex;
import org.apache.commons.codec.binary.Base64;
import org.apache.commons.codec.net.URLCodec;
public class Case_8bdfe48e6aed83e7b7cf65d549000d64 {
@Test
public void testDecodeWithUppercaseHexEscapes() throws Exception {
    assertEquals("\u00E4\u00F6\u00FC", new URLCodec().decode("%C3%84%C3%96%C3%9C", "UTF-8"));
}
}
