package entry;
import org.junit.Test;
import org.junit.Assert;
import static org.junit.Assert.*;
import java.nio.charset.StandardCharsets;
import org.apache.commons.codec.binary.Hex;
import org.apache.commons.codec.binary.Base64;
import org.apache.commons.codec.net.URLCodec;
public class Case_f77e983f1b57417ce3a5afe6fd4c8a8c {
@Test
public void testDecodeWithNumericValues() throws Exception {
    assertEquals("123", new URLCodec().decode("123", "UTF-8"));
}
}
