package entry;
import org.junit.Test;
import org.junit.Assert;
import static org.junit.Assert.*;
import java.nio.charset.StandardCharsets;
import org.apache.commons.codec.binary.Hex;
import org.apache.commons.codec.binary.Base64;
import org.apache.commons.codec.net.URLCodec;
public class Case_1cc2d6b4d61dfed065bbdc88d2cec53f {
@Test
public void testDecodeLeadingPlusSign() throws Exception {
    assertEquals("+", new URLCodec().decode("+", "UTF-8"));
}
}
