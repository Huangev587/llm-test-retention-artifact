package entry;
import org.junit.Test;
import org.junit.Assert;
import static org.junit.Assert.*;
import java.nio.charset.StandardCharsets;
import org.apache.commons.codec.binary.Hex;
import org.apache.commons.codec.binary.Base64;
import org.apache.commons.codec.net.URLCodec;
public class Case_1c5fd718bb3c5aee3b64ab332d1d0d05 {
@Test
public void testDecodeURLSafeCharacters() throws Exception {
    assertEquals("a b c!", new URLCodec().decode("a+b+c%21", "UTF-8"));
}
}
