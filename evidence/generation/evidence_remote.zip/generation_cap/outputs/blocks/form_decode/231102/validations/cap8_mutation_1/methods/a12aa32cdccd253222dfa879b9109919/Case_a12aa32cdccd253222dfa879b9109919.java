package entry;
import org.junit.Test;
import org.junit.Assert;
import static org.junit.Assert.*;
import java.nio.charset.StandardCharsets;
import org.apache.commons.codec.binary.Hex;
import org.apache.commons.codec.binary.Base64;
import org.apache.commons.codec.net.URLCodec;
public class Case_a12aa32cdccd253222dfa879b9109919 {
@Test
public void testDecodeWithLeadingAndTrailingSpaces() throws Exception {
    assertEquals(" hello ", new URLCodec().decode("%20hello%20", "UTF-8"));
}
}
