package entry;
import org.junit.Test;
import org.junit.Assert;
import static org.junit.Assert.*;
import java.nio.charset.StandardCharsets;
import org.apache.commons.codec.binary.Hex;
import org.apache.commons.codec.binary.Base64;
import org.apache.commons.codec.net.URLCodec;
public class Case_f57a238593065983e3bda600d8d52995 {
@Test public void testDecodeURLReserved() throws Exception {
    assertEquals("?=:", new URLCodec().decode("Pz0=", "UTF-8"));
}
}
