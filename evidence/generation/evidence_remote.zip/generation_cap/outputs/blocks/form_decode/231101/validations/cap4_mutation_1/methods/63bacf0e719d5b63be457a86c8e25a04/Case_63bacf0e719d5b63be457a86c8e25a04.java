package entry;
import org.junit.Test;
import org.junit.Assert;
import static org.junit.Assert.*;
import java.nio.charset.StandardCharsets;
import org.apache.commons.codec.binary.Hex;
import org.apache.commons.codec.binary.Base64;
import org.apache.commons.codec.net.URLCodec;
public class Case_63bacf0e719d5b63be457a86c8e25a04 {
@Test
public void testDecodeSpace() throws Exception {
    String input = "hello world";
    String decoded = new URLCodec().decode(input, "UTF-8");
    assertEquals("hello world", decoded);
}
}
