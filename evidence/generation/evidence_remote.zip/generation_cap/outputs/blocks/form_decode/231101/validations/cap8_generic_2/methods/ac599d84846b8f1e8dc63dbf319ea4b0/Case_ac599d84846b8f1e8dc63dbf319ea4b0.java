package entry;
import org.junit.Test;
import org.junit.Assert;
import static org.junit.Assert.*;
import java.nio.charset.StandardCharsets;
import org.apache.commons.codec.binary.Hex;
import org.apache.commons.codec.binary.Base64;
import org.apache.commons.codec.net.URLCodec;
public class Case_ac599d84846b8f1e8dc63dbf319ea4b0 {
@Test
public void testDecodeTrailingSpace() throws Exception {
    String input = "trailingSpace%20";
    String decoded = new URLCodec().decode(input, "UTF-8");
    assertEquals("trailingSpace ", decoded);
}
}
