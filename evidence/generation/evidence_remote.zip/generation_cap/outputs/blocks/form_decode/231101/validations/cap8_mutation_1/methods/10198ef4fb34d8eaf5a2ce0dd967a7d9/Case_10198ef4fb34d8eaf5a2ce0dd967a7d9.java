package entry;
import org.junit.Test;
import org.junit.Assert;
import static org.junit.Assert.*;
import java.nio.charset.StandardCharsets;
import org.apache.commons.codec.binary.Hex;
import org.apache.commons.codec.binary.Base64;
import org.apache.commons.codec.net.URLCodec;
public class Case_10198ef4fb34d8eaf5a2ce0dd967a7d9 {
@Test public void testDecodeMix() throws Exception { assertEquals("hello!worldὠ0", new URLCodec().decode("aGVsbG8hV29ybGQr8J YqA==", "UTF-8")); }
}
