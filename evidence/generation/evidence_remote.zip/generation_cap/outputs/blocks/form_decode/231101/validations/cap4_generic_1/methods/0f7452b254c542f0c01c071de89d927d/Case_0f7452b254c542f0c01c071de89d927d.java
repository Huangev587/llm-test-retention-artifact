package entry;
import org.junit.Test;
import org.junit.Assert;
import static org.junit.Assert.*;
import java.nio.charset.StandardCharsets;
import org.apache.commons.codec.binary.Hex;
import org.apache.commons.codec.binary.Base64;
import org.apache.commons.codec.net.URLCodec;
public class Case_0f7452b254c542f0c01c071de89d927d {
@Test
public void testDecodeSimpleString() throws Exception {
    String input = "HelloWorld";
    String decoded = new URLCodec().decode(input, "UTF-8");
    assertEquals("HelloWorld", decoded);
}
}
