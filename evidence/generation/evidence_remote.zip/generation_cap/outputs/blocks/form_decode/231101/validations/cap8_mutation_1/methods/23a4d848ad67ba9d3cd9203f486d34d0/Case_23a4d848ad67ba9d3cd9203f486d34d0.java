package entry;
import org.junit.Test;
import org.junit.Assert;
import static org.junit.Assert.*;
import java.nio.charset.StandardCharsets;
import org.apache.commons.codec.binary.Hex;
import org.apache.commons.codec.binary.Base64;
import org.apache.commons.codec.net.URLCodec;
public class Case_23a4d848ad67ba9d3cd9203f486d34d0 {
@Test public void testDecodeSpace() throws Exception { assertEquals("hello world", new URLCodec().decode("aGVsbG8gd29ybGQ=", "UTF-8")); }
}
