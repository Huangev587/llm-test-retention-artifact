package entry;
import org.junit.Test;
import org.junit.Assert;
import static org.junit.Assert.*;
import java.nio.charset.StandardCharsets;
import org.apache.commons.codec.binary.Hex;
import org.apache.commons.codec.binary.Base64;
import org.apache.commons.codec.net.URLCodec;
public class Case_839c47338c9c27ca071d72dac646459e {
@Test
public void testDecodeMultiplePercentEncodedChars() throws Exception {
    String input = "a%21b%23c%24d%25e%26f%27g%28h%29i%2AJ%2BK%2CL%2DM%2EN%2FO%2GP%2HQ%2RI%2JJ%2KK%2CL%2DM%2EN%2FO%2GP%2HQ%2RI%2JJ%2KK%2CL%2DM%2EN%2FO%2GP%2HQ%2RI%2JJ%2KK%2CL%2DM%2EN%2FO%2GP%2HQ%2RI%2JJ%2KK";
    String decoded = new URLCodec().decode(input, "UTF-8");
    assertEquals("a!b#c$d%e&f'g(h)iJ*K,L-M-N/O?PQRJLKMNOPQRSTJKLNMNOPQRSTUVJ", decoded);
}
}
