package entry;
import org.junit.Test;
import org.junit.Assert;
import static org.junit.Assert.*;
import java.nio.charset.StandardCharsets;
import org.apache.commons.codec.binary.Hex;
import org.apache.commons.codec.binary.Base64;
import org.apache.commons.codec.net.URLCodec;
public class Case_cc95c13328c5dd9c775aaceeb0a538ef {
@Test
public void testDecodeMultiByteCharacter() throws Exception {
    String input = "%E2%98%BA";
    String decoded = new URLCodec().decode(input, "UTF-8");
    assertEquals("🚀", decoded);
}
}
