package entry;
import org.junit.Test;
import org.junit.Assert;
import static org.junit.Assert.*;
import java.nio.charset.StandardCharsets;
import org.apache.commons.codec.binary.Hex;
import org.apache.commons.codec.binary.Base64;
import org.apache.commons.codec.net.URLCodec;
public class Case_09e8cccc25a3e080a873a5f451cef74f {
@Test
public void testDecodeSingleByte() throws Exception {
    String input = "%2F";
    String decoded = new URLCodec().decode(input, "UTF-8");
    assertEquals("/", decoded);
}
}
