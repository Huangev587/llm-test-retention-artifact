package entry;
import org.junit.Test;
import org.junit.Assert;
import static org.junit.Assert.*;
import java.nio.charset.StandardCharsets;
import org.apache.commons.codec.binary.Hex;
import org.apache.commons.codec.binary.Base64;
import org.apache.commons.codec.net.URLCodec;
public class Case_15c8fac2c56b31627937bfc0137ca4f4 {
@Test
public void testDecodeNullInput() throws Exception {
    String input = null;
    String decoded = new URLCodec().decode(input, "UTF-8");
    assertNull(decoded);
}
}
