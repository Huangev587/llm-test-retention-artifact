package entry;
import org.junit.Test;
import org.junit.Assert;
import static org.junit.Assert.*;
import java.nio.charset.StandardCharsets;
import org.apache.commons.codec.binary.Hex;
import org.apache.commons.codec.binary.Base64;
import org.apache.commons.codec.net.URLCodec;
public class Case_4ae6d7d8d37fb389046592ec71289a56 {
@Test
public void testDecodeWhitespace() throws Exception {
    String input = "%20";
    String decoded = new URLCodec().decode(input, "UTF-8");
    assertEquals(" ", decoded);
}
}
