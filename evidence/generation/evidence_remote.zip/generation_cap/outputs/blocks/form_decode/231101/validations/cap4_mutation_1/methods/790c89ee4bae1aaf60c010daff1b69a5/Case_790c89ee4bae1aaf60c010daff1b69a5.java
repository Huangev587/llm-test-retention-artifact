package entry;
import org.junit.Test;
import org.junit.Assert;
import static org.junit.Assert.*;
import java.nio.charset.StandardCharsets;
import org.apache.commons.codec.binary.Hex;
import org.apache.commons.codec.binary.Base64;
import org.apache.commons.codec.net.URLCodec;
public class Case_790c89ee4bae1aaf60c010daff1b69a5 {
@Test
public void testDecodeMixedCharacters() throws Exception {
    String input = "Hello, World! @#$%^&*()";
    String decoded = new URLCodec().decode(input, "UTF-8");
    assertEquals("Hello, World! @#$%^&*()", decoded);
}
}
