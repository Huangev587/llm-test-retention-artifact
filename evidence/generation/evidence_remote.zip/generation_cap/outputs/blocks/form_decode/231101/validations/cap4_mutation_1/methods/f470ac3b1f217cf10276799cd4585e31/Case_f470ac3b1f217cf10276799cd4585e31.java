package entry;
import org.junit.Test;
import org.junit.Assert;
import static org.junit.Assert.*;
import java.nio.charset.StandardCharsets;
import org.apache.commons.codec.binary.Hex;
import org.apache.commons.codec.binary.Base64;
import org.apache.commons.codec.net.URLCodec;
public class Case_f470ac3b1f217cf10276799cd4585e31 {
@Test
public void testDecodeBasic() throws Exception {
    String input = "hello";
    String decoded = new URLCodec().decode(input, "UTF-8");
    assertEquals("hello", decoded);
}
}
