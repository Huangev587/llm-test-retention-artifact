package entry;
import org.junit.Test;
import org.junit.Assert;
import static org.junit.Assert.*;
import java.nio.charset.StandardCharsets;
import org.apache.commons.codec.binary.Hex;
import org.apache.commons.codec.binary.Base64;
import org.apache.commons.codec.net.URLCodec;
public class Case_38151a1b765e2df83a762af8d9c72b8e {
@Test
public void testDecodeSingleByteCharacter() throws Exception {
    String input = "%01";
    String decoded = new URLCodec().decode(input, "UTF-8");
    assertEquals("\u0001", decoded);
}
}
