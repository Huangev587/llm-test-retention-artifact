package entry;
import org.junit.Test;
import org.junit.Assert;
import static org.junit.Assert.*;
import java.nio.charset.StandardCharsets;
import org.apache.commons.codec.binary.Hex;
import org.apache.commons.codec.binary.Base64;
import org.apache.commons.codec.net.URLCodec;
public class Case_73c25ef28c5cd209d13d7687d3eb83ff {
@Test
public void testDecodePlusSignAsSpace() throws Exception {
    String input = "foo+bar";
    String decoded = new URLCodec().decode(input, "UTF-8");
    assertEquals("foo bar", decoded);
}
}
