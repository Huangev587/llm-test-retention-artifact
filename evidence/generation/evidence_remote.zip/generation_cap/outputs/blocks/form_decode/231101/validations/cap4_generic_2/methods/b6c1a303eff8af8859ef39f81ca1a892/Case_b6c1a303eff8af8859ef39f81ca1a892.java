package entry;
import org.junit.Test;
import org.junit.Assert;
import static org.junit.Assert.*;
import java.nio.charset.StandardCharsets;
import org.apache.commons.codec.binary.Hex;
import org.apache.commons.codec.binary.Base64;
import org.apache.commons.codec.net.URLCodec;
public class Case_b6c1a303eff8af8859ef39f81ca1a892 {
@Test
public void testDecodeSpecialCharacters() throws Exception {
    String input = "%21%22%23%24%25%26%27%28%29%2A%2B%2C%2D%2E%2F";
    String decoded = new URLCodec().decode(input, "UTF-8");
    assertEquals("!\"#$%&'()*+,-./", decoded);
}
}
