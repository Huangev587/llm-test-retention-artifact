package entry;
import org.junit.Test;
import org.junit.Assert;
import static org.junit.Assert.*;
import java.nio.charset.StandardCharsets;
import org.apache.commons.codec.binary.Hex;
import org.apache.commons.codec.binary.Base64;
import org.apache.commons.codec.net.URLCodec;
public class Case_89df7344b5c5dd135b4fd36783e1a270 {
@Test
public void testDecodeSpecialChars() throws Exception {
    assertEquals("!@#$%^&*()", new URLCodec().decode("IQAkJSUjJCEoKSkpLS0=", "UTF-8"));
}
}
