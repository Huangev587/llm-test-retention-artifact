package entry;
import org.junit.Test;
import org.junit.Assert;
import static org.junit.Assert.*;
import java.nio.charset.StandardCharsets;
import org.apache.commons.codec.binary.Hex;
import org.apache.commons.codec.binary.Base64;
import org.apache.commons.codec.net.URLCodec;
public class Case_c6d27a85100c7114bfcc96272551d4ee {
@Test
public void testDecodeEmptyString() throws Exception {
    assertNull(new URLCodec().decode("", "UTF-8"));
}
}
