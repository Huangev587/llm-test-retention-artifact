package entry;
import org.junit.Test;
import org.junit.Assert;
import static org.junit.Assert.*;
import java.nio.charset.StandardCharsets;
import org.apache.commons.codec.binary.Hex;
import org.apache.commons.codec.binary.Base64;
import org.apache.commons.codec.net.URLCodec;
public class Case_5fbba14436f5041381ff8fdd4e53217f {
@Test
public void testDecodeEscapedCharacters() throws Exception {
    String input = "foo%2Bbar%2Cqux%3Dcorge%26grault%3Dgarply";
    String decoded = new URLCodec().decode(input, "UTF-8");
    assertEquals("foo+bar,qux=corge&grault=garply", decoded);
}
}
