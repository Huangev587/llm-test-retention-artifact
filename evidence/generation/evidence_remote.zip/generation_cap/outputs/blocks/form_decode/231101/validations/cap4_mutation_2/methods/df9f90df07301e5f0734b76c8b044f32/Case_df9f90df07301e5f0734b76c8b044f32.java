package entry;
import org.junit.Test;
import org.junit.Assert;
import static org.junit.Assert.*;
import java.nio.charset.StandardCharsets;
import org.apache.commons.codec.binary.Hex;
import org.apache.commons.codec.binary.Base64;
import org.apache.commons.codec.net.URLCodec;
public class Case_df9f90df07301e5f0734b76c8b044f32 {
@Test
public void testDecodeMixedContent() throws Exception {
    String input = "foo%20bar%E2%82%ACbaz";
    String decoded = new URLCodec().decode(input, "UTF-8");
    assertEquals("foo bar\u20ACbaz", decoded);
}
}
