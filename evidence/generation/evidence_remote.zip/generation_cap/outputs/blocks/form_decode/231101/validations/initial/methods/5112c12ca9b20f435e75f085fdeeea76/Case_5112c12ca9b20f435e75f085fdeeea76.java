package entry;
import org.junit.Test;
import org.junit.Assert;
import static org.junit.Assert.*;
import java.nio.charset.StandardCharsets;
import org.apache.commons.codec.binary.Hex;
import org.apache.commons.codec.binary.Base64;
import org.apache.commons.codec.net.URLCodec;
public class Case_5112c12ca9b20f435e75f085fdeeea76 {
@Test
public void testDecodeUnicode() throws Exception {
    assertEquals("\u1F600", new URLCodec().decode("8J+YqA==", "UTF-8"));
}
}
