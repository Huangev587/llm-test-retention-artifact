package entry;
import org.junit.Test;
import org.junit.Assert;
import static org.junit.Assert.*;
import java.nio.charset.StandardCharsets;
import org.apache.commons.codec.binary.Hex;
import org.apache.commons.codec.binary.Base64;
import org.apache.commons.codec.net.URLCodec;
public class Case_bb373360e3f4e6e40689c6e3f7bf2bda {
@Test
public void testDecodeSpaceCharacter() throws Exception {
    String input = "Hello%20World";
    String decoded = new URLCodec().decode(input, "UTF-8");
    assertEquals("Hello World", decoded);
}
}
