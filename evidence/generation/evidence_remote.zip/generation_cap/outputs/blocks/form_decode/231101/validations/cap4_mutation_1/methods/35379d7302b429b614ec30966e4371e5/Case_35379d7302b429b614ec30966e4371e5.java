package entry;
import org.junit.Test;
import org.junit.Assert;
import static org.junit.Assert.*;
import java.nio.charset.StandardCharsets;
import org.apache.commons.codec.binary.Hex;
import org.apache.commons.codec.binary.Base64;
import org.apache.commons.codec.net.URLCodec;
public class Case_35379d7302b429b614ec30966e4371e5 {
@Test
public void testDecodeSpecialChars() throws Exception {
    String input = "!@#$%^&*()";
    String decoded = new URLCodec().decode(input, "UTF-8");
    assertEquals("!@#$%^&*()", decoded);
}
}
