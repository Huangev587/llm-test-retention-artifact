package entry;
import org.junit.Test;
import org.junit.Assert;
import static org.junit.Assert.*;
import java.nio.charset.StandardCharsets;
import org.apache.commons.codec.binary.Hex;
import org.apache.commons.codec.binary.Base64;
import org.apache.commons.codec.net.URLCodec;
public class Case_e832a4a6adde44bd2790494af0391e8a {
@Test
public void testDecodeSingleChar() throws Exception {
    String input = "A";
    String decoded = new URLCodec().decode(input, "UTF-8");
    assertEquals("A", decoded);
}
}
