package entry;
import org.junit.Test;
import org.junit.Assert;
import static org.junit.Assert.*;
import java.nio.charset.StandardCharsets;
import org.apache.commons.codec.binary.Hex;
import org.apache.commons.codec.binary.Base64;
import org.apache.commons.codec.net.URLCodec;
public class Case_ea68bcfdbd3a47e1373eb5911b1d1bfa {
@Test public void testDecodeMix() throws Exception {
    assertEquals("hello!world Nintendo DS", new URLCodec().decode("aGVsbG8hV29ybGQgTGludGVyYXRpdmUgRFM=", "UTF-8"));
}
}
