package entry;
import org.junit.Test;
import org.junit.Assert;
import static org.junit.Assert.*;
import java.nio.charset.StandardCharsets;
import org.apache.commons.codec.binary.Hex;
import org.apache.commons.codec.binary.Base64;
import org.apache.commons.codec.net.URLCodec;
public class Case_3bd1f2f6a670746517ca48e31b4c1b1a {
@Test public void testDecodeUnicode() throws Exception {
    assertEquals("ὠ0", new URLCodec().decode("8J YqA==", "UTF-8"));
}
}
