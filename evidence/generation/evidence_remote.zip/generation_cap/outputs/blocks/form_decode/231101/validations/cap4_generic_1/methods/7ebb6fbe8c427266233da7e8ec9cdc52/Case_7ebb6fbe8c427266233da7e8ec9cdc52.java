package entry;
import org.junit.Test;
import org.junit.Assert;
import static org.junit.Assert.*;
import java.nio.charset.StandardCharsets;
import org.apache.commons.codec.binary.Hex;
import org.apache.commons.codec.binary.Base64;
import org.apache.commons.codec.net.URLCodec;
public class Case_7ebb6fbe8c427266233da7e8ec9cdc52 {
@Test
public void testDecodeURLSafeCharacters() throws Exception {
    String input = "aA0123456789-_.~!@#$%^&*()+=`{}|\\:\"'<>,.?/~";
    String decoded = new URLCodec().decode(input, "UTF-8");
    assertEquals(input, decoded);
}
}
