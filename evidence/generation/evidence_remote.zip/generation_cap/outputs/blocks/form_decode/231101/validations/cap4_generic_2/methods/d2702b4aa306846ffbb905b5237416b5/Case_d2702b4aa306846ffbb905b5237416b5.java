package entry;
import org.junit.Test;
import org.junit.Assert;
import static org.junit.Assert.*;
import java.nio.charset.StandardCharsets;
import org.apache.commons.codec.binary.Hex;
import org.apache.commons.codec.binary.Base64;
import org.apache.commons.codec.net.URLCodec;
public class Case_d2702b4aa306846ffbb905b5237416b5 {
@Test
public void testDecodeMixedEncodedAndUnencoded() throws Exception {
    String input = "foo%2Bbar,qux=%E2%98%BA&grault=garply";
    String decoded = new URLCodec().decode(input, "UTF-8");
    assertEquals("foo+bar,qux=🚀&grault=garply", decoded);
}
}
