package entry;
import org.junit.Test;
import org.junit.Assert;
import static org.junit.Assert.*;
import java.nio.charset.StandardCharsets;
import org.apache.commons.codec.binary.Hex;
import org.apache.commons.codec.binary.Base64;
import org.apache.commons.codec.net.URLCodec;
public class Case_026490b9695bb956207def957216517a {
@Test
public void testDecodeLeadingSpace() throws Exception {
    String input = "%20leadingSpace";
    String decoded = new URLCodec().decode(input, "UTF-8");
    assertEquals(" leadingSpace", decoded);
}
}
