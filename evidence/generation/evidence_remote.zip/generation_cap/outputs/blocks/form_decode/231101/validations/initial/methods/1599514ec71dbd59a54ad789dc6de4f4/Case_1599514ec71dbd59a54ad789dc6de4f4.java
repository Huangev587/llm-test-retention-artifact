package entry;
import org.junit.Test;
import org.junit.Assert;
import static org.junit.Assert.*;
import java.nio.charset.StandardCharsets;
import org.apache.commons.codec.binary.Hex;
import org.apache.commons.codec.binary.Base64;
import org.apache.commons.codec.net.URLCodec;
public class Case_1599514ec71dbd59a54ad789dc6de4f4 {
@Test
public void testDecodeBasic() throws Exception {
    assertEquals("hello", new URLCodec().decode("aGVsbG8=", "UTF-8"));
}
}
