package entry;
import org.junit.Test;
import org.junit.Assert;
import static org.junit.Assert.*;
import java.nio.charset.StandardCharsets;
import org.apache.commons.codec.binary.Hex;
import org.apache.commons.codec.binary.Base64;
import org.apache.commons.codec.net.URLCodec;
public class Case_2f37df5280286918d7e19f95a6f8af30 {
@Test
public void testDecodeHexadecimal() throws Exception {
    String input = "%41%42%43";
    String decoded = new URLCodec().decode(input, "UTF-8");
    assertEquals("ABC", decoded);
}
}
