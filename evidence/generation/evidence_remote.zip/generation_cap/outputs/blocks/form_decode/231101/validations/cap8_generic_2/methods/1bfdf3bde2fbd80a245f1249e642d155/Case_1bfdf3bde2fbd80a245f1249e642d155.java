package entry;
import org.junit.Test;
import org.junit.Assert;
import static org.junit.Assert.*;
import java.nio.charset.StandardCharsets;
import org.apache.commons.codec.binary.Hex;
import org.apache.commons.codec.binary.Base64;
import org.apache.commons.codec.net.URLCodec;
public class Case_1bfdf3bde2fbd80a245f1249e642d155 {
@Test
public void testDecodeTrailingSlash() throws Exception {
    String input = "foo%2Fbar";
    String decoded = new URLCodec().decode(input, "UTF-8");
    assertEquals("foo/bar", decoded);
}
}
