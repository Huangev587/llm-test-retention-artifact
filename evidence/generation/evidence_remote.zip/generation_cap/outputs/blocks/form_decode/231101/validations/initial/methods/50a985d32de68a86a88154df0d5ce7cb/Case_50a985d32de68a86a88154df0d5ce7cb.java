package entry;
import org.junit.Test;
import org.junit.Assert;
import static org.junit.Assert.*;
import java.nio.charset.StandardCharsets;
import org.apache.commons.codec.binary.Hex;
import org.apache.commons.codec.binary.Base64;
import org.apache.commons.codec.net.URLCodec;
public class Case_50a985d32de68a86a88154df0d5ce7cb {
@Test
public void testDecodeMixed() throws Exception {
    assertEquals("hello!world\u1F600", new URLCodec().decode("aGVsbG8hV29ybGQr8J+YqA==", "UTF-8"));
}
}
