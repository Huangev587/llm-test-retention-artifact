package entry;
import org.junit.Test;
import org.junit.Assert;
import static org.junit.Assert.*;
import java.nio.charset.StandardCharsets;
import org.apache.commons.codec.binary.Hex;
import org.apache.commons.codec.binary.Base64;
import org.apache.commons.codec.net.URLCodec;
public class Case_d22ab6b8ee6580c77323ff83b749a610 {
@Test
public void testDecodeUnicodeEscape() throws Exception {
    String input = "%E2%82%AC"; // Euro sign
    String decoded = new URLCodec().decode(input, "UTF-8");
    assertEquals("\u20AC", decoded);
}
}
