package entry;
import org.junit.Test;
import org.junit.Assert;
import static org.junit.Assert.*;
import java.nio.charset.StandardCharsets;
import org.apache.commons.codec.binary.Hex;
import org.apache.commons.codec.binary.Base64;
import org.apache.commons.codec.net.URLCodec;
public class Case_d96adb7246b6d769650f4d306c4fedd9 {
@Test
public void testDecodeWhitespaceInEncodedString() throws Exception {
    String input = "foo%20bar";
    String decoded = new URLCodec().decode(input, "UTF-8");
    assertEquals("foo bar", decoded);
}
}
