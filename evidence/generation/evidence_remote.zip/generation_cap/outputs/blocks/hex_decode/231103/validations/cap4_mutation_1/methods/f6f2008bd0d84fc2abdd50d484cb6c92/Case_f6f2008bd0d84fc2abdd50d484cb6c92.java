package entry;
import org.junit.Test;
import org.junit.Assert;
import static org.junit.Assert.*;
import java.nio.charset.StandardCharsets;
import org.apache.commons.codec.binary.Hex;
import org.apache.commons.codec.binary.Base64;
import org.apache.commons.codec.net.URLCodec;
public class Case_f6f2008bd0d84fc2abdd50d484cb6c92 {
@Test
public void testDecodeHexTwoBytes() throws Exception {
    assertEquals(new byte[]{0x12, 0x34}, Hex.decodeHex("1234"));
}
}
