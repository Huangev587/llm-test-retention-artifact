package entry;
import org.junit.Test;
import org.junit.Assert;
import static org.junit.Assert.*;
import java.nio.charset.StandardCharsets;
import org.apache.commons.codec.binary.Hex;
import org.apache.commons.codec.binary.Base64;
import org.apache.commons.codec.net.URLCodec;
public class Case_79f31ac33902f770635524f513985b55 {
@Test
public void testDecodeHexMultipleBytes() throws Exception {
    assertEquals(new byte[]{0x12, 0x34, 0x56, 0x78}, Hex.decodeHex("12345678"));
}
}
