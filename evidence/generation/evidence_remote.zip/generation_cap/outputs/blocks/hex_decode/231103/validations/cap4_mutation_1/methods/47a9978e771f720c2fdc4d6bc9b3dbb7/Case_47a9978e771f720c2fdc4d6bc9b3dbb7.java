package entry;
import org.junit.Test;
import org.junit.Assert;
import static org.junit.Assert.*;
import java.nio.charset.StandardCharsets;
import org.apache.commons.codec.binary.Hex;
import org.apache.commons.codec.binary.Base64;
import org.apache.commons.codec.net.URLCodec;
public class Case_47a9978e771f720c2fdc4d6bc9b3dbb7 {
@Test
public void testDecodeHexSingleByte() throws Exception {
    assertEquals(new byte[]{0x12}, Hex.decodeHex("12"));
}
}
