package entry;
import org.junit.Test;
import org.junit.Assert;
import static org.junit.Assert.*;
import java.nio.charset.StandardCharsets;
import org.apache.commons.codec.binary.Hex;
import org.apache.commons.codec.binary.Base64;
import org.apache.commons.codec.net.URLCodec;
public class Case_8313b3f75fcff7cd76083b78418ba2ab {
@Test
public void testLowercase() throws Exception {
    assertArrayEquals(new byte[]{0xab, 0xcd}, Hex.decodeHex("abcd"));
}
}
