package entry;
import org.junit.Test;
import org.junit.Assert;
import static org.junit.Assert.*;
import java.nio.charset.StandardCharsets;
import org.apache.commons.codec.binary.Hex;
import org.apache.commons.codec.binary.Base64;
import org.apache.commons.codec.net.URLCodec;
public class Case_ae7f2f1be3a24df5bc584e55a81a810f {
@Test
public void testSingleByte() throws Exception {
    assertArrayEquals(new byte[]{0x12}, Hex.decodeHex("12"));
}
}
