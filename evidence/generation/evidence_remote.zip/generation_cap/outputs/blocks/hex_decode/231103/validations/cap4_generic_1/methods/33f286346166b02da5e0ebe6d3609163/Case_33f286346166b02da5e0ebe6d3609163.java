package entry;
import org.junit.Test;
import org.junit.Assert;
import static org.junit.Assert.*;
import java.nio.charset.StandardCharsets;
import org.apache.commons.codec.binary.Hex;
import org.apache.commons.codec.binary.Base64;
import org.apache.commons.codec.net.URLCodec;
public class Case_33f286346166b02da5e0ebe6d3609163 {
@Test
public void testMultipleBytes() throws Exception {
    assertArrayEquals(new byte[]{0x12, 0x34, 0x56, 0x78}, Hex.decodeHex("12345678"));
}
}
