package entry;
import org.junit.Test;
import org.junit.Assert;
import static org.junit.Assert.*;
import java.nio.charset.StandardCharsets;
import org.apache.commons.codec.binary.Hex;
import org.apache.commons.codec.binary.Base64;
import org.apache.commons.codec.net.URLCodec;
public class Case_b52e6036b6865210e7b253c947adb858 {
@Test
public void testUpperCase() throws Exception {
    assertArrayEquals(new byte[]{0xAB, 0xCD}, Hex.decodeHex("ABCD"));
}
}
