package entry;
import org.junit.Test;
import org.junit.Assert;
import static org.junit.Assert.*;
import java.nio.charset.StandardCharsets;
import org.apache.commons.codec.binary.Hex;
import org.apache.commons.codec.binary.Base64;
import org.apache.commons.codec.net.URLCodec;
public class Case_8e45fe1bcb3bba2ea1455c6e56a2e188 {
@Test
public void testZeroPadding() throws Exception {
    assertArrayEquals(new byte[]{0x00}, Hex.decodeHex("00"));
}
}
