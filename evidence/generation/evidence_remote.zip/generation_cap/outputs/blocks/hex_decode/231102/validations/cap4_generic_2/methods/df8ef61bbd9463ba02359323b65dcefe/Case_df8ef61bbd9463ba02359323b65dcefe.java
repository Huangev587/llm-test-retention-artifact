package entry;
import org.junit.Test;
import org.junit.Assert;
import static org.junit.Assert.*;
import java.nio.charset.StandardCharsets;
import org.apache.commons.codec.binary.Hex;
import org.apache.commons.codec.binary.Base64;
import org.apache.commons.codec.net.URLCodec;
public class Case_df8ef61bbd9463ba02359323b65dcefe {
@Test
public void testDecodeHexMixedCase() throws Exception {
    assertArrayEquals(
        new byte[]{(byte) 0xaa, (byte) 0xbb},
        Hex.decodeHex("aaBB")
    );
}
}
