package entry;
import org.junit.Test;
import org.junit.Assert;
import static org.junit.Assert.*;
import java.nio.charset.StandardCharsets;
import org.apache.commons.codec.binary.Hex;
import org.apache.commons.codec.binary.Base64;
import org.apache.commons.codec.net.URLCodec;
public class Case_566eff1b017522cd9d6dc0108689e1b6 {
@Test
public void testDecodeHexLeadingZeros() throws Exception {
    assertArrayEquals(
        new byte[]{(byte) 0x00, (byte) 0x11},
        Hex.decodeHex("0011")
    );
}
}
