package entry;
import org.junit.Test;
import org.junit.Assert;
import static org.junit.Assert.*;
import java.nio.charset.StandardCharsets;
import org.apache.commons.codec.binary.Hex;
import org.apache.commons.codec.binary.Base64;
import org.apache.commons.codec.net.URLCodec;
public class Case_7971d261720b865b835339f1a2683679 {
@Test
public void testDecodeHexZeroPadding() throws Exception {
    assertArrayEquals(new byte[]{(byte) 0, (byte) 0}, Hex.decodeHex("0000"));
}
}
