package entry;
import org.junit.Test;
import org.junit.Assert;
import static org.junit.Assert.*;
import java.nio.charset.StandardCharsets;
import org.apache.commons.codec.binary.Hex;
import org.apache.commons.codec.binary.Base64;
import org.apache.commons.codec.net.URLCodec;
public class Case_ffddd8abbdaee03e7f33b1882edf052d {
@Test
public void testDecodeHexTrailingZeros() throws Exception {
    assertArrayEquals(
        new byte[]{(byte) 0xff, (byte) 0x00},
        Hex.decodeHex("ff00")
    );
}
}
