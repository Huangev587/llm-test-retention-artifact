package entry;
import org.junit.Test;
import org.junit.Assert;
import static org.junit.Assert.*;
import java.nio.charset.StandardCharsets;
import org.apache.commons.codec.binary.Hex;
import org.apache.commons.codec.binary.Base64;
import org.apache.commons.codec.net.URLCodec;
public class Case_4b4867738e231f20377c0d92304270b6 {
@Test
public void testDecodeHexSingleByte() throws Exception {
    assertArrayEquals(new byte[]{(byte) 0}, Hex.decodeHex("00"));
}
}
