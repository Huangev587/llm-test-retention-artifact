package entry;
import org.junit.Test;
import org.junit.Assert;
import static org.junit.Assert.*;
import java.nio.charset.StandardCharsets;
import org.apache.commons.codec.binary.Hex;
import org.apache.commons.codec.binary.Base64;
import org.apache.commons.codec.net.URLCodec;
public class Case_2b64077b943fdeb4bcb9d103fa5f47ad {
@Test
public void testDecodeHexMaxLength() throws Exception {
    assertArrayEquals(
        new byte[]{(byte) 0x12, (byte) 0x34, (byte) 0x56, (byte) 0x78, (byte) 0x9a, (byte) 0xbc, (byte) 0xde, (byte) 0xf0},
        Hex.decodeHex("123456789abcdef0")
    );
}
}
