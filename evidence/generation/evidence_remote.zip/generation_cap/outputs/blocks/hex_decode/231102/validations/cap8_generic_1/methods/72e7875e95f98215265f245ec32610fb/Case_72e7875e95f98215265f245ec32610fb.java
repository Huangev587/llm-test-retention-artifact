package entry;
import org.junit.Test;
import org.junit.Assert;
import static org.junit.Assert.*;
import java.nio.charset.StandardCharsets;
import org.apache.commons.codec.binary.Hex;
import org.apache.commons.codec.binary.Base64;
import org.apache.commons.codec.net.URLCodec;
public class Case_72e7875e95f98215265f245ec32610fb {
@Test
public void testDecodeHexTwoBytes() throws Exception {
    assertArrayEquals(new byte[]{(byte) 170, (byte) 85}, Hex.decodeHex("AA55"));
}
}
