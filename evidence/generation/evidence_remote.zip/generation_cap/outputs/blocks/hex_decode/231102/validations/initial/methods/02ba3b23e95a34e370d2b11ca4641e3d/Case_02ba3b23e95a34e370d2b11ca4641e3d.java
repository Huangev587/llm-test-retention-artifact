package entry;
import org.junit.Test;
import org.junit.Assert;
import static org.junit.Assert.*;
import java.nio.charset.StandardCharsets;
import org.apache.commons.codec.binary.Hex;
import org.apache.commons.codec.binary.Base64;
import org.apache.commons.codec.net.URLCodec;
public class Case_02ba3b23e95a34e370d2b11ca4641e3d {
@Test
public void testDecodeHexLongString() throws Exception {
    String longHexString = "0123456789ABCDEF";
    byte[] expected = new byte[]{1, 2, 3, 4, 5, 6, 7, 8, 9, 10, 11, 12, 13, 14, 15};
    assertArrayEquals(expected, Hex.decodeHex(longHexString));
}
}
