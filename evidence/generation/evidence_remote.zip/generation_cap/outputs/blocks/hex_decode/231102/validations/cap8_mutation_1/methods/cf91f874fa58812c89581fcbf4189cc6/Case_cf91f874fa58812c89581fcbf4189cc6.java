package entry;
import org.junit.Test;
import org.junit.Assert;
import static org.junit.Assert.*;
import java.nio.charset.StandardCharsets;
import org.apache.commons.codec.binary.Hex;
import org.apache.commons.codec.binary.Base64;
import org.apache.commons.codec.net.URLCodec;
public class Case_cf91f874fa58812c89581fcbf4189cc6 {
@Test
public void testDecodeHexTrailingZeros() throws Exception {
    assertArrayEquals(new byte[]{(byte) 0}, Hex.decodeHex("0000"));
}
}
