package entry;
import org.junit.Test;
import org.junit.Assert;
import static org.junit.Assert.*;
import java.nio.charset.StandardCharsets;
import org.apache.commons.codec.binary.Hex;
import org.apache.commons.codec.binary.Base64;
import org.apache.commons.codec.net.URLCodec;
public class Case_843950631ab8542f25ef2abe890e4150 {
@Test
public void testDecodeHexMaxValue() throws Exception {
    assertArrayEquals(new byte[]{(byte) 127}, Hex.decodeHex("7F"));
}
}
