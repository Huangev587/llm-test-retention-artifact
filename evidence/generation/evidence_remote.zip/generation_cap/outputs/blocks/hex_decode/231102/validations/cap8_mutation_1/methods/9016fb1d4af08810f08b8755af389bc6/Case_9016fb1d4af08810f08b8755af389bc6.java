package entry;
import org.junit.Test;
import org.junit.Assert;
import static org.junit.Assert.*;
import java.nio.charset.StandardCharsets;
import org.apache.commons.codec.binary.Hex;
import org.apache.commons.codec.binary.Base64;
import org.apache.commons.codec.net.URLCodec;
public class Case_9016fb1d4af08810f08b8755af389bc6 {
@Test
public void testDecodeHexSingleByte() throws Exception {
    assertArrayEquals(new byte[]{(byte) 255}, Hex.decodeHex("FF"));
}
}
