package entry;
import org.junit.Test;
import org.junit.Assert;
import static org.junit.Assert.*;
import java.nio.charset.StandardCharsets;
import org.apache.commons.codec.binary.Hex;
import org.apache.commons.codec.binary.Base64;
import org.apache.commons.codec.net.URLCodec;
public class Case_8b0cce0fbd6cf42ae90d103794bcfc5b {
@Test
public void testDecodeHexFourBytes() throws Exception {
    assertArrayEquals(new byte[]{(byte) -32, (byte) -85, (byte) -128, (byte) -171}, Hex.decodeHex("80FF00FF"));
}
}
