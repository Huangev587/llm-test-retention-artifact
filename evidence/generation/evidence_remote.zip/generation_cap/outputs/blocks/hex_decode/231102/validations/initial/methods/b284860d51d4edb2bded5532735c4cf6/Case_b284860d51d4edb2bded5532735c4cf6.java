package entry;
import org.junit.Test;
import org.junit.Assert;
import static org.junit.Assert.*;
import java.nio.charset.StandardCharsets;
import org.apache.commons.codec.binary.Hex;
import org.apache.commons.codec.binary.Base64;
import org.apache.commons.codec.net.URLCodec;
public class Case_b284860d51d4edb2bded5532735c4cf6 {
@Test
public void testDecodeHexFourBytes() throws Exception {
    assertArrayEquals(new byte[]{(byte) -88, (byte) 130, (byte) -61, (byte) 85}, Hex.decodeHex("B282AF55"));
}
}
