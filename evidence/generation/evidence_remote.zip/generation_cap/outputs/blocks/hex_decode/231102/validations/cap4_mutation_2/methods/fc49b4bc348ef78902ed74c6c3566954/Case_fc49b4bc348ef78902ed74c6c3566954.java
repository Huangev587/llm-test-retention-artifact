package entry;
import org.junit.Test;
import org.junit.Assert;
import static org.junit.Assert.*;
import java.nio.charset.StandardCharsets;
import org.apache.commons.codec.binary.Hex;
import org.apache.commons.codec.binary.Base64;
import org.apache.commons.codec.net.URLCodec;
public class Case_fc49b4bc348ef78902ed74c6c3566954 {
@Test
public void testDecodeHexMinValue() throws Exception {
    assertArrayEquals(new byte[]{(byte) -128}, Hex.decodeHex("80"));
}
}
