package entry;
import org.junit.Test;
import org.junit.Assert;
import static org.junit.Assert.*;
import java.nio.charset.StandardCharsets;
import org.apache.commons.codec.binary.Hex;
import org.apache.commons.codec.binary.Base64;
import org.apache.commons.codec.net.URLCodec;
public class Case_8fc5ea321440d3143c0c91380c8e2ca2 {
@Test
public void testDecodeHexLowerCase() throws Exception {
    assertArrayEquals(new byte[]{(byte) 170, (byte) 85}, Hex.decodeHex("aa55"));
}
}
