package entry;
import org.junit.Test;
import org.junit.Assert;
import static org.junit.Assert.*;
import java.nio.charset.StandardCharsets;
import org.apache.commons.codec.binary.Hex;
import org.apache.commons.codec.binary.Base64;
import org.apache.commons.codec.net.URLCodec;
public class Case_e2f6d7cff5ec5b474ccfa15617073fe2 {
@Test
public void testDecodeHexMixedCase() throws Exception {
    assertArrayEquals(new byte[]{(byte) 170, (byte) 85}, Hex.decodeHex("Aa55"));
}
}
