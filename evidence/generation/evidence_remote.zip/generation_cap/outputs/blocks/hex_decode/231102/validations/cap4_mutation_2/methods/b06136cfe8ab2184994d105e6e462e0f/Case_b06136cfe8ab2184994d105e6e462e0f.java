package entry;
import org.junit.Test;
import org.junit.Assert;
import static org.junit.Assert.*;
import java.nio.charset.StandardCharsets;
import org.apache.commons.codec.binary.Hex;
import org.apache.commons.codec.binary.Base64;
import org.apache.commons.codec.net.URLCodec;
public class Case_b06136cfe8ab2184994d105e6e462e0f {
@Test
public void testDecodeHexTwoBytes() throws Exception {
    assertArrayEquals(new byte[]{(byte) 255, (byte) 128}, Hex.decodeHex("FF80"));
}
}
