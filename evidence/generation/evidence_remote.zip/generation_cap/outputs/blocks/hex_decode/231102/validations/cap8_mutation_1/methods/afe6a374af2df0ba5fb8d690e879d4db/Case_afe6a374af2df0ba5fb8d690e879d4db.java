package entry;
import org.junit.Test;
import org.junit.Assert;
import static org.junit.Assert.*;
import java.nio.charset.StandardCharsets;
import org.apache.commons.codec.binary.Hex;
import org.apache.commons.codec.binary.Base64;
import org.apache.commons.codec.net.URLCodec;
public class Case_afe6a374af2df0ba5fb8d690e879d4db {
@Test
public void testDecodeHexMixedCase() throws Exception {
    assertArrayEquals(new byte[]{(byte) 0, (byte) 170, (byte) 85}, Hex.decodeHex("00aa55"));
}
}
