package entry;
import org.junit.Test;
import org.junit.Assert;
import static org.junit.Assert.*;
import java.nio.charset.StandardCharsets;
import org.apache.commons.codec.binary.Hex;
import org.apache.commons.codec.binary.Base64;
import org.apache.commons.codec.net.URLCodec;
public class Case_3a2e1c631f2e15fb7a2ba3f2e7054263 {
@Test
public void testDecodeHexOneCharacter() throws Exception {
    assertArrayEquals(new byte[]{(byte) 0}, Hex.decodeHex("0"));
}
}
