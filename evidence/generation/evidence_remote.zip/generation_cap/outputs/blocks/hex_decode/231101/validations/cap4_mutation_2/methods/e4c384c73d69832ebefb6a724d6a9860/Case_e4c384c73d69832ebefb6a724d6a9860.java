package entry;
import org.junit.Test;
import org.junit.Assert;
import static org.junit.Assert.*;
import java.nio.charset.StandardCharsets;
import org.apache.commons.codec.binary.Hex;
import org.apache.commons.codec.binary.Base64;
import org.apache.commons.codec.net.URLCodec;
public class Case_e4c384c73d69832ebefb6a724d6a9860 {
@Test
public void testDecodeHexLeadingZeroes() throws Exception {
    assertArrayEquals(new byte[]{(byte) 0x00, (byte) 0x01}, Hex.decodeHex("0001"));
}
}
