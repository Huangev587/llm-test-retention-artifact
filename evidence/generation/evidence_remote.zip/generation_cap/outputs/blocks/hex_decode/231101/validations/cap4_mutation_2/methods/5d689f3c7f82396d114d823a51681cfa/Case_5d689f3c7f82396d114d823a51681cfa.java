package entry;
import org.junit.Test;
import org.junit.Assert;
import static org.junit.Assert.*;
import java.nio.charset.StandardCharsets;
import org.apache.commons.codec.binary.Hex;
import org.apache.commons.codec.binary.Base64;
import org.apache.commons.codec.net.URLCodec;
public class Case_5d689f3c7f82396d114d823a51681cfa {
@Test
public void testDecodeHexEightBytes() throws Exception {
    assertArrayEquals(new byte[]{(byte) 0x9ABCDEF0, (byte) 0x12345678}, Hex.decodeHex("9ABCDEF012345678"));
}
}
