package entry;
import org.junit.Test;
import org.junit.Assert;
import static org.junit.Assert.*;
import java.nio.charset.StandardCharsets;
import org.apache.commons.codec.binary.Hex;
import org.apache.commons.codec.binary.Base64;
import org.apache.commons.codec.net.URLCodec;
public class Case_5d437f5e81443c96861f3397c01f7569 {
@Test
public void testDecodeHexEmptyString() throws Exception {
    assertArrayEquals(new byte[]{}, Hex.decodeHex(""));
}
}
