package entry;
import org.junit.Test;
import org.junit.Assert;
import static org.junit.Assert.*;
import java.nio.charset.StandardCharsets;
import org.apache.commons.codec.binary.Hex;
import org.apache.commons.codec.binary.Base64;
import org.apache.commons.codec.net.URLCodec;
public class Case_98a66fb59d2aa3cb7e11f761968e9bd8 {
@Test
public void testDecodeHexLongString() throws Exception {
    String hexString = "0123456789ABCDEF0123456789ABCDEF";
    assertArrayEquals(new byte[]{
            1, 2, 3, 4, 5, 6, 7, 8, 9, 10, 11, 12, 13, 14, 15, 16,
            1, 2, 3, 4, 5, 6, 7, 8, 9, 10, 11, 12, 13, 14, 15, 16
    }, Hex.decodeHex(hexString));
}
}
