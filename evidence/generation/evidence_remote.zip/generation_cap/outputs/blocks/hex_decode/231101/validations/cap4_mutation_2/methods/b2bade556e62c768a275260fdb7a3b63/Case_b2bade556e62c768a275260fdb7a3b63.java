package entry;
import org.junit.Test;
import org.junit.Assert;
import static org.junit.Assert.*;
import java.nio.charset.StandardCharsets;
import org.apache.commons.codec.binary.Hex;
import org.apache.commons.codec.binary.Base64;
import org.apache.commons.codec.net.URLCodec;
public class Case_b2bade556e62c768a275260fdb7a3b63 {
@Test
public void testDecodeHexTrailingZeroes() throws Exception {
    assertArrayEquals(new byte[]{(byte) 0x01, (byte) 0x00}, Hex.decodeHex("0100"));
}
}
