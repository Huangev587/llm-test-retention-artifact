package entry;
import org.junit.Test;
import org.junit.Assert;
import static org.junit.Assert.*;
import java.nio.charset.StandardCharsets;
import org.apache.commons.codec.binary.Hex;
import org.apache.commons.codec.binary.Base64;
import org.apache.commons.codec.net.URLCodec;
public class Case_826343622ae5019b9eb6122bfb9e8c50 {
@Test
public void testSingleByte() throws Exception {
    assertArrayEquals(new byte[]{0x0A}, Hex.decodeHex("0A"));
}
}
