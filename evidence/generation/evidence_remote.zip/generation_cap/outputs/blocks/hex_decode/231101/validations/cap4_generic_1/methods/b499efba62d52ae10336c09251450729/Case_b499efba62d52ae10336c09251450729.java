package entry;
import org.junit.Test;
import org.junit.Assert;
import static org.junit.Assert.*;
import java.nio.charset.StandardCharsets;
import org.apache.commons.codec.binary.Hex;
import org.apache.commons.codec.binary.Base64;
import org.apache.commons.codec.net.URLCodec;
public class Case_b499efba62d52ae10336c09251450729 {
@Test
public void testTwoBytes() throws Exception {
    assertArrayEquals(new byte[]{0x12, 0x34}, Hex.decodeHex("1234"));
}
}
