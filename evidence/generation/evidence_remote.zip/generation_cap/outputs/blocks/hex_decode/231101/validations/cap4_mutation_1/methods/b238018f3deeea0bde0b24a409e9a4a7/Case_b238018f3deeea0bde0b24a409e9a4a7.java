package entry;
import org.junit.Test;
import org.junit.Assert;
import static org.junit.Assert.*;
import java.nio.charset.StandardCharsets;
import org.apache.commons.codec.binary.Hex;
import org.apache.commons.codec.binary.Base64;
import org.apache.commons.codec.net.URLCodec;
public class Case_b238018f3deeea0bde0b24a409e9a4a7 {
@Test
public void testDecodeHexSingleByte() throws Exception {
    assertArrayEquals(new byte[]{(byte) 0x10}, Hex.decodeHex("10"));
}
}
