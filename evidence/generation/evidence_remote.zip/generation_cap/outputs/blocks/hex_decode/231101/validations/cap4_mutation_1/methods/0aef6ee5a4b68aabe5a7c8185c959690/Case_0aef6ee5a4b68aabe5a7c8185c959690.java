package entry;
import org.junit.Test;
import org.junit.Assert;
import static org.junit.Assert.*;
import java.nio.charset.StandardCharsets;
import org.apache.commons.codec.binary.Hex;
import org.apache.commons.codec.binary.Base64;
import org.apache.commons.codec.net.URLCodec;
public class Case_0aef6ee5a4b68aabe5a7c8185c959690 {
@Test
public void testDecodeHexTwoBytes() throws Exception {
    assertArrayEquals(new byte[]{(byte) 0xAB, (byte) 0xCD}, Hex.decodeHex("ABCD"));
}
}
