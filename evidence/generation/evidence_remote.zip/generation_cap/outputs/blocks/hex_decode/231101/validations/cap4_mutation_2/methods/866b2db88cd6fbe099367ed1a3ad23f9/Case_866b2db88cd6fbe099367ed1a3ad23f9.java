package entry;
import org.junit.Test;
import org.junit.Assert;
import static org.junit.Assert.*;
import java.nio.charset.StandardCharsets;
import org.apache.commons.codec.binary.Hex;
import org.apache.commons.codec.binary.Base64;
import org.apache.commons.codec.net.URLCodec;
public class Case_866b2db88cd6fbe099367ed1a3ad23f9 {
@Test
public void testDecodeHexRandomEvenLength() throws Exception {
    assertArrayEquals(Hex.decodeHex("DEADBEEFCAFEBABE"), Hex.decodeHex("DEADBEEFCAFEBABE"));
}
}
