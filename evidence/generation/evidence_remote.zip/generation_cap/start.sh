#!/usr/bin/env bash
set -eu
cd -- "$(dirname -- "$0")"
project=/root/autodl-tmp/LSH/mutgen_budget_pilot_20261111/revision/generation_cap_20261123
[[ "$(pwd -P)" == "$project" ]]
python=/root/autodl-tmp/LSH/conda/envs/Paper/bin/python
mkdir -p outputs
if [[ ${1:-} != worker ]]; then
    if [[ -f outputs/results.json ]]; then echo "Batch already complete: $project/outputs/results.json"; exit 0; fi
    exec 9>outputs/run.lock
    if ! flock -n 9; then echo "Already started. Log: $project/outputs/run.log"; exit 0; fi
    nohup bash "$project/start.sh" worker 9>&9 </dev/null >>outputs/run.log 2>&1 &
    echo "Background PID $! | log $project/outputs/run.log"
    exit 0
fi
[[ -e /proc/$$/fd/9 ]]
wall_limit=$("$python" -I -B -c 'import json; print(json.load(open("protocol.json"))["wall_seconds"])')
echo "$(date -Is) GPU_QUEUE_ACTIVE pid=$$ wait_limit=none"
while :; do
    if free=$(nvidia-smi -i 0 --query-gpu=memory.free --format=csv,noheader,nounits 2>/dev/null) && [[ "$free" =~ ^[0-9]+$ ]]; then
        if (( free >= 21504 )); then break; fi
        echo "$(date -Is) WAITING_FOR_GPU free=${free}MiB required=21504MiB"
    else
        echo "$(date -Is) GPU_QUERY_FAILED; retrying in 60 seconds"
    fi
    sleep 60
done
if [[ -f outputs/batch.json ]]; then
    wall_limit=$("$python" -I -B -c 'import json,time;print(max(0,int(json.load(open("outputs/batch.json"))["deadline"]-time.time())))')
fi
(( wall_limit > 0 )) || { echo "Batch deadline exhausted."; exit 2; }
export CUDA_VISIBLE_DEVICES=0 TOKENIZERS_PARALLELISM=false
set +e
timeout -k 10 "$wall_limit" "$python" -u -I -B runner.py
rc=$?
echo "$(date -Is) BATCH_EXIT=$rc"
exit "$rc"
