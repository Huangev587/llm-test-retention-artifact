"""Build only the extended guard and reference, using the previous frozen Codec runtime."""
import json
import os
import shutil
import sys
import tempfile
import time
from pathlib import Path

HERE = Path(__file__).resolve().parent
BASE = HERE.parent / "external_confirmation"
sys.path.insert(0, str(BASE / "scripts"))
from common import Commands, digest, read, remote_only, verify, write
from config import APIS, JDK, MODEL, source_context
from pilot_runner import model_identity
from runtime import Runtime
from messages import build as original_prompt, compact_feedback
from selection import prefix_ids

NEW = "base64_urlsafe"
APIS[NEW] = dict(APIS["base64_encode"], call="Base64.encodeBase64URLSafeString(byte[])",
                 marker="public static String encodeBase64URLSafeString(final byte[] binaryData)",
                 domain="Non-null byte array of length 0..256. Return URL-safe Base64 without padding or line breaks.")


def prompt(api, context, suite, arm, validation, cap, rows, split):
    if arm != "mutation":
        return original_prompt(api, context, suite, arm)
    if validation["structure_pass"]:
        diagnostics = [{"index": m["index"], "diagnostic": m.get("original_feedback", m.get(
            "diagnostic", "Original program outcome unavailable."))[:256]} for m in validation["methods"][:cap]]
    else:
        diagnostics = validation["original_feedback"][:1024]
    messages = original_prompt(api, context, suite, "generic")
    messages[1]["content"] += "\nOriginal-program feedback:\n" + json.dumps(
        diagnostics or [], ensure_ascii=False, separators=(",", ":"))
    messages[1]["content"] += "\nAvailable mutation metadata (indexed tables preserve complete visible entries):\n" + json.dumps(
        compact_feedback(rows, split), separators=(",", ":"))
    return messages


def runtime_for(command, setup):
    runtime = Runtime(command)
    runtime.helpers = setup / "helpers"
    runtime.reference = setup / "reference"
    return runtime


def identity():
    return {f.name: digest(f) for f in [HERE / "protocol.json", HERE / "prepare.py",
            HERE / "runner.py", HERE / "start.sh", BASE / "freeze.json"]}


def setup_hashes(setup):
    return {p.relative_to(setup).as_posix(): digest(p) for folder in ("helpers", "reference", "contexts")
            for p in sorted((setup / folder).rglob("*")) if p.is_file()}


def verify_setup():
    remote_only()
    if HERE != HERE.resolve(strict=True) or HERE != BASE.parent / "generation_cap_20261123":
        raise ValueError("Unexpected project root")
    verify()
    receipt = read(HERE / "setup/checked.json")
    if (receipt["sources"] != identity() or receipt["setup_files"] != setup_hashes(HERE / "setup")
            or model_identity() != read(BASE / "setup/model_identity.json")):
        raise ValueError("Frozen inputs changed")
    return receipt


def prepare():
    remote_only()
    verify()
    if (HERE / "setup").exists():
        print(json.dumps(verify_setup()))
        return
    if model_identity() != read(BASE / "setup/model_identity.json"):
        raise ValueError("Unexpected Qwen snapshot")
    from transformers import AutoTokenizer
    tokenizer = AutoTokenizer.from_pretrained(MODEL, local_files_only=True)
    with tempfile.TemporaryDirectory(dir=HERE) as temp:
        stage = Path(temp) / "setup"
        stage.mkdir()
        base = BASE / "setup/runtime"
        for d in ("helpers", "reference"):
            shutil.copytree(base / d, stage / d)
        command = Commands(time.time() + 180)
        guard = (BASE / "java/CodecGuard.java").read_text()
        anchor = '        "base64_encode", new Target'
        assert guard.count(anchor) == 1
        guard = guard.replace(anchor, '        "base64_urlsafe", new Target("Base64", "org.apache.commons.codec.binary", "encodeBase64URLSafeString", Value.ARRAY, Value.STRING),\n' + anchor)
        ref = (BASE / "java/reference/org/apache/commons/codec/binary/Base64.java").read_text()
        anchor = "    public static byte[] decodeBase64("
        assert ref.count(anchor) == 1
        ref = ref.replace(anchor, "    public static String encodeBase64URLSafeString(byte[] input) {\n"
                          "        Domain.touch(); Domain.requireBytes(input);\n"
                          "        return java.util.Base64.getUrlEncoder().withoutPadding().encodeToString(input);\n    }\n\n" + anchor)
        for name, src, dest in [("CodecGuard", guard, "helpers"), ("Base64", ref, "reference")]:
            path = stage / (name + ".java")
            path.write_text(src)
            command.run(stage, "build_" + name, [JDK / "bin/javac", "-cp", stage / "helpers",
                        "-d", stage / dest, path], required=True)
        runtime = runtime_for(command, stage)
        # Upper positions have unique method bodies, so four and eight differ after deduplication.
        body = "\n".join('@Test public void t%d() { assertEquals("%s", Base64.encodeBase64URLSafeString(new byte[]{%d})); }'
                         % (i, __import__("base64").urlsafe_b64encode(bytes([i])).decode().rstrip("="), i) for i in range(1,9))
        probe = stage / "probe"
        val = runtime.validate(NEW, body, probe / "eight", probe / "methods")
        ids = prefix_ids([val["methods"]], 8)
        assert len(ids) == 8
        for i, (arg, expected, status) in enumerate([("new byte[]{(byte)251,(byte)255}", "-_8", "PASS"),
                ("new byte[]{(byte)251,(byte)255}", "+/8=", "ORIGINAL_FAILURE"), ("null", "", "OUT_OF_DOMAIN")]):
            test = '@Test public void check() { byte[] input = %s; assertEquals("%s", Base64.encodeBase64URLSafeString(input)); }' % (arg, expected)
            result = runtime.validate(NEW, test, probe / ("case"+str(i)), probe/"methods")
            assert result["methods"][0]["status"] == status, result["methods"][0]["status"]
        split = read(BASE / "setup/base64_partition.json")
        rows = runtime.pit(NEW, ids, probe / "pit")
        context = source_context(NEW)
        for cap in (4,8):
            suite = [runtime.methods[k][0] for k in ids[:cap]]
            msg = prompt(NEW, context, suite, "mutation", val, cap, rows, split)
            part = msg[1]["content"].split("\nOriginal-program feedback:\n")[1].split("\nAvailable mutation")[0]
            assert len(json.loads(part)) == cap and ("void t8(" in msg[1]["content"]) == (cap == 8)
            if cap == 4:
                assert msg == original_prompt(NEW, context, suite, "mutation", val["original_feedback"], rows, split)
        visible = compact_feedback(rows, split)
        assert len(visible["entries"]) == len(split["feedback_ids"]) and set(split["feedback_ids"]).isdisjoint(split["evaluation_ids"])
        (stage / "contexts").mkdir()
        tokens = {}
        for api in read(HERE/"protocol.json")["targets"]:
            ctx = source_context(api)
            if api != NEW:
                assert ctx == (BASE/"inputs/contexts"/(api+".txt")).read_text()
            (stage/"contexts"/(api+".txt")).write_text(ctx)
            family = APIS[api]["family"]
            empty = read(BASE/"setup/checks"/family/"empty_pit/mutants.json")
            sp = read(BASE/"setup"/(family+"_partition.json"))
            m = prompt(api, ctx, [], "mutation", val, 8, empty, sp)
            tokens[api] = len(tokenizer.apply_chat_template(m, tokenize=True, add_generation_prompt=True))
            assert tokens[api] + 4096 <= 8192
        receipt = dict(status="PREFLIGHT_PASS", sources=identity(),setup_files=setup_hashes(stage),
                       eight_valid_tests=len(ids), new_api_PIT_mutants=len(rows),prompt_tokens=tokens,
                       verified_generation_caps=[4,8], model_calls=0)
        write(stage/"checked.json",receipt)
        stage.rename(HERE/"setup")
        print(json.dumps({k:v for k,v in receipt.items() if k not in ("sources","setup_files")}),flush=True)


if __name__ == "__main__":
    prepare()
