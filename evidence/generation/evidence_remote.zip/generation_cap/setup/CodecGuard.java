import com.sun.source.tree.*;
import com.sun.source.util.JavacTask;
import com.sun.source.util.SourcePositions;
import com.sun.source.util.Trees;
import java.io.IOException;
import java.net.URI;
import java.nio.charset.StandardCharsets;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.util.ArrayList;
import java.util.Base64;
import java.util.HashMap;
import java.util.HashSet;
import java.util.List;
import java.util.Map;
import java.util.Set;
import java.util.regex.Matcher;
import java.util.regex.Pattern;
import javax.lang.model.element.Modifier;
import javax.lang.model.type.TypeKind;
import javax.tools.Diagnostic;
import javax.tools.DiagnosticCollector;
import javax.tools.JavaCompiler;
import javax.tools.JavaFileObject;
import javax.tools.SimpleJavaFileObject;
import javax.tools.StandardJavaFileManager;
import javax.tools.ToolProvider;

/**
 * Restricted test input language, adapted from revision/scripts/JavaMethodGuard.java.
 * Parses only: no attribution, annotation processing, compilation, or execution.
 * This is not a security sandbox or an input-domain/correctness check. Compilation,
 * bounded real-library execution, and independent reference execution remain separate.
 * Successful output: TOTAL\tcount, then METHOD/REJECT\tzero-based-position\tbase64.
 * Structural failures are atomic (no stdout, exit 2); rejected methods consume positions.
 */
public final class CodecGuard {
    private static final int MAX_RESPONSE_CHARS = 20000;
    private static final int MAX_RESPONSE_METHODS = 32;
    private static final int SELECTED_METHODS = 8;
    private static final int MAX_STRING_CHARS = 4096;
    private static final int MAX_DEPTH = 100;
    private static final String PREFIX = "package original;\npublic class GeneratedSuite {\n";
    private static final Pattern FENCE = Pattern.compile("\\A\\s*```java[ \\t]*\\r?\\n([\\s\\S]*)\\r?\\n```[ \\t]*\\s*\\z");
    private static final Pattern ASCII_NAME = Pattern.compile("[A-Za-z_$][A-Za-z0-9_$]*");
    private static final Set<String> ASSERTIONS = Set.of(
        "assertTrue", "assertFalse", "assertEquals", "assertNull", "assertNotNull",
        "assertSame", "assertNotSame", "assertArrayEquals", "fail");
    // All API roots are protected, including APIs other than the selected target.
    private static final Set<String> RESERVED = Set.of(
        "original", "java", "javax", "org", "GeneratedSuite", "Test", "Assert",
        "Hex", "Base64", "URLCodec", "StandardCharsets", "String", "Exception",
        "Object", "Class", "System", "Runtime", "Thread", "ProcessBuilder",
        "HexFormat", "URLEncoder", "URLDecoder", "Arrays", "Collections", "Math");

    private enum Value { NUMBER, BOOLEAN, STRING, ARRAY, CODEC, CHARSET, NULL, VOID }

    private static final class Rejected extends RuntimeException {
        Rejected(String reason) { super(reason); }
    }

    private static final class Target {
        final String owner;
        final String packageName;
        final String method;
        final Value argument;
        final Value result;

        Target(String owner, String packageName, String method, Value argument, Value result) {
            this.owner = owner;
            this.packageName = packageName;
            this.method = method;
            this.argument = argument;
            this.result = result;
        }
    }

    private static final Map<String, Target> TARGETS = Map.of(
        "hex_encode", new Target("Hex", "org.apache.commons.codec.binary", "encodeHexString", Value.ARRAY, Value.STRING),
        "hex_decode", new Target("Hex", "org.apache.commons.codec.binary", "decodeHex", Value.STRING, Value.ARRAY),
        "base64_urlsafe", new Target("Base64", "org.apache.commons.codec.binary", "encodeBase64URLSafeString", Value.ARRAY, Value.STRING),
        "base64_encode", new Target("Base64", "org.apache.commons.codec.binary", "encodeBase64String", Value.ARRAY, Value.STRING),
        "base64_decode", new Target("Base64", "org.apache.commons.codec.binary", "decodeBase64", Value.STRING, Value.ARRAY),
        "form_encode", new Target("URLCodec", "org.apache.commons.codec.net", "encode", Value.STRING, Value.STRING),
        "form_decode", new Target("URLCodec", "org.apache.commons.codec.net", "decode", Value.STRING, Value.STRING));

    private final Map<String, Value> locals = new HashMap<>();
    private final Target target;

    private CodecGuard(Target target) { this.target = target; }

    private static void require(boolean condition, String reason) {
        if (!condition) throw new Rejected(reason);
    }

    private static String encode(String value) {
        return Base64.getEncoder().encodeToString(value.getBytes(StandardCharsets.UTF_8));
    }

    public static void main(String[] args) {
        try {
            require(args.length == 2, "usage: CodecGuard <response_file> <apiId>");
            Target target = TARGETS.get(args[1]);
            require(target != null, "unknown target API");
            Path path = Paths.get(args[0]);
            require(Files.size(path) <= MAX_RESPONSE_CHARS * 4L, "response too large");
            String raw = Files.readString(path, StandardCharsets.UTF_8);
            require(raw.length() <= MAX_RESPONSE_CHARS, "response too large");
            List<String> output = extract(raw, target);
            for (String line : output) System.out.println(line);
        } catch (Rejected failure) {
            System.err.println("REJECTED: " + failure.getMessage());
            System.exit(2);
        } catch (IOException failure) {
            System.err.println("REJECTED: cannot read response or initialize parser");
            System.exit(2);
        } catch (RuntimeException | StackOverflowError failure) {
            System.err.println("REJECTED: parser failure or excessive nesting");
            System.exit(2);
        }
    }

    private static List<String> extract(String raw, Target target) throws IOException {
        String fragment = raw;
        Matcher fence = FENCE.matcher(raw);
        if (fence.matches()) {
            fragment = fence.group(1);
            require(!fragment.contains("```"), "multiple or nested fences");
        } else {
            require(!raw.contains("```"), "expected one whole-response java fence");
        }
        final String source = PREFIX + fragment + "\n}\n";
        JavaCompiler compiler = ToolProvider.getSystemJavaCompiler();
        require(compiler != null, "a JDK compiler is required");
        DiagnosticCollector<JavaFileObject> diagnostics = new DiagnosticCollector<>();
        JavaFileObject input = new SimpleJavaFileObject(
            URI.create("string:///original/GeneratedSuite.java"), JavaFileObject.Kind.SOURCE) {
            @Override public CharSequence getCharContent(boolean ignoreErrors) { return source; }
        };
        try (StandardJavaFileManager manager = compiler.getStandardFileManager(diagnostics, null, StandardCharsets.UTF_8)) {
            JavacTask task = (JavacTask) compiler.getTask(null, manager, diagnostics,
                List.of("-proc:none", "--release", "11"), null, List.of(input));
            List<CompilationUnitTree> units = new ArrayList<>();
            for (CompilationUnitTree unit : task.parse()) units.add(unit);
            for (Diagnostic<? extends JavaFileObject> diagnostic : diagnostics.getDiagnostics()) {
                require(diagnostic.getKind() != Diagnostic.Kind.ERROR,
                    "Java syntax error at wrapped line " + diagnostic.getLineNumber());
            }
            require(units.size() == 1, "expected one compilation unit");
            CompilationUnitTree unit = units.get(0);
            require("original".equals(qualifiedName(unit.getPackageName(), 0))
                && unit.getPackageAnnotations().isEmpty() && unit.getImports().isEmpty()
                && unit.getTypeDecls().size() == 1, "only test methods are accepted");
            Tree outer = unit.getTypeDecls().get(0);
            require(outer.getKind() == Tree.Kind.CLASS, "invalid wrapper class");
            ClassTree suite = (ClassTree) outer;
            require(suite.getSimpleName().contentEquals("GeneratedSuite")
                && suite.getModifiers().getFlags().equals(Set.of(Modifier.PUBLIC))
                && suite.getModifiers().getAnnotations().isEmpty()
                && suite.getTypeParameters().isEmpty() && suite.getExtendsClause() == null
                && suite.getImplementsClause().isEmpty(), "invalid wrapper class");
            require(suite.getMembers().size() >= 1 && suite.getMembers().size() <= MAX_RESPONSE_METHODS,
                "expected one to 32 complete methods");
            // Inspect the whole response for syntax/member shape before selecting a prefix.
            for (Tree member : suite.getMembers()) {
                require(member.getKind() == Tree.Kind.METHOD,
                    "fields, initializers and helper classes are forbidden");
                require(((MethodTree) member).getBody() != null, "complete methods with bodies required");
            }
            SourcePositions positions = Trees.instance(task).getSourcePositions();
            Set<String> names = new HashSet<>();
            List<String> output = new ArrayList<>();
            output.add("TOTAL\t" + suite.getMembers().size());
            int index = 0;
            for (Tree member : suite.getMembers().subList(0, Math.min(SELECTED_METHODS, suite.getMembers().size()))) {
                MethodTree method = (MethodTree) member;
                String name = method.getName().toString();
                long start = positions.getStartPosition(unit, method);
                long end = positions.getEndPosition(unit, method);
                require(start >= PREFIX.length() && end > start
                    && end <= PREFIX.length() + fragment.length(), "method escapes response bounds");
                String exact = source.substring((int) start, (int) end);
                try {
                    require(safeName(name) && names.add(name), "invalid or duplicate test method name");
                    new CodecGuard(target).checkMethod(method);
                    output.add("METHOD\t" + index + "\t" + encode(exact));
                } catch (Rejected failure) {
                    output.add("REJECT\t" + index + "\t" + encode(failure.getMessage()));
                }
                index++;
            }
            return output;
        }
    }

    private static boolean safeName(String name) {
        return ASCII_NAME.matcher(name).matches() && !RESERVED.contains(name) && !ASSERTIONS.contains(name);
    }

    private void checkMethod(MethodTree method) {
        require(method.getModifiers().getFlags().equals(Set.of(Modifier.PUBLIC)), "test must be public and non-static");
        require(method.getReturnType() instanceof PrimitiveTypeTree
            && ((PrimitiveTypeTree) method.getReturnType()).getPrimitiveTypeKind() == TypeKind.VOID,
            "test must return void");
        require(method.getParameters().isEmpty() && method.getReceiverParameter() == null
            && method.getTypeParameters().isEmpty() && method.getDefaultValue() == null
            && method.getBody() != null, "test signature must have no parameters or type parameters");
        require(method.getThrows().isEmpty() || (method.getThrows().size() == 1
            && named(qualifiedName(method.getThrows().get(0), 0), "Exception", "java.lang")),
            "only throws Exception is accepted");
        List<? extends AnnotationTree> annotations = method.getModifiers().getAnnotations();
        require(annotations.size() == 1, "exactly one @Test annotation is required");
        AnnotationTree annotation = annotations.get(0);
        require(named(qualifiedName(annotation.getAnnotationType(), 0), "Test", "org.junit")
            && annotation.getArguments().isEmpty(), "only @Test without arguments is accepted");
        for (StatementTree statement : method.getBody().getStatements()) {
            switch (statement.getKind()) {
                case VARIABLE:
                    VariableTree local = (VariableTree) statement;
                    require(local.getModifiers().getAnnotations().isEmpty()
                        && (local.getModifiers().getFlags().isEmpty()
                            || local.getModifiers().getFlags().equals(Set.of(Modifier.FINAL))),
                        "invalid local modifiers");
                    String name = local.getName().toString();
                    require(safeName(name) && !locals.containsKey(name), "invalid or shadowing local name");
                    Value type = safeType(local.getType(), 0);
                    require(local.getInitializer() != null, "local variable must have an initializer");
                    require(expression(local.getInitializer(), 0) != Value.VOID, "void initializer");
                    locals.put(name, type);
                    break;
                case EXPRESSION_STATEMENT:
                    expression(((ExpressionStatementTree) statement).getExpression(), 0);
                    break;
                default:
                    throw new Rejected("statement is not straight-line: " + statement.getKind());
            }
        }
    }

    private static void depth(int nesting) {
        require(nesting <= MAX_DEPTH, "expression or type nesting too deep");
    }

    private static String qualifiedName(Tree tree, int nesting) {
        depth(nesting);
        if (tree == null) return "";
        if (tree.getKind() == Tree.Kind.IDENTIFIER) return ((IdentifierTree) tree).getName().toString();
        if (tree.getKind() == Tree.Kind.MEMBER_SELECT) {
            MemberSelectTree member = (MemberSelectTree) tree;
            String parent = qualifiedName(member.getExpression(), nesting + 1);
            return parent.isEmpty() ? "" : parent + "." + member.getIdentifier();
        }
        return "";
    }

    private static boolean named(String actual, String simple, String packageName) {
        return actual.equals(simple) || actual.equals(packageName + "." + simple);
    }

    private static boolean byteType(Tree tree) {
        return tree instanceof PrimitiveTypeTree
            && ((PrimitiveTypeTree) tree).getPrimitiveTypeKind() == TypeKind.BYTE;
    }

    private static Value safeType(Tree tree, int nesting) {
        depth(nesting);
        require(tree != null, "explicit allowed type required");
        switch (tree.getKind()) {
            case PRIMITIVE_TYPE:
                TypeKind kind = ((PrimitiveTypeTree) tree).getPrimitiveTypeKind();
                require(kind != TypeKind.VOID, "void value type forbidden");
                return kind == TypeKind.BOOLEAN ? Value.BOOLEAN : Value.NUMBER;
            case ARRAY_TYPE:
                require(byteType(((ArrayTypeTree) tree).getType()), "only one-dimensional byte arrays are accepted");
                return Value.ARRAY;
            case IDENTIFIER:
            case MEMBER_SELECT:
                String name = qualifiedName(tree, nesting + 1);
                if (named(name, "String", "java.lang")) return Value.STRING;
                if (named(name, "URLCodec", "org.apache.commons.codec.net")) return Value.CODEC;
                throw new Rejected("type outside allowlist");
            default:
                throw new Rejected("type syntax outside allowlist: " + tree.getKind());
        }
    }

    private Value expression(ExpressionTree tree, int nesting) {
        depth(nesting);
        require(tree != null, "missing expression");
        switch (tree.getKind()) {
            case BOOLEAN_LITERAL: return Value.BOOLEAN;
            case CHAR_LITERAL:
            case INT_LITERAL:
            case LONG_LITERAL:
            case FLOAT_LITERAL:
            case DOUBLE_LITERAL: return Value.NUMBER;
            case NULL_LITERAL: return Value.NULL;
            case STRING_LITERAL:
                require(((String) ((LiteralTree) tree).getValue()).length() <= MAX_STRING_CHARS, "string literal too long");
                return Value.STRING;
            case IDENTIFIER:
                Value local = locals.get(((IdentifierTree) tree).getName().toString());
                require(local != null, "undeclared or forbidden expression name");
                return local;
            case PARENTHESIZED:
                return expression(((ParenthesizedTree) tree).getExpression(), nesting + 1);
            case UNARY_PLUS:
            case UNARY_MINUS:
                require(expression(((UnaryTree) tree).getExpression(), nesting + 1) == Value.NUMBER,
                    "numeric unary operand required");
                return Value.NUMBER;
            case PLUS:
            case MINUS:
            case MULTIPLY:
            case DIVIDE:
            case REMAINDER:
            case LESS_THAN:
            case LESS_THAN_EQUAL:
            case GREATER_THAN:
            case GREATER_THAN_EQUAL:
                BinaryTree numeric = (BinaryTree) tree;
                require(expression(numeric.getLeftOperand(), nesting + 1) == Value.NUMBER
                    && expression(numeric.getRightOperand(), nesting + 1) == Value.NUMBER,
                    "numeric binary operands required");
                switch (tree.getKind()) {
                    case PLUS: case MINUS: case MULTIPLY: case DIVIDE: case REMAINDER: return Value.NUMBER;
                    default: return Value.BOOLEAN;
                }
            case EQUAL_TO:
            case NOT_EQUAL_TO:
                BinaryTree equality = (BinaryTree) tree;
                require(expression(equality.getLeftOperand(), nesting + 1) != Value.VOID
                    && expression(equality.getRightOperand(), nesting + 1) != Value.VOID, "void comparison forbidden");
                return Value.BOOLEAN;
            case TYPE_CAST:
                TypeCastTree cast = (TypeCastTree) tree;
                require(byteType(cast.getType()) && expression(cast.getExpression(), nesting + 1) == Value.NUMBER,
                    "only numeric byte casts are accepted");
                return Value.NUMBER;
            case NEW_ARRAY:
                NewArrayTree array = (NewArrayTree) tree;
                require(array.getDimensions().isEmpty() && array.getInitializers() != null
                    && array.getAnnotations().isEmpty(), "only inline initialized byte arrays are accepted");
                for (List<? extends AnnotationTree> annotations : array.getDimAnnotations()) {
                    require(annotations.isEmpty(), "array annotations forbidden");
                }
                require(array.getType() == null || byteType(array.getType()), "only byte array construction is accepted");
                for (ExpressionTree item : array.getInitializers()) {
                    require(expression(item, nesting + 1) == Value.NUMBER, "numeric byte array element required");
                }
                return Value.ARRAY;
            case ARRAY_ACCESS:
                ArrayAccessTree access = (ArrayAccessTree) tree;
                require(expression(access.getExpression(), nesting + 1) == Value.ARRAY
                    && expression(access.getIndex(), nesting + 1) == Value.NUMBER, "byte array access required");
                return Value.NUMBER;
            case NEW_CLASS:
                return construction((NewClassTree) tree, nesting + 1);
            case MEMBER_SELECT:
                MemberSelectTree member = (MemberSelectTree) tree;
                if (utf8Constant(member, nesting + 1)) return Value.CHARSET;
                require(member.getIdentifier().contentEquals("length")
                    && expression(member.getExpression(), nesting + 1) == Value.ARRAY,
                    "field or constant outside allowlist");
                return Value.NUMBER;
            case METHOD_INVOCATION:
                return invocation((MethodInvocationTree) tree, nesting + 1);
            default:
                throw new Rejected("expression outside allowlist: " + tree.getKind());
        }
    }

    private Value construction(NewClassTree tree, int nesting) {
        depth(nesting);
        require(tree.getClassBody() == null && tree.getEnclosingExpression() == null
            && tree.getTypeArguments().isEmpty(), "anonymous or qualified constructor forbidden");
        require(named(qualifiedName(tree.getIdentifier(), nesting + 1), "URLCodec", "org.apache.commons.codec.net")
            && tree.getArguments().isEmpty(), "only new URLCodec() construction is accepted");
        return Value.CODEC;
    }

    private static boolean utf8Constant(ExpressionTree tree, int nesting) {
        if (!(tree instanceof MemberSelectTree)) return false;
        MemberSelectTree member = (MemberSelectTree) tree;
        return member.getIdentifier().contentEquals("UTF_8")
            && named(qualifiedName(member.getExpression(), nesting + 1), "StandardCharsets", "java.nio.charset");
    }

    private static boolean utf8Literal(ExpressionTree tree, int nesting) {
        depth(nesting);
        if (tree instanceof ParenthesizedTree) {
            return utf8Literal(((ParenthesizedTree) tree).getExpression(), nesting + 1);
        }
        return tree.getKind() == Tree.Kind.STRING_LITERAL && "UTF-8".equals(((LiteralTree) tree).getValue());
    }

    private Value invocation(MethodInvocationTree call, int nesting) {
        depth(nesting);
        require(call.getTypeArguments().isEmpty(), "generic invocation arguments forbidden");
        List<Value> arguments = new ArrayList<>();
        for (ExpressionTree argument : call.getArguments()) {
            Value value = expression(argument, nesting + 1);
            require(value != Value.VOID, "void call argument forbidden");
            arguments.add(value);
        }
        ExpressionTree select = call.getMethodSelect();
        if (select.getKind() == Tree.Kind.IDENTIFIER) {
            require(ASSERTIONS.contains(((IdentifierTree) select).getName().toString()),
                "unqualified call outside assertion allowlist");
            return Value.VOID;
        }
        require(select.getKind() == Tree.Kind.MEMBER_SELECT, "unsupported method selection");
        MemberSelectTree member = (MemberSelectTree) select;
        String name = member.getIdentifier().toString();
        String owner = qualifiedName(member.getExpression(), nesting + 1);
        if (named(owner, "Assert", "org.junit") && ASSERTIONS.contains(name)) return Value.VOID;
        if (!target.owner.equals("URLCodec") && named(owner, target.owner, target.packageName)
            && name.equals(target.method)) {
            require(arguments.size() == 1 && (arguments.get(0) == target.argument || arguments.get(0) == Value.NULL),
                "invalid target API arguments");
            return target.result;
        }
        if (target.owner.equals("URLCodec") && name.equals(target.method)) {
            require(expression(member.getExpression(), nesting + 1) == Value.CODEC,
                "URLCodec instance receiver required");
            require(arguments.size() == 2 && (arguments.get(0) == Value.STRING || arguments.get(0) == Value.NULL)
                && utf8Literal(call.getArguments().get(1), nesting + 1), "URLCodec requires String and literal UTF-8");
            return Value.STRING;
        }
        require(Set.of("getBytes", "equals", "length", "isEmpty").contains(name), "method outside API allowlist");
        require(expression(member.getExpression(), nesting + 1) == Value.STRING, "safe string receiver required");
        switch (name) {
            case "getBytes":
                require(arguments.size() == 1 && (arguments.get(0) == Value.CHARSET
                    || utf8Literal(call.getArguments().get(0), nesting + 1)), "getBytes requires explicit UTF-8");
                return Value.ARRAY;
            case "equals":
                require(arguments.size() == 1, "invalid equals arity");
                return Value.BOOLEAN;
            case "length":
                require(arguments.isEmpty(), "invalid length arity");
                return Value.NUMBER;
            case "isEmpty":
                require(arguments.isEmpty(), "invalid isEmpty arity");
                return Value.BOOLEAN;
            default: throw new Rejected("unknown string operation");
        }
    }
}
