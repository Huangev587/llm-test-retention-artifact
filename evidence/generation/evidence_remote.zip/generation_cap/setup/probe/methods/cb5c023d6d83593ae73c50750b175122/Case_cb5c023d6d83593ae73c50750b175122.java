package entry;
import org.junit.Test;
import org.junit.Assert;
import static org.junit.Assert.*;
import java.nio.charset.StandardCharsets;
import org.apache.commons.codec.binary.Hex;
import org.apache.commons.codec.binary.Base64;
import org.apache.commons.codec.net.URLCodec;
public class Case_cb5c023d6d83593ae73c50750b175122 {
@Test public void t8() { assertEquals("CA", Base64.encodeBase64URLSafeString(new byte[]{8})); }
}
