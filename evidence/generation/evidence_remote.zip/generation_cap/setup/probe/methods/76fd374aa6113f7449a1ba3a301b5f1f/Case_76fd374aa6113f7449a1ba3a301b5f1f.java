package entry;
import org.junit.Test;
import org.junit.Assert;
import static org.junit.Assert.*;
import java.nio.charset.StandardCharsets;
import org.apache.commons.codec.binary.Hex;
import org.apache.commons.codec.binary.Base64;
import org.apache.commons.codec.net.URLCodec;
public class Case_76fd374aa6113f7449a1ba3a301b5f1f {
@Test public void check() { byte[] input = null; assertEquals("", Base64.encodeBase64URLSafeString(input)); }
}
