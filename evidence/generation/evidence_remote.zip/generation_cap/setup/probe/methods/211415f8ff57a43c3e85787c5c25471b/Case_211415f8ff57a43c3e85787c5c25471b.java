package entry;
import org.junit.Test;
import org.junit.Assert;
import static org.junit.Assert.*;
import java.nio.charset.StandardCharsets;
import org.apache.commons.codec.binary.Hex;
import org.apache.commons.codec.binary.Base64;
import org.apache.commons.codec.net.URLCodec;
public class Case_211415f8ff57a43c3e85787c5c25471b {
@Test public void check() { byte[] input = new byte[]{(byte)251,(byte)255}; assertEquals("+/8=", Base64.encodeBase64URLSafeString(input)); }
}
