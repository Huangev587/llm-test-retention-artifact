package entry;
import org.junit.Test;
import org.junit.Assert;
import static org.junit.Assert.*;
import java.nio.charset.StandardCharsets;
import org.apache.commons.codec.binary.Hex;
import org.apache.commons.codec.binary.Base64;
import org.apache.commons.codec.net.URLCodec;
public class Case_2f8f109824473bf7f624cd90cf3a9a97 {
@Test public void check() { byte[] input = new byte[]{(byte)251,(byte)255}; assertEquals("-_8", Base64.encodeBase64URLSafeString(input)); }
}
