package entry;
import org.junit.Test;
import org.junit.Assert;
import static org.junit.Assert.*;
import java.nio.charset.StandardCharsets;
import org.apache.commons.codec.binary.Hex;
import org.apache.commons.codec.binary.Base64;
import org.apache.commons.codec.net.URLCodec;
public class Case_7d8210344ba21041f14653bfae3897ae {
@Test public void t4() { assertEquals("BA", Base64.encodeBase64URLSafeString(new byte[]{4})); }
}
