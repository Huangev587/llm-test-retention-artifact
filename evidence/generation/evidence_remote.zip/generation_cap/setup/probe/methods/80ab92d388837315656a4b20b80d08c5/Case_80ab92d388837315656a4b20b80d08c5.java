package entry;
import org.junit.Test;
import org.junit.Assert;
import static org.junit.Assert.*;
import java.nio.charset.StandardCharsets;
import org.apache.commons.codec.binary.Hex;
import org.apache.commons.codec.binary.Base64;
import org.apache.commons.codec.net.URLCodec;
public class Case_80ab92d388837315656a4b20b80d08c5 {
@Test public void t3() { assertEquals("Aw", Base64.encodeBase64URLSafeString(new byte[]{3})); }
}
