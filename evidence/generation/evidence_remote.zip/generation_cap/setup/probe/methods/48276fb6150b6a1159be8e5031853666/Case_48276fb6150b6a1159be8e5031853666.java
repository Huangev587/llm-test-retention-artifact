package entry;
import org.junit.Test;
import org.junit.Assert;
import static org.junit.Assert.*;
import java.nio.charset.StandardCharsets;
import org.apache.commons.codec.binary.Hex;
import org.apache.commons.codec.binary.Base64;
import org.apache.commons.codec.net.URLCodec;
public class Case_48276fb6150b6a1159be8e5031853666 {
@Test public void t6() { assertEquals("Bg", Base64.encodeBase64URLSafeString(new byte[]{6})); }
}
