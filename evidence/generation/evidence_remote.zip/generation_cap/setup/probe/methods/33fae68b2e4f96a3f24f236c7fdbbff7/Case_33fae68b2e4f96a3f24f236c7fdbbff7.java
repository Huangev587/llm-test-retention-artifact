package entry;
import org.junit.Test;
import org.junit.Assert;
import static org.junit.Assert.*;
import java.nio.charset.StandardCharsets;
import org.apache.commons.codec.binary.Hex;
import org.apache.commons.codec.binary.Base64;
import org.apache.commons.codec.net.URLCodec;
public class Case_33fae68b2e4f96a3f24f236c7fdbbff7 {
@Test public void t5() { assertEquals("BQ", Base64.encodeBase64URLSafeString(new byte[]{5})); }
}
