package entry;
import org.junit.Test;
import org.junit.Assert;
import static org.junit.Assert.*;
import java.nio.charset.StandardCharsets;
import org.apache.commons.codec.binary.Hex;
import org.apache.commons.codec.binary.Base64;
import org.apache.commons.codec.net.URLCodec;
public class Case_7f2779edda2cbd81dbf5604b6e560a97 {
@Test public void t1() { assertEquals("AQ", Base64.encodeBase64URLSafeString(new byte[]{1})); }
}
