package entry;
import org.junit.Test;
import org.junit.Assert;
import static org.junit.Assert.*;
import java.nio.charset.StandardCharsets;
import org.apache.commons.codec.binary.Hex;
import org.apache.commons.codec.binary.Base64;
import org.apache.commons.codec.net.URLCodec;
public class Case_27e13311f481836f4092556896757fd9 {
@Test public void t2() { assertEquals("Ag", Base64.encodeBase64URLSafeString(new byte[]{2})); }
}
