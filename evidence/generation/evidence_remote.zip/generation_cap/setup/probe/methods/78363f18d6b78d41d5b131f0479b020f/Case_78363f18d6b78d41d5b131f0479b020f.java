package entry;
import org.junit.Test;
import org.junit.Assert;
import static org.junit.Assert.*;
import java.nio.charset.StandardCharsets;
import org.apache.commons.codec.binary.Hex;
import org.apache.commons.codec.binary.Base64;
import org.apache.commons.codec.net.URLCodec;
public class Case_78363f18d6b78d41d5b131f0479b020f {
@Test public void t7() { assertEquals("Bw", Base64.encodeBase64URLSafeString(new byte[]{7})); }
}
