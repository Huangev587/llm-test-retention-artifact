package org.apache.commons.codec.binary;

import entry.Domain;

/** Restricted JDK reference facade; this class never calls Commons conversions. */
public final class Base64 {
    private Base64() { }

    public static String encodeBase64String(byte[] input) {
        Domain.touch();
        Domain.requireBytes(input);
        return java.util.Base64.getEncoder().encodeToString(input);
    }

    public static String encodeBase64URLSafeString(byte[] input) {
        Domain.touch(); Domain.requireBytes(input);
        return java.util.Base64.getUrlEncoder().withoutPadding().encodeToString(input);
    }

    public static byte[] decodeBase64(String input) {
        Domain.touch();
        return Domain.decodeCanonicalBase64(input);
    }
}
