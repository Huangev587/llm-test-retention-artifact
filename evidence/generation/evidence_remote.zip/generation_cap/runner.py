"""Paired, sampled generation followed by held-out replay at both position caps."""
import hashlib
import json
import os
import sys
import tempfile
import time
from pathlib import Path

sys.path.insert(0, str(Path(__file__).resolve().parent))
from prepare import HERE, BASE, APIS, MODEL, Commands, digest, read, runtime_for, prefix_ids, prompt, verify_setup

PLAN = read(HERE / "protocol.json")
OUT = HERE / "outputs"


def save(path, value):
    path.parent.mkdir(parents=True, exist_ok=True)
    with tempfile.NamedTemporaryFile(mode="w", encoding="utf-8", dir=path.parent, delete=False) as f:
        json.dump(value, f, ensure_ascii=False, indent=2)
        f.flush()
        os.fsync(f.fileno())
    os.replace(f.name, path)


def random_seed(api, repeat, step):
    raw = f"paired-cap-20261123/{api}/{repeat}/{step}".encode()
    return int.from_bytes(hashlib.sha256(raw).digest()[:8], "big") % (2**63)


def signed_order(delta):
    return (delta > 0) - (delta < 0)


def transition(first, second):
    a, b = signed_order(first), signed_order(second)
    if a == b:
        return "same_order"
    if a*b == -1:
        return "strict_reversal"
    return "lead_to_tie" if b == 0 else "tie_to_lead"


class Generation:
    def __init__(self):
        import torch
        import transformers
        from transformers import AutoTokenizer, AutoModelForCausalLM
        if torch.__version__ != "2.5.1+cu124" or transformers.__version__ != "4.57.6":
            raise RuntimeError("Unexpected Paper inference environment")
        self.torch = torch
        torch.set_num_threads(2)
        self.tok = AutoTokenizer.from_pretrained(MODEL, local_files_only=True)
        self.model = AutoModelForCausalLM.from_pretrained(MODEL, dtype=torch.bfloat16,
                        device_map={"":0}, attn_implementation="sdpa", use_safetensors=True,
                        local_files_only=True).eval()

    def sample(self, path, messages, rng):
        request = dict(messages=messages, seed=rng, sampling=PLAN["sampling"])
        if (path/"response.json").is_file():
            assert read(path/"request.json") == request
            return read(path/"response.json")["text"]
        if path.exists():
            raise RuntimeError(f"Unfinished generation at {path}; inspect before reusing its budget")
        # Every model forward begins after its unique request is recorded.
        if sum(1 for _ in OUT.glob("blocks/*/*/calls/*/request.json")) >= PLAN["max_calls"]:
            raise RuntimeError("Call budget exhausted")
        text = self.tok.apply_chat_template(messages,tokenize=False,add_generation_prompt=True)
        inputs = self.tok(text,return_tensors="pt").to("cuda:0")
        n = int(inputs.input_ids.shape[-1])
        if n > PLAN["max_input_tokens"] or n + PLAN["sampling"]["max_new_tokens"] > self.model.config.max_position_embeddings:
            raise ValueError("Input exceeds the frozen token budget")
        path.mkdir(parents=True, exist_ok=False)
        save(path/"request.json",request)
        self.torch.manual_seed(rng)
        start = time.monotonic()
        with self.torch.inference_mode():
            tokens = self.model.generate(**inputs,**PLAN["sampling"], num_beams=1, num_return_sequences=1,
                        pad_token_id=self.tok.pad_token_id if self.tok.pad_token_id is not None else self.tok.eos_token_id)
        continuation = tokens[0,n:]
        response = self.tok.decode(continuation,skip_special_tokens=True)
        save(path/"response.json",dict(text=response,input_tokens=n,output_tokens=len(continuation),
                                       seconds=round(time.monotonic()-start,3)))
        return response


def validated(runtime, api, block, slot, response):
    dest = block/"validations"/slot
    if not dest.exists():
        dest.parent.mkdir(parents=True,exist_ok=True)
        with tempfile.TemporaryDirectory(dir=dest.parent) as tmp:
            stage = Path(tmp)/"complete"
            runtime.validate(api,response,stage/"output",stage/"methods")
            stage.rename(dest)
    assert (dest/"output/response.txt").read_text(encoding="utf-8") == response
    result = read(dest/"output/result.json")
    # validate() registers transient paths while compiling. Bind every valid ID to durable files.
    for method in result["methods"]:
        if method["status"] == "PASS":
            key = method["id"]
            folder = dest/"methods"/key
            runtime.methods[key] = (read(folder/"result.json"),folder)
    return result


def pit(runtime, api, ids):
    key = hashlib.sha256(json.dumps(ids).encode()).hexdigest()
    dest = OUT/"pit"/api/key
    if not dest.exists():
        dest.parent.mkdir(parents=True,exist_ok=True)
        with tempfile.TemporaryDirectory(dir=dest.parent) as tmp:
            stage = Path(tmp)/"complete"
            runtime.pit(api,ids,stage)
            save(stage/"ids.json",ids)
            stage.rename(dest)
    assert read(dest/"ids.json") == ids
    return read(dest/"mutants.json")


def run_block(api, repeat, command, model):
    block = OUT/"blocks"/api/str(repeat)
    runtime = runtime_for(command,HERE/"setup")
    exposures = []
    split = read(BASE/"setup"/(APIS[api]["family"]+"_partition.json"))
    ctx = (HERE/"setup/contexts"/(api+".txt")).read_text()
    def generate(slot, arm, histories, cap, step):
        ids = prefix_ids([v["methods"] for v in histories],cap)
        if histories:
            first_four = prefix_ids([v["methods"] for v in histories],4)
            exposures.append(dict(slot=slot, generation_cap=cap, retained=len(ids),
                                  retained_only_from_late_positions=sorted(set(ids)-set(first_four)),
                                  last_response_diagnostic_positions=min(cap,len(histories[-1]["methods"]))
                                  if arm=="mutation" else 0))
        suite = [runtime.methods[i][0] for i in ids]
        rows = pit(runtime,api,ids) if arm == "mutation" else None
        messages = prompt(api,ctx,suite,arm,histories[-1] if histories else None,cap,rows,split)
        rng = random_seed(api,repeat,step)
        text = model.sample(block/"calls"/slot,messages,rng)
        return validated(runtime,api,block,slot,text)

    seed = generate("initial","seed",[],4,0)
    plans = {}
    for cap in PLAN["caps"]:
        for arm in PLAN["arms"]:
            hist = [seed]
            for step in range(1,PLAN["continuations"]+1):
                slot = f"cap{cap}_{arm}_{step}"
                print(f"GENERATING {api} repeat={repeat} {slot}",flush=True)
                hist.append(generate(slot,arm,hist,cap,step))
            for replay in PLAN["caps"]:
                plans[f"{arm}_{cap}_{replay}"] = prefix_ids([v["methods"] for v in hist],replay)
    save(block/"selections.json",plans)
    scores = {}
    for cell, ids in plans.items():
        rows = [r for r in pit(runtime,api,ids) if r["id"] in split["evaluation_ids"]]
        assert sorted(r["id"] for r in rows)==split["evaluation_ids"]
        unresolved = [r["id"] for r in rows if r["status"] not in ("KILLED","SURVIVED","NO_COVERAGE")]
        killed = [r["id"] for r in rows if r["status"] == "KILLED"]
        scores[cell] = dict(valid=len(ids),catalog=len(rows),killed=len(killed),killed_ids=killed,
                            unresolved=unresolved)
    gaps = {f"{c}_{k}": scores[f"generic_{c}_{k}"]["killed"]-scores[f"mutation_{c}_{k}"]["killed"]
            for c in PLAN["caps"] for k in PLAN["caps"]}
    # Lower and upper bounds cover every unresolved evaluation status.
    bounds = {}
    for c in PLAN["caps"]:
        for k in PLAN["caps"]:
            d = gaps[f"{c}_{k}"]
            bounds[f"{c}_{k}"] = [d-len(scores[f"mutation_{c}_{k}"]["unresolved"]),
                                   d+len(scores[f"generic_{c}_{k}"]["unresolved"])]
    result = dict(api=api,seed=repeat,scores=scores,gaps=gaps,gap_bounds=bounds,feedback_exposure=exposures,
                  native_transition=transition(gaps["4_4"],gaps["8_8"]),
                  seeded_replay_transition=transition(gaps["4_4"],gaps["4_8"]),
                  matched_scoring_cap_transition=transition(gaps["4_8"],gaps["8_8"]))
    save(block/"result.json",result)
    return result


def main():
    freeze = verify_setup()
    os.environ.update(TRANSFORMERS_OFFLINE="1",HF_HUB_OFFLINE="1")
    config = OUT/"batch.json"
    if config.exists():
        batch = read(config)
        if batch["sources"] != freeze["sources"]:
            raise RuntimeError("Protocol or scripts changed since batch start")
    else:
        batch = dict(sources=freeze["sources"],deadline=time.time()+PLAN["wall_seconds"])
        save(config,batch)
    command = Commands(batch["deadline"])
    blocks = []
    model = None
    for i, repeat in enumerate(PLAN["seeds"]):
        targets = list(PLAN["targets"])
        for api in targets[i:]+targets[:i]:
            result = OUT/"blocks"/api/str(repeat)/"result.json"
            if not result.exists():
                if time.time() >= batch["deadline"]:
                    raise TimeoutError("Batch deadline reached")
                if model is None:
                    model = Generation()
                print(f"BLOCK {len(blocks)+1}/9 {api} seed={repeat}",flush=True)
                run_block(api,repeat,command,model)
            blocks.append(read(result))
    calls=sum(1 for _ in OUT.glob("blocks/*/*/calls/*/response.json"))
    assert len(blocks)==9 and calls==PLAN["max_calls"]
    result=dict(status="COMPLETE_VALUE_REVIEW_PENDING",blocks=blocks,model_calls=calls,
                protocol_sha256=digest(HERE/"protocol.json"))
    save(OUT/"results.json",result)
    print(json.dumps(dict(status=result["status"],blocks=len(blocks),model_calls=calls,result=str(OUT/"results.json"))),flush=True)


if __name__=="__main__":
    main()
