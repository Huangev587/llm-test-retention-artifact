"""Enumerate one recorded zero-/few-shot round per class and model."""
import hashlib
import itertools
import json
from collections import Counter, defaultdict
from fractions import Fraction
from pathlib import Path


def summarize(rows):
    groups = defaultdict(list)
    for row in rows:
        groups[row["target"], row["model"]].append(row)
    models_per_class = Counter(target for target, _ in groups)
    class_count = len(models_per_class)
    options = []
    for (target, _), group in sorted(groups.items()):
        weight = Fraction(100, class_count * models_per_class[target])
        rounds = []
        for row in group:
            g4, g8 = row["prefix"]["gaps"]
            changed = (g4 > 0, g4 < 0) != (g8 > 0, g8 < 0)
            rounds.append((weight * g4 / row["n"], weight * g8 / row["n"], changed))
        options.append(rounds)
    choices = []
    for selected in itertools.product(*options):
        first4, first8, changed = map(sum, zip(*selected))
        choices.append((first4, first8, first8 - first4, changed))
    def bounds(column):
        values = [row[column] for row in choices]
        return [float(min(values)), float(max(values))]
    return {
        "pairs": len(rows), "classes": class_count, "class_model_groups": len(groups),
        "observed_round_options_per_group": {f"{t}/{m}": [r["pair"] for r in g]
                                              for (t, m), g in sorted(groups.items())},
        "possible_selections": len(choices),
        "zero_shot_ahead_at_both_caps": sum(a > 0 and b > 0 for a, b, _, _ in choices),
        "mean_gap_pp_first4": bounds(0), "mean_gap_pp_first8": bounds(1),
        "paired_change_in_mean_gap_pp": bounds(2),
        "number_of_local_order_changes": [int(v) for v in bounds(3)],
    }


if __name__ == "__main__":
    research = Path(__file__).resolve().parents[5]
    folder = research / "experiments/external_retention_sbes_20261118/outputs/formal_review"
    data = (folder / "review.json").read_bytes()
    sha = hashlib.sha256(data).hexdigest()
    if sha != "8831e433961e28b33b5045063122c4eea78025edea26052ec24989161c37e653":
        raise ValueError("Unexpected audit input")
    result = summarize(json.loads(data)["pairs"])
    result.update(input_sha256=sha, design="Post hoc enumeration over observed rounds. "
                  "Equal model weights within each class and equal weights across classes. "
                  "Each chosen round is shared by both caps. Ranges are descriptive.")
    (folder / "round_sensitivity.json").write_text(json.dumps(result, indent=2) + "\n",
                                                  encoding="utf-8")
    print(json.dumps({k: v for k, v in result.items() if k != "observed_round_options_per_group"}))
