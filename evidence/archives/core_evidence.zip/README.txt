Run: python core_evidence.zip (Python 3.9+, standard library).
Offline re-scoring of stored PIT reports for Sections 4.7 and 4.13.
No generation or Java execution. Upstream Java suites and original catalogs: https://doi.org/10.5281/zenodo.21230015
manifest.json specifies fixed mutant IDs and XML file hashes. In each pair of reports the order is generic/mutation (Codec) or zero-shot/few-shot (archive). The outer order is caps 4 and 8 for the primary panels, or 4 and the recorded common upper cap (5, 6 or 7) for short_suites. Excluded short suites include their archived or replayed full-suite timeout XML. codec_response.txt is the saved second generic continuation for form decoding. Its method positions and validation records can be matched to the killing tests named by PIT.
