"""Pack the local records with --pack. Reviewers can run the ZIP directly with Python."""
import hashlib
import json
import re
import statistics
import sys
import tarfile
import xml.etree.ElementTree as ET
import zipfile
from collections import Counter, defaultdict
from fractions import Fraction
from pathlib import Path

from round_sensitivity import summarize


def sha(data):
    return hashlib.sha256(data).hexdigest()


def mutant_id(node):
    key = [node.findtext(field) for field in
           ("mutatedClass", "mutatedMethod", "methodDescription", "mutator")]
    key.append([int(n.text) for n in node.findall("indexes/index")])
    return json.dumps(key, separators=(",", ":"))


def states(data):
    rows = {}
    for node in ET.fromstring(data).findall("mutation"):
        identifier = mutant_id(node)
        if identifier in rows:
            raise ValueError("Repeated PIT mutant ID")
        rows[identifier] = node.attrib["status"]
    return rows


def pack():
    script = Path(__file__).resolve()
    revision = script.parents[1]
    experiments = script.parents[5] / "experiments"
    codec = experiments / "mutgen_budget_pilot_20261111/revision/external_confirmation"
    external = experiments / "external_retention_sbes_20261118"
    review = external / "outputs/formal_review"
    checked = json.loads((review / "review.json").read_bytes())
    manifest = {"catalogs": {}, "pairs": [], "short_suites": []}
    reports = {}

    def register(raw):
        digest = sha(raw)
        reports[digest] = raw
        return digest

    manifest["catalogs"]["form_decode"] = json.loads(
        (codec / "setup/form_partition.json").read_bytes())["evaluation_ids"]
    run_dir = codec / "outputs/run"
    slot = Path("form_decode/generic_2")
    response_dir = run_dir / "responses" / slot
    raw_response = (response_dir / "response.txt").read_bytes()
    original_call = json.loads((run_dir / "calls" / slot / "result.json").read_bytes())
    if raw_response.decode("utf-8").splitlines() != original_call["response"].splitlines():
        raise ValueError("Retained response differs from the call record")
    validation = json.loads((response_dir / "result.json").read_bytes())
    manifest["codec_response"] = {
        "slot": slot.as_posix(), "sha256": sha(raw_response),
        "positions": [{"position": m["index"] + 1, "class_name": m["class_name"], "status": m["status"]}
                      for m in validation["methods"]],
    }
    codec_rows = json.loads((codec / "analysis/audit.json").read_bytes())["apis"]["form_decode"]["rows"]
    by_arm = {(row["arm"], row["rule"]): row for row in codec_rows}
    manifest["codec"] = []
    for cap in (4, 8):
        arm_reports = []
        for arm in ("generic", "mutation"):
            row = by_arm[arm, f"positions_{cap}"]
            xml = codec / "outputs/run/pit/form_decode" / row["suite_hash"] / "raw/mutations.xml"
            arm_reports.append(register(xml.read_bytes()))
        manifest["codec"].append(arm_reports)
    archive = review / "formal.tar.gz"
    if sha(archive.read_bytes()) != checked["evidence_archive_sha256"]:
        raise ValueError("Unexpected formal replay archive")
    upstream = external / "inputs/repository-empirical-study-sbes.zip"
    def catalog(original, target):
        if target not in manifest["catalogs"]:
            member = f"experiments/{target}/mutation-testing/fixed-mutants/report/mutations.xml"
            manifest["catalogs"][target] = sorted(states(original.read(member)))

    def suite_xml(tar, base, key, rec, arm):
        run = rec["runs"][arm].get("same_subset_as", arm)
        member = f"{base}/pairs/{key}/{rec['evidence']}/{run}/pit/mutations.xml"
        return register(tar.extractfile(member).read())

    def prefix_reports(tar, base, key, rec, upper):
        return [[suite_xml(tar, base, key, rec, f"{prompt}_first{cap}")
                 for prompt in ("zero_shot", "few_shot")] for cap in (4, upper)]

    with tarfile.open(archive) as tar, zipfile.ZipFile(upstream) as original:
        plan = json.load(tar.extractfile("formal/plan.json"))
        if sha(upstream.read_bytes()) != plan["archive_sha256"]:
            raise ValueError("Unexpected third-party archive")
        records = json.load(tar.extractfile("formal/results.json"))["results"]
        for row in checked["pairs"]:
            key, target = row["pair"], row["target"]
            rec = records[key]
            catalog(original, target)
            prefix = prefix_reports(tar, "formal", key, rec, 8)
            manifest["pairs"].append(dict(pair=key, target=target, model=row["model"], reports=prefix))
    short = external / "outputs/short_suites"
    audit = json.loads((short / "review.json").read_bytes())
    archive = short / "run.tar.gz"
    if sha(archive.read_bytes()) != audit["evidence_sha256"]:
        raise ValueError("Unexpected short-suite archive")
    with tarfile.open(archive) as tar, zipfile.ZipFile(upstream) as original:
        records = json.load(tar.extractfile("run/results.json"))["results"]
        for case in audit["pairs"]:
            key, target, upper = case["pair"], case["target"], case["upper"]
            rec = records[key]
            catalog(original, target)
            item = dict(pair=key, target=target, upper=upper, status=case["status"])
            if case["status"] == "COMPARED":
                item["reports"] = prefix_reports(tar, "run", key, rec, upper)
            elif case["status"] == "ARCHIVED_UNRESOLVED":
                members = []
                for prompt in rec["issues"]:
                    suite = Path(rec["pair"][prompt + "_source"]).stem
                    members.append(f"experiments/{target}/mutation-testing/suites-execution-results/{suite}/mutations.xml")
                item["timeout_reports"] = [register(original.read(member)) for member in members]
            elif case["status"] == "NOT_EVALUABLE":
                item["timeout_reports"] = [suite_xml(tar, "run", key, rec, arm) for arm in rec["errors"]]
            else:
                raise ValueError(f"Unknown short-suite status for {key}")
            manifest["short_suites"].append(item)
    output = revision / "core_evidence.zip"
    with zipfile.ZipFile(output, "w", zipfile.ZIP_DEFLATED) as z:
        z.write(script, "__main__.py")
        z.write(script.with_name("round_sensitivity.py"), "round_sensitivity.py")
        z.writestr("README.txt", "Run: python core_evidence.zip (Python 3.9+, standard library).\n"
                   "Offline re-scoring of stored PIT reports for Sections 4.7 and 4.13.\n"
                   "No generation or Java execution. Upstream Java suites and original catalogs: "
                   "https://doi.org/10.5281/zenodo.21230015\n"
                   "manifest.json specifies fixed mutant IDs and XML file hashes. In each pair of "
                   "reports the order is generic/mutation (Codec) or zero-shot/few-shot (archive). "
                   "The outer order is caps 4 and 8 for the primary panels, or 4 and the recorded "
                   "common upper cap (5, 6 or 7) for short_suites. Excluded short suites include "
                   "their archived or replayed full-suite timeout XML. codec_response.txt is the saved second generic "
                   "continuation for form decoding. Its method positions and validation records "
                   "can be matched to the killing tests named by PIT.\n")
        z.writestr("codec_response.txt", raw_response)
        z.writestr("manifest.json", json.dumps(manifest, indent=2) + "\n")
        for digest, raw in sorted(reports.items()):
            z.writestr("pit/" + digest[:32] + ".xml", raw)
    print(output, len(reports), "distinct PIT reports")


def codec_attribution(z, manifest):
    provenance = manifest["codec_response"]
    raw = z.read("codec_response.txt")
    if sha(raw) != provenance["sha256"]:
        raise ValueError("Response checksum mismatch")
    # The seven methods in this fixed response each use a standalone @Test line.
    names = re.findall(r"(?m)^@Test[ \t]*\r?\npublic void (\w+)\(", raw.decode("utf-8"))
    positions = provenance["positions"]
    if [m["position"] for m in positions] != list(range(1, len(names) + 1)):
        raise ValueError("Saved method positions disagree with the response")
    by_test = {}
    for method, name in zip(positions, names):
        if method["status"] == "PASS":
            cls = method["class_name"]
            by_test[f"{cls}.{name}({cls})"] = (method["position"], name)
    catalog = set(manifest["catalogs"]["form_decode"])
    before, after = [z.read(f"pit/{arms[0][:32]}.xml") for arms in manifest["codec"]]
    earlier = {k for k, v in states(before).items() if v == "KILLED"}
    eligible_new = catalog - earlier
    counts = Counter()
    for node in ET.fromstring(after).findall("mutation"):
        if node.get("status") == "KILLED" and mutant_id(node) in eligible_new:
            counts[by_test[node.findtext("killingTest")]] += 1
    return [{"position": p, "method": name, "new_mutants_naming_this_test": n}
            for (p, name), n in sorted(counts.items())]


def ordering(a, b):
    if a * b < 0:
        return "strict_reversal"
    if a and not b:
        return "lead_to_tie"
    if b and not a:
        return "tie_to_lead"
    return "same_order"


def verify(path):
    with zipfile.ZipFile(path) as z:
        manifest = json.loads(z.read("manifest.json"))
        def report_states(digest):
            raw = z.read(f"pit/{digest[:32]}.xml")
            if sha(raw) != digest:
                raise ValueError("XML checksum mismatch")
            return states(raw)

        def score(reports, target):
            catalog = manifest["catalogs"][target]
            scores = []
            for arms in reports:
                counts = []
                for digest in arms:
                    observed = report_states(digest)
                    counts.append(sum(observed[k] == "KILLED" for k in catalog))
                scores.append(counts)
            return scores

        codec = score(manifest["codec"], "form_decode")
        attribution = codec_attribution(z, manifest)
        rows, changes, classes = [], Counter(), defaultdict(list)
        for r in manifest["pairs"]:
            target = r["target"]
            gaps = [left - right for left, right in score(r["reports"], target)]
            changes[ordering(*gaps)] += 1
            n = len(manifest["catalogs"][target])
            classes[target].append([Fraction(100*g, n) for g in gaps])
            rows.append(dict(pair=r["pair"], target=target, model=r["model"], n=n, prefix={"gaps": gaps}))
        short_caps, short_totals = defaultdict(Counter), Counter()
        short_ceiling = 0
        for case in manifest["short_suites"]:
            target, cap, status = case["target"], case["upper"], case["status"]
            fixed = manifest["catalogs"][target]
            short_caps[cap][status] += 1
            short_totals[status] += 1
            if status == "COMPARED":
                scores = score(case["reports"], target)
                event = ordering(*(left - right for left, right in scores))
                short_caps[cap][event] += 1
                short_totals[event] += 1
                short_ceiling += event == "lead_to_tie" and scores[1] == [len(fixed), len(fixed)]
            else:
                reports = [report_states(digest) for digest in case["timeout_reports"]]
                if not reports or not all(any(r[k] == "TIMED_OUT" for k in fixed) for r in reports):
                    raise ValueError(f"Missing fixed-catalog timeout evidence for {case['pair']}")
    class_means = [[statistics.mean(col) for col in zip(*group)] for group in classes.values()]
    rounds = summarize(rows)
    rounds.pop("observed_round_options_per_group")
    print(json.dumps({"codec_generic_vs_mutation_counts_at_4_and_8": codec,
                      "codec_generic_new_kills": attribution,
                      "codec_denominator": len(manifest["catalogs"]["form_decode"]),
                      "external_transitions": dict(strict_reversal=0) | dict(changes),
                      "short_suites": {"planned": len(manifest["short_suites"]),
                                       "counts": dict(strict_reversal=0) | dict(short_totals),
                                       "by_upper_cap": short_caps, "lead_to_tie_at_ceiling": short_ceiling},
                      "equal_class_mean_gap_pp": [float(statistics.mean(col)) for col in zip(*class_means)],
                      "one_round_per_class_model": rounds}, indent=2))


if __name__ == "__main__":
    if sys.argv[1:] == ["--pack"]:
        pack()
    else:
        verify(sys.argv[0])
