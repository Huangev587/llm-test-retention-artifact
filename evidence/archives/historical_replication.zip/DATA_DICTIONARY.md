# Data dictionary and interpretation

All JSON uses UTF-8. XML is the original PIT output. Durations are seconds. Missing/unavailable values are represented by explicit status/availability fields or null where originally recorded, not imputed as zero observations.

| Field or term | Meaning |
| --- | --- |
| `subject`, `number` | Historical HumanEval-Java numeric identifier. IDs 0–11, 19, 119 are included. |
| `phase` | Historical pilot, confirmation or revision batch; a batch name does not make the later replay independent. |
| `api`, `family` | Library task identifier and related behavior family (Hex, Base64, form URL). APIs in a family share a class-level mutation universe. |
| `generic`, `execution`, `mutation` | G, E and M response-source groups. All share an initial `seed` response and have two continuation slots each. |
| logical response slot | Planned response location; cached reuse consumes a slot without a new inference. |
| `index` | Zero-based original method position. Figures and prose describe positions starting at one. A failed position is never filled from a later one. |
| `source` | Saved generated method source, including the first cached signature for a shared body. It is not third-party production source. |
| `structure_pass` | Saved whole-response structure/guard outcome. A structure-rejected response contributes no selected methods. |
| `id` (method) | Body-token identity. Historical IDs include the function number and SHA256; API IDs hash API plus normalized body. Names, whitespace/comments are excluded; literals/token boundaries are retained. This is not semantic equivalence. |
| `PASS` | Recorded passage of both original and independent reference checks under the declared domain. It is not a proof of universal correctness or assertion strength. |
| `ORACLE_MISMATCH` | Historical reference expected-result disagreement. |
| `CONTRACT_UNKNOWN`, `REFERENCE_COMPILE_ERROR` | Historical uncertainty or reference compilation failure. Unresolved methods are separate from known invalid tests. |
| `OUT_OF_DOMAIN` | Input outside this study's declared comparison domain. It does not imply uselessness for all other test objectives. |
| `GUARD_REJECTED`, `COMPILE_FAILURE`, `ORIGINAL_FAILURE` | Library static, compilation or original-program failure. Original failure does not by itself identify the unique error cause. |
| `limit`, `positions_1/4/8` | Maximum eligible original position per response, followed by recorded validation and body deduplication. Historical `32` is the capped all-method rule. |
| `raw_slots` | Historical count control holding at most four candidate positions per parseable response; failures consume positions. |
| `valid_count`, `matched_prefix`, `matched_random_N` | Controls holding the number of jointly validated unique methods fixed. The prefix originates in the first-four selected set; random selection uses the complete valid pool. Test composition, including seed/continuation proportion, can change. |
| `k`, `matched_valid_count` | Minimum first-four valid count across G/E/M. `k=0` yields an uninformative empty comparison. |
| `repeat`, `N` | Fixed random draw index, 0–4. These are correlated draws on existing pools, not generation repetitions. |
| `retained_ids`, `ids` | Final selected unique method identities. Ordering in API plans may preserve first occurrence; suite hashes use sorted unique IDs. |
| `suite_hash` | SHA256 of JSON-encoded sorted unique method IDs; links comparisons to raw XML. |
| `feedback_ids`, `evaluation_ids` | Frozen mutant ID partitions grouped by class/method/descriptor/source line; mutation statuses are excluded from partition identity. |
| `INSUFFICIENT_DISTINCT_SITES` | Function 2 has only one mutation site and no site-based held-out comparison. |
| mutation `id` | Full JSON identity of class, method, descriptor, mutator and all instruction indexes. |
| `KILLED` | The only status counted as detected in this paper. Timeouts and coverage absence are not counted as kills. |
| `available` | Whether a held-out partition exists. Subject 0 has an additional contract exclusion even though it has a partition. |
| `evaluation_mutants`, `mutants` | Original denominator retained per task and partition; never replaced by an across-report intersection. |
| `attributed_*seconds` | One measured command/validation cost attributed from shared caches, not an independently rerun end-to-end speed measurement. |
| `provenance.json` | Maps packaged copies/projections to workspace-relative source paths and hashes. A path alone is not a release or a public access URL. |

The original aggregate JSONs retain historical administrative fields such as `next_owner` and `COMPLETE_VALUE_REVIEW_PENDING`. Those fields describe run output and are not the latest submission decision. The current paper proceeds to submission preparation.
