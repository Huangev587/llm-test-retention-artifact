# Local reproducibility package plan

Approved scope: the submission preparation described on 14 November and the user's continuation on 16 November 2026. This implements that existing scope in the current session.

Goal: provide a portable local artifact that checks selections and recomputes reported mutation scores without a GPU, model, Java, Maven, network connection, or the original workspace.

Design: retain the three original aggregate JSON results, generated responses and validation checkpoints, every PIT XML needed by those comparisons, and the figure source data. Reuse the frozen pure-Python selection, identity and partition routines. A standalone verifier checks a strict file manifest, reconstructs selections, and recomputes scores from XML. Supporting documents map claims to files and distinguish score recomputation from regenerating tests or revalidating correctness. The author's release licence and public access remain unset; third-party production source, source-containing prompts, model weights, environments and binary dependencies are excluded.

The local package is a review artifact, not an assertion that publication, third-party clearance or author licensing has occurred. All originals remain in place.

Implementation sequence:

- [x] Add verifier tests that reject changed evidence, unsafe paths, and incorrect scores; observe failure before implementation.
- [x] Export fixed result files, response/checkpoint records, partitions, raw XML and provenance into purpose-based directories.
- [x] Implement the dependency-free verifier and run it on actual data, including all five selection draws.
- [x] Document licensing findings, source mapping, data dictionary and accurate availability wording.
- [x] Verify a detached archive, including a semantic corruption check; remove temporary extraction and test files and update project navigation.

Completion: all 126 historical, 504 count-control and 162 API comparisons verify; packaged reports and source hashes are indexed; every supported figure record maps to verified results. Any omitted layer is explicitly described. This block does not launch an experiment or publish files.
