"""Durable call budgets and generation-facing prompt boundary."""
import hashlib
import json
import math
import os
from pathlib import Path
import re
import time

from protocol_boundary import feedback_payload

ARMS = ('generic', 'execution', 'mutation')
SLOTS = ('seed',) + tuple(f'{arm}_{i}' for arm in ARMS for i in (1, 2))


_JAVA_TOKENS = re.compile(
    r'(?P<space>\s+)|(?P<line>//[^\r\n]*)|(?P<block>/\*[\s\S]*?\*/)|'
    r'(?P<literal>"(?:\\[^\r\n]|[^"\\\r\n])*"|\'(?:\\[^\r\n]|[^\'\\\r\n])*\')|'
    r'(?P<identifier>(?:[^\W\d]|[$])[\w$]*)|'
    r'(?P<number>(?:0[xX][0-9a-fA-F_]+(?:\.[0-9a-fA-F_]*)?(?:[pP][+-]?[0-9_]+)?|'
    r'0[bB][01_]+|(?:[0-9][0-9_]*(?:\.[0-9_]*)?|\.[0-9][0-9_]*)(?:[eE][+-]?[0-9_]+)?)[fFdDlL]?)|'
    r'(?P<operator>>>>=|>>=|<<=|>>>|>>|<<|\.\.\.|::|->|\+\+|--|&&|\|\||'
    r'==|!=|<=|>=|[+*/%&|^!-]=)|(?P<other>.)'
)


def method_body_key(source):
    """Return Java body tokens, preserving literal spelling and token boundaries.

    This intentionally does not rename locals or otherwise infer semantic
    equivalence. Inputs are single methods already accepted by the Java guard.
    """
    if not isinstance(source, str) or not source:
        raise ValueError('Expected a complete method source')
    tokens = []
    for match in _JAVA_TOKENS.finditer(source):
        kind, token = match.lastgroup, match.group()
        if kind in ('space', 'line', 'block'):
            continue
        if kind == 'other' and token in ('"', "'"):
            raise ValueError('Unterminated Java literal')
        if token == '/' and source.startswith('/*', match.start()):
            raise ValueError('Unterminated Java comment')
        tokens.append(token)
    # An annotation may itself contain braces, but they occur inside its
    # argument parentheses. The method body opens at parenthesis depth zero.
    parentheses, start = 0, None
    for index, token in enumerate(tokens):
        if token == '(':
            parentheses += 1
        elif token == ')':
            parentheses -= 1
        elif token == '{' and parentheses == 0:
            start = index
            break
    if start is None:
        raise ValueError('Method body missing')
    depth = 0
    for index in range(start, len(tokens)):
        if tokens[index] == '{':
            depth += 1
        elif tokens[index] == '}':
            depth -= 1
            if depth == 0:
                if index != len(tokens) - 1:
                    raise ValueError('Expected a single method')
                return tuple(tokens[start + 1:index])
    raise ValueError('Unclosed method body')

