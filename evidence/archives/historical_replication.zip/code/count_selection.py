"""Selection rules that consume no mutation outcomes."""

from collections import Counter
import hashlib
import json
import random


ARMS = ('generic', 'execution', 'mutation')
REPEATS = 5
LIMIT = 4
SEED = 'selection-count-control-v1'


def rng(*parts):
    key = json.dumps([SEED, *parts], separators=(',', ':')).encode()
    return random.Random(int.from_bytes(hashlib.sha256(key).digest(), 'big'))


def draw_raw(entries, response_sha256, repeat):
    chosen = rng('raw', response_sha256, repeat).sample(range(len(entries)), min(LIMIT, len(entries)))
    return [entries[i] for i in sorted(chosen)]


def unique_pass(entries):
    return list(dict.fromkeys(m['id'] for m in entries if m['status'] == 'PASS'))


def matched_valid(prefix, pools, subject):
    k = min(len(prefix[arm]) for arm in ARMS)
    common = sorted({method for arm in ARMS for method in pools[arm]})
    orders = [rng('valid', subject, i).sample(common, len(common)) for i in range(REPEATS)]
    result = {}
    for arm in ARMS:
        pool = set(pools[arm])
        result[arm] = {
            'prefix': prefix[arm][:k],
            'random': [sorted([method for method in order if method in pool][:k]) for order in orders],
        }
    return {'k': k, 'arms': result}


def suite_hash(ids):
    if len(ids) != len(set(ids)):
        raise ValueError('Duplicate method identity in suite')
    return hashlib.sha256(json.dumps(sorted(ids)).encode()).hexdigest()


def plan_subject(subject, checkpoints, identities):
    full, prefix, rows, full_cost = {}, {}, [], {}
    for arm in ARMS:
        slots = ('seed', arm + '_1', arm + '_2')
        per_slot = {s: checkpoints[s]['methods'] for s in slots}
        all_entries = [m for s in slots for m in per_slot[s]]
        full[arm] = unique_pass(all_entries)
        charges = {m['id']: m['validation_seconds'] for m in all_entries if 'validation_seconds' in m}
        full_cost[arm] = {
            'raw_entries': len(all_entries), 'valid_unique': len(full[arm]),
            'historical_full_pool_validation_seconds': sum(charges.values()),
            'historical_extraction_seconds': sum(
                checkpoints[s]['extraction_seconds'] for s in {identities[s]: s for s in slots}.values()),
        }
        for repeat in [None, *range(REPEATS)]:
            selected = {s: per_slot[s][:LIMIT] if repeat is None
                        else draw_raw(per_slot[s], identities[s], repeat) for s in slots}
            entries = [m for s in slots for m in selected[s]]
            ids = unique_pass(entries)
            if repeat is None:
                prefix[arm] = ids
            rows.append(dict(arm=arm, comparison='raw_slots', rule='prefix' if repeat is None else 'random',
                             repeat=repeat, retained_ids=sorted(ids),
                             positions={s: [m['index'] for m in selected[s]] for s in slots},
                             structure_rejected_slots=[s for s in slots if not checkpoints[s]['structure_pass']],
                             selected_statuses=dict(Counter(m['status'] for m in entries)),
                             attributed_validation_seconds=sum({m['id']: m['validation_seconds'] for m in entries
                                                               if 'validation_seconds' in m}.values())))
    matched = matched_valid(prefix, full, subject)
    for arm, variants in matched['arms'].items():
        rows.append(dict(arm=arm, comparison='valid_count', rule='prefix', repeat=None,
                         retained_ids=sorted(variants['prefix'])))
        for repeat, ids in enumerate(variants['random']):
            rows.append(dict(arm=arm, comparison='valid_count', rule='random', repeat=repeat, retained_ids=ids))
    for row in rows:
        row['retained_methods'] = len(row['retained_ids'])
        row['suite_hash'] = suite_hash(row['retained_ids'])
    return {'subject': subject, 'matched_valid_count': matched['k'], 'full_pool_cost': full_cost, 'rows': rows}
