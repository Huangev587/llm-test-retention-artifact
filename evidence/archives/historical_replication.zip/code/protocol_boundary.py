"""Group mutations by source site before exposing any feedback.

This is an evaluation split, not a mutant-prioritization algorithm. Source code
is visible in every arm; only evaluation mutant metadata/outcomes are sealed.
"""
import hashlib
import json


FIELDS = ('id', 'mutated_class', 'method', 'descriptor', 'line', 'mutator', 'status')


def _sites(rows):
    seen, sites = set(), {}
    for row in rows:
        if not all(k in row for k in FIELDS):
            raise ValueError('Missing mutant metadata')
        if not isinstance(row['id'], str) or not row['id'] or row['id'] in seen:
            raise ValueError('Empty or duplicate mutant ID')
        if type(row['line']) is not int or row['line'] <= 0:
            raise ValueError('Cannot assign mutant to a source site')
        if any(not isinstance(row[k], str) or not row[k]
               for k in ('mutated_class', 'method', 'descriptor', 'mutator')):
            raise ValueError('Invalid source site or operator')
        seen.add(row['id'])
        key = (row['mutated_class'], row['method'], row['descriptor'], row['line'])
        sites.setdefault(key, []).append(row['id'])
    return sites


def _identity_digest(rows):
    # Status is deliberately excluded: it changes across generation rounds.
    values = sorted(tuple(r[k] for k in FIELDS if k != 'status') for r in rows)
    return hashlib.sha256(json.dumps(values, separators=(',', ':')).encode()).hexdigest()


def partition(rows, seed):
    sites = _sites(rows)
    if not isinstance(seed, str) or not seed:
        raise ValueError('Explicit predeclared seed required')
    base = dict(seed=seed, universe_sha256=_identity_digest(rows), sites=len(sites))
    if len(sites) < 2:
        return dict(base, status='INSUFFICIENT_DISTINCT_SITES',
                    feedback_ids=[], evaluation_ids=[])
    ranked = sorted(sites, key=lambda s: (
        hashlib.sha256(json.dumps([seed, s], separators=(',', ':')).encode()).hexdigest(), s))
    midpoint = len(ranked) // 2
    return dict(base, status='PARTITIONED',
                feedback_ids=sorted(i for s in ranked[:midpoint] for i in sites[s]),
                evaluation_ids=sorted(i for s in ranked[midpoint:] for i in sites[s]))


def feedback_payload(rows, split):
    expected = partition(rows, split['seed'])
    if split != expected:
        raise ValueError('Universe or frozen partition changed')
    visible = set(split['feedback_ids'])
    statuses = {'KILLED', 'SURVIVED', 'NO_COVERAGE', 'TIMED_OUT', 'NON_VIABLE',
                'MEMORY_ERROR', 'RUN_ERROR', 'NOT_STARTED', 'STARTED'}
    output = []
    for row in sorted(rows, key=lambda r: r['id']):
        if row['id'] in visible:
            if row['status'] not in statuses:
                raise ValueError('Unrecognized PIT status')
            output.append({k: row[k] for k in FIELDS})
    return output
