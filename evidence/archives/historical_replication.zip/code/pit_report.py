"""Strict PIT report decoding for the bounded Java pilot."""
import json
import xml.etree.ElementTree as ET


def parse_report(xml, target='original.HasCloseElements'):
    root = ET.fromstring(xml)
    if root.tag != 'mutations':
        raise ValueError('Unexpected PIT XML root')
    rows, seen = [], set()
    statuses = {'KILLED', 'SURVIVED', 'NO_COVERAGE', 'TIMED_OUT', 'NON_VIABLE',
                'MEMORY_ERROR', 'RUN_ERROR', 'NOT_STARTED', 'STARTED'}
    for node in root:
        if node.tag != 'mutation':
            raise ValueError('Unexpected PIT XML record')
        fields = [node.findtext(k) for k in
                  ('mutatedClass', 'mutatedMethod', 'methodDescription', 'mutator')]
        if any(not v or not v.strip() for v in fields) or fields[0] != target:
            raise ValueError('Missing identity or unexpected target class')
        indexes = [int(n.text) for n in node.findall('indexes/index')]
        if not indexes or min(indexes) < 0 or len(set(indexes)) != len(indexes):
            raise ValueError('Missing or invalid full PIT indexes')
        indexes.sort()
        try:
            line = int(node.findtext('lineNumber'))
        except (ValueError, TypeError) as exc:
            raise ValueError('Missing or invalid source line') from exc
        status = node.get('status')
        if line <= 0 or status not in statuses:
            raise ValueError('Invalid source line or unknown PIT status')
        identity = json.dumps(fields + [indexes], separators=(',', ':'))
        if identity in seen:
            raise ValueError('Duplicate full mutant identity')
        seen.add(identity)
        rows.append(dict(id=identity, mutated_class=fields[0], method=fields[1],
                         descriptor=fields[2], mutator=fields[3], indexes=indexes,
                         line=line, status=status))
    if not rows:
        raise ValueError('No target mutant identities')
    return sorted(rows, key=lambda r: r['id'])
