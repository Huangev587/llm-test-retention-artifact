# Output-selection study: local replication artifact

Version: `local-review-20261116`. Status: **local author-review artifact; not publicly deposited**.

This package supports *Output Selection Changes Comparisons of LLM-Generated Unit Tests: A Paired Replay Study*. It retains generated responses, recorded method validation states, fixed selections, original aggregate results, and raw PIT reports. It provides offline reconstruction of selections and mutation scores, including unchanged and failed cases. It does not rerun Java correctness checks or reproduce generation under different prompts or models.

## Quick start

Extract the package to a writable local directory. With Python 3.10 or later:

```text
python -I -S -B verify.py
```

No extra Python packages, model, GPU, Java, Maven, network access or AutoDL workspace are required. The command reads the package and prints a JSON report. Expected status is `VERIFIED_OFFLINE_SCORES_AND_SELECTIONS`, with 792 logical comparisons and 385 distinct saved XML reports. No test-generation or Java commands are executed. The verifier uses explicit errors and also works with Python optimization enabled.

The XML total consists of 83 historical replay reports, 237 additional count-control reports, 53 final library reports and 12 library generation-feedback reports. Count control also references 39 reports already included in the historical set; these are not duplicated. Five fixed draws describe selections within saved pools, not independent generation replications.

## Files and evidence coverage

| Files | Contents | Paper coverage |
| --- | --- | --- |
| `data/results/historical_replay.json` | Byte-identical historical results for all 14 functions and 126 comparisons | Sections 3.2–3.6, 4.1–4.5; Tables 1–4 |
| `data/historical/corpus.json` | All 98 logical response records, original response text, request/response hashes and source provenance metadata | Historical batch inventory and fixed-output provenance |
| `data/historical/subject_N/` | Validation checkpoints, generated method sources, original zero-based positions, partition and measured command records | Retention, method identity, position traces, failure states and cost attribution |
| `data/results/count_control.json`, `data/count_control/` | All 504 comparisons and measured command costs; all five draws retained | Sections 3.7, 4.6; Table 5 |
| `data/results/library_apis.json`, `data/library/` | Six APIs, checkpoints, all 42 logical call-result records, domains, partitions and 162 final comparisons | Sections 3.8, 4.7; Tables 6–7 |
| `raw/pit/` | Byte-identical PIT XML, indexed by suite hash and subject/API | Recalculation of mutation identities, partitions, kill sets and scores |
| `data/measurements/` | Run completion, costs, model-file metadata and saved signature-check receipt | Reported execution budgets and cache-signature limitation |
| `figures/` | Source data and SVG/PDF/PNG for all three numerical figures | Figures 1–3 |
| `code/` | Frozen pure-Python selection, method identity, XML parser and site-partition routines | Selection and score reconstruction; copied bytes indexed in `provenance.json` |
| `provenance.json`, `manifest.json` | Source paths/hashes, documented projections, package byte lengths and SHA256 | Traceability and integrity |
| `LICENSE_REVIEW.md`, `notices/` | Component-level observations, retained licence/notice texts and unresolved release conditions | Redistribution status; no blanket relicensing |
| `metadata.json`, `DATA_DICTIONARY.md` | Scope, missing release metadata and field definitions | Interpretation and future deposit |

Table numbers refer to the current English review draft. Algorithmic function 0 has no confirmed independent contract; function 2 has no site-based held-out partition. Both remain present, and neither is recoded as a zero-quality observation. Twelve other functions support the main historical held-out comparison. The six library APIs are nested in three behavior families and one project; their class-level mutation denominators include other overloads and the opposite direction.

## What is verified

The verifier checks every manifested file; rehashes historical response text and method-body identities; reconstructs the first-1/first-4/all selection and both historical count controls; reconstructs all API position and matched-count selections; and parses saved XML to recompute mutant identities, source-site partitions, status totals and `KILLED` identities. It checks all 144 plotted source rows against the verified results and checks reported call/cache and command costs.

Recorded original/reference validation states are inputs to this offline analysis. The package does not prove semantic correctness of the reference implementations, recompile the generated tests, rebuild feedback prompts, or independently reproduce timing. The saved API signature-check certificate records six successful compile checks for three raw variants. It documents the previous check; it is not six new compile runs by this verifier.

## Recreating numerical figures (optional)

Saved figures are included, so plotting is unnecessary for score verification. To render them again, use a **copy** of the extracted package with matplotlib 3.10.9 and numpy 2.5.4, the versions recorded in `data/measurements/figure_receipt.json`:

```text
python -B render_figures.py
```

The renderer is the manuscript's existing script with file paths adapted to this package. It overwrites figure exports/source data and adds its own figure receipt; keep the original artifact for checksum verification. Fonts and renderer versions can change pixel output. No software is installed automatically. The verification command itself remains standard-library-only.

## Sources, access and reuse

The historical program source is from MUTGEN commit `69dd37ddfab16b8c5efd22117dc3d213ab05418d`; Commons Codec is version 1.15, commit `c89d2af770f05457fbefa5fb4713c888bf177fb2`; generation used Qwen2.5-Coder-7B-Instruct, BF16 and greedy decoding. See [licensing observations](LICENSE_REVIEW.md) before preparing a public release.

This package excludes third-party production Java sources, source-containing full prompt files, model weights, dependency JARs, virtual environments and executable experiment launchers. These remain in their original locations where applicable. The selected method text is model-generated test output, not a permission grant for upstream production code. Original method names and cached signatures remain visible; no assertions have been repaired for this package.

Authors, institutional rights and a release licence have not yet been confirmed. No new open licence is assigned here. No public URL, DOI, data-deposit publisher or archive citation is claimed. The intended access route is a supplementary artifact or a versioned repository record after author review. An actual reviewer access identifier must be established before the availability wording is finalized.

## Local build provenance

The workspace exporter is `research/manuscripts/llm_selection/scripts/build_reproducibility.py`. It only reads existing research evidence and creates this local package. It preserves originals, omits command-line/path details from projected timing records, and records the hashes of the original timing files. The full experiment runs and deeper original validation logs remain in the research workspace. The portable artifact is deliberately smaller than that working archive.
