"""Render manuscript figures from the verified, fixed experiment outputs.

Figure contract: descriptive comparisons of fixed responses, not population
rankings. Figure 1 gives two concrete comparisons; Figure 2 shows every one of
five fixed matched-count draws for four cases; Figure 3 reports all six library
APIs. All are quantitative grids drawn only with Python/matplotlib, 183 mm wide,
with editable SVG text, embedded PDF fonts and a 300 dpi PNG preview. No error
bars, inferential tests or invented observations are added. The five draws are
selections from existing pools, not independent generation replicates.
"""

from __future__ import annotations

import hashlib
import importlib.metadata
import json
import os
from pathlib import Path
import sys

ROOT = Path(__file__).resolve().parent
REPO = ROOT
REVISION = ROOT
OUTPUT = ROOT / "figures"
PACKAGE_DIR = Path(os.environ.get("PAPER_PLOT_PACKAGES", "__no_extra_packages__"))
if PACKAGE_DIR.is_dir():
    sys.path.insert(0, str(PACKAGE_DIR))
# Matplotlib uses its configured/user cache; set MPLCONFIGDIR externally if needed.
sys.dont_write_bytecode = True

import matplotlib

matplotlib.use("Agg")
import matplotlib.pyplot as plt
from matplotlib.lines import Line2D
from matplotlib.patches import Patch
from matplotlib.ticker import MaxNLocator
import numpy as np

ARMS = ("generic", "execution", "mutation")
LETTERS = dict(zip(ARMS, ("G", "E", "M")))
COLORS = {"generic": "#3B6FA1", "execution": "#D28B45", "mutation": "#8064A2"}
HATCHES = {"generic": None, "execution": "//", "mutation": ".."}
API_ORDER = ("hex_encode", "hex_decode", "base64_encode", "base64_decode", "form_encode", "form_decode")
API_TITLES = {
    "hex_encode": "Hex encoding", "hex_decode": "Hex decoding",
    "base64_encode": "Base64 encoding", "base64_decode": "Base64 decoding",
    "form_encode": "Form URL encoding", "form_decode": "Form URL decoding",
}

plt.rcParams.update({
    "font.family": "sans-serif", "font.sans-serif": ["Arial", "DejaVu Sans"],
    "font.size": 8, "axes.titlesize": 8, "axes.labelsize": 8,
    "xtick.labelsize": 8, "ytick.labelsize": 7.5, "legend.fontsize": 8,
    "svg.fonttype": "none", "pdf.fonttype": 42, "ps.fonttype": 42,
    "axes.spines.top": False, "axes.spines.right": False,
    "axes.linewidth": 0.6, "xtick.major.width": 0.6, "ytick.major.width": 0.6,
    "legend.frameon": False, "figure.facecolor": "white", "axes.facecolor": "white",
    "hatch.linewidth": 0.45, "savefig.facecolor": "white",
})


def read(relative):
    names = {
        "selection_replay/evidence/result.json": "historical_replay",
        "selection_count_control/outputs/results.json": "count_control",
        "external_confirmation/outputs/run/results.json": "library_apis",
    }
    return json.loads((ROOT / "data/results" / (names[relative] + ".json")).read_text(encoding="utf-8"))


def load_data():
    replay_rel = "selection_replay/evidence/result.json"
    count_rel = "selection_count_control/outputs/results.json"
    api_rel = "external_confirmation/outputs/run/results.json"
    replay, counts, apis = read(replay_rel), read(count_rel), read(api_rel)
    assert apis["status"] == "COMPLETE_VALUE_REVIEW_PENDING"
    sources = {}
    for relative in (replay_rel, count_rel, api_rel):
        path = ROOT / "data/results" / ({replay_rel:"historical_replay", count_rel:"count_control", api_rel:"library_apis"}[relative] + ".json")
        sources["research/experiments/mutgen_budget_pilot_20261111/revision/" + relative] = hashlib.sha256(path.read_bytes()).hexdigest()

    old_cases = {}
    for subject, title in ((19, "SortNumbers"), (119, "MatchParens")):
        saved = next(s for s in replay["subjects"] if s["subject"] == subject)
        rows = []
        for arm in ARMS:
            for limit in (1, 4, 32):
                row = next(r for r in saved["evaluations"] if r["arm"] == arm and r["limit"] == limit)
                metric = row["metrics"]["evaluation"]
                assert metric["available"]
                rows.append(dict(arm=arm, limit=limit, killed=metric["killed"],
                                 denominator=metric["mutants"], valid_methods=row["retained_methods"]))
        old_cases[title] = dict(subject=subject, rows=rows)

    api_cases = {}
    for api in API_ORDER:
        saved = apis["apis"][api]
        rows = []
        for arm in ARMS:
            for limit in (1, 4, 8):
                row = next(r for r in saved["rows"] if r["arm"] == arm and r["rule"] == "positions_" + str(limit))
                rows.append(dict(arm=arm, limit=limit, killed=len(row["killed_ids"]),
                                 denominator=row["evaluation_mutants"], valid_methods=row["valid_methods"]))
        api_cases[api] = dict(family=saved["family"], matched_valid_count=saved["k"], rows=rows)

    matched = {}
    for title, case in old_cases.items():
        saved = next(s for s in counts["subjects"] if s["subject"] == case["subject"])
        rows = []
        for arm in ARMS:
            for row in saved["rows"]:
                if row["arm"] != arm or row["comparison"] != "valid_count":
                    continue
                metric = row["metrics"]["evaluation"]
                assert metric["available"] and row["retained_methods"] == saved["matched_valid_count"]
                rows.append(dict(arm=arm, rule=row["rule"], repeat=row["repeat"],
                                 killed=metric["killed"], denominator=metric["mutants"]))
        matched[title] = dict(k=saved["matched_valid_count"], rows=rows)
    for api in ("form_encode", "form_decode"):
        saved = apis["apis"][api]
        rows = []
        for arm in ARMS:
            for row in saved["rows"]:
                if row["arm"] != arm or not row["rule"].startswith("matched_"):
                    continue
                assert row["valid_methods"] == saved["k"]
                random = row["rule"].startswith("matched_random_")
                rows.append(dict(arm=arm, rule="random" if random else "prefix",
                                 repeat=int(row["rule"].rsplit("_", 1)[1]) if random else None,
                                 killed=len(row["killed_ids"]), denominator=row["evaluation_mutants"]))
        matched[API_TITLES[api]] = dict(k=saved["k"], rows=rows)
    for saved in matched.values():
        assert saved["k"] > 0
        for arm in ARMS:
            subset = [r for r in saved["rows"] if r["arm"] == arm]
            assert len(subset) == 6
            assert sorted(r["repeat"] for r in subset if r["rule"] == "random") == list(range(5))
            assert sum(r["rule"] == "prefix" for r in subset) == 1

    return dict(
        sources=sources,
        metric="Count of held-out mutants with status KILLED; denominator is retained per case.",
        statistical_scope="Descriptive fixed-response comparisons. Library APIs are paired within three families in one project. Five random draws are not independent generation replicates.",
        old_cases=old_cases, api_cases=api_cases, matched=matched,
    )


def decorate(ax):
    ax.set_axisbelow(True)
    ax.grid(axis="y", color="#E5E7EB", linewidth=0.5)
    ax.yaxis.set_major_locator(MaxNLocator(nbins=5, integer=True))
    ax.tick_params(axis="both", length=3, pad=3)


def bars(ax, case, title, limits, letter):
    labels = ["First 1", "First 4", "All (" + ("32 max" if limits[-1] == 32 else "8 max") + ")"]
    labels[-1] = "All (<=32)" if limits[-1] == 32 else "Up to 8"
    xpos = np.arange(len(limits), dtype=float)
    label_artists = []
    for offset, arm in zip((-0.24, 0, 0.24), ARMS):
        values = [next(r["killed"] for r in case["rows"] if r["arm"] == arm and r["limit"] == lim) for lim in limits]
        container = ax.bar(xpos + offset, values, width=0.22, color=COLORS[arm],
                           edgecolor="#FFFFFF", linewidth=0.35, hatch=HATCHES[arm], zorder=3)
        label_artists.extend(ax.bar_label(container, labels=[str(v) for v in values], padding=2,
                                          fontsize=7, color="#252525"))
    denominator = case["rows"][0]["denominator"]
    assert all(r["denominator"] == denominator for r in case["rows"])
    maximum = max(r["killed"] for r in case["rows"])
    ax.set_ylim(0, max(3, maximum + max(2, maximum * 0.2)))
    ax.set_xticks(xpos, labels)
    ax.set_title(title + " (" + str(denominator) + " held out)", pad=10)
    ax.set_ylabel("Mutants killed")
    ax.text(-0.17, 1.09, letter, transform=ax.transAxes, fontsize=9, fontweight="bold")
    decorate(ax)
    return label_artists


def arm_legend(fig, y):
    handles = [Patch(facecolor=COLORS[arm], edgecolor="white", hatch=HATCHES[arm],
                     label=LETTERS[arm] + "  " + dict(generic="Generic", execution="Execution feedback", mutation="Mutation feedback")[arm])
               for arm in ARMS]
    fig.legend(handles=handles, loc="upper center", bbox_to_anchor=(0.5, y), ncol=3,
               handlelength=1.6, columnspacing=2.0)


def verify_and_save(fig, name, label_artists, claim):
    fig.canvas.draw()
    renderer = fig.canvas.get_renderer()
    figure_box = fig.bbox
    outside = []
    for text in fig.findobj(match=lambda a: isinstance(a, matplotlib.text.Text)):
        if not text.get_visible() or not text.get_text():
            continue
        box = text.get_window_extent(renderer)
        # Ignore tick placeholders outside axes that matplotlib does not draw.
        if not text.get_clip_on() and (box.x0 < -1 or box.y0 < -1 or box.x1 > figure_box.x1 + 1 or box.y1 > figure_box.y1 + 1):
            outside.append(text.get_text())
    assert not outside, (name, "Text extends beyond canvas", outside)
    numeric_overlaps = []
    boxes = [(a.get_text(), a.get_window_extent(renderer)) for a in label_artists]
    for i, (left, a) in enumerate(boxes):
        for right, b in boxes[i + 1:]:
            if a.overlaps(b):
                numeric_overlaps.append([left, right])
    assert not numeric_overlaps, (name, "Numeric labels overlap", numeric_overlaps)
    files = {}
    for extension in ("png", "svg", "pdf"):
        destination = OUTPUT / (name + "." + extension)
        fig.savefig(destination, dpi=300, metadata={"Creator": "Python matplotlib"} if extension == "pdf" else None)
        files[destination.name] = dict(bytes=destination.stat().st_size,
                                       sha256=hashlib.sha256(destination.read_bytes()).hexdigest())
    svg = (OUTPUT / (name + ".svg")).read_text(encoding="utf-8")
    assert "<text" in svg, "SVG text was converted to outlines"
    result = dict(core_conclusion=claim, archetype="quantitative grid", backend="Python matplotlib",
                  size_mm=[round(v * 25.4, 2) for v in fig.get_size_inches()],
                  preview_dpi=300, editable_svg_text=True, pdf_fonttype=42,
                  out_of_canvas_text=outside, overlapping_numeric_labels=numeric_overlaps,
                  inferential_statistics="None; no error bars or significance markers", files=files)
    plt.close(fig)
    return result


def main():
    OUTPUT.mkdir(parents=True, exist_ok=True)
    data = load_data()
    (OUTPUT / "source_data.json").write_text(json.dumps(data, ensure_ascii=False, indent=2) + "\n", encoding="utf-8")
    quality = {}

    fig, axes = plt.subplots(1, 2, figsize=(183 / 25.4, 83 / 25.4))
    fig.subplots_adjust(left=0.08, right=0.985, bottom=0.19, top=0.76, wspace=0.29)
    all_labels = []
    all_labels += bars(axes[0], data["old_cases"]["SortNumbers"], "SortNumbers", (1, 4, 32), "a")
    all_labels += bars(axes[1], data["api_cases"]["form_decode"], "Form URL decoding", (1, 4, 8), "b")
    arm_legend(fig, 0.99)
    fig.text(0.5, 0.035, "Fixed saved responses; descriptive comparisons without error bars.", ha="center", fontsize=7.5)
    quality["fig1_comparisons"] = verify_and_save(fig, "fig1_comparisons", all_labels,
        "Changing retained output positions changes local comparisons between generation sources in two observed cases.")

    fig, axes = plt.subplots(2, 2, figsize=(183 / 25.4, 126 / 25.4))
    fig.subplots_adjust(left=0.08, right=0.985, bottom=0.13, top=0.85, wspace=0.29, hspace=0.66)
    for index, (title, saved) in enumerate(data["matched"].items()):
        ax = axes.flat[index]
        maximum = max(r["killed"] for r in saved["rows"])
        denom = saved["rows"][0]["denominator"]
        ax.set_title(title + " | k=" + str(saved["k"]) + ", " + str(denom) + " held out", pad=10)
        for center, arm in enumerate(ARMS):
            subset = [r for r in saved["rows"] if r["arm"] == arm]
            prefix = next(r["killed"] for r in subset if r["rule"] == "prefix")
            random = sorted((r for r in subset if r["rule"] == "random"), key=lambda r: r["repeat"])
            ax.scatter([center - 0.24], [prefix], marker="D", s=27, color="#252525", linewidths=0.4,
                       edgecolors="white", zorder=4)
            ax.scatter(center + np.array([-0.08, 0.00, 0.08, 0.16, 0.24]), [r["killed"] for r in random],
                       s=27, color=COLORS[arm], edgecolors="white", linewidths=0.4, zorder=4)
        ax.set_xlim(-0.53, 2.55)
        ax.set_ylim(0, maximum + max(1, maximum * 0.18))
        ax.set_xticks(range(3), [LETTERS[a] for a in ARMS])
        for label, arm in zip(ax.get_xticklabels(), ARMS):
            label.set_color(COLORS[arm])
            label.set_fontweight("bold")
        ax.set_ylabel("Mutants killed")
        ax.text(-0.17, 1.12, "abcd"[index], transform=ax.transAxes, fontsize=9, fontweight="bold")
        decorate(ax)
    handles = [Line2D([], [], marker="D", color="none", markerfacecolor="#252525", markeredgecolor="white", markersize=6, label="Position prefix"),
               Line2D([], [], marker="o", color="none", markerfacecolor="#777777", markeredgecolor="white", markersize=6, label="Random selection (five draws)")]
    fig.legend(handles=handles, loc="upper center", bbox_to_anchor=(0.5, 0.995), ncol=2,
               handlelength=1.0, columnspacing=3)
    fig.text(0.5, 0.025, "Each dot is one fixed selection draw, not an independent generation replicate.", ha="center", fontsize=7.5)
    quality["fig2_matched_count"] = verify_and_save(fig, "fig2_matched_count", [],
        "With the number of jointly validated methods fixed, detection still depends on composition in the displayed cases; all five draws are shown, including lower scores.")

    fig, axes = plt.subplots(3, 2, figsize=(183 / 25.4, 151 / 25.4))
    fig.subplots_adjust(left=0.08, right=0.985, bottom=0.115, top=0.875, wspace=0.29, hspace=0.73)
    all_labels = []
    for index, api in enumerate(API_ORDER):
        all_labels += bars(axes.flat[index], data["api_cases"][api], API_TITLES[api], (1, 4, 8), "abcdef"[index])
    arm_legend(fig, 0.995)
    fig.text(0.5, 0.025, "Paired APIs share class-level mutation universes: three behavior families in one project.", ha="center", fontsize=7.5)
    quality["fig3_api_scope"] = verify_and_save(fig, "fig3_api_scope", all_labels,
        "Selection sensitivity varies across all six declared library APIs; zero and unchanged results remain visible.")

    receipt = dict(status="FIGURES_RENDERED_AND_GEOMETRY_CHECKED", source_data_sha256=hashlib.sha256((OUTPUT / "source_data.json").read_bytes()).hexdigest(),
                   versions=dict(matplotlib=matplotlib.__version__, numpy=np.__version__),
                   figures=quality, figure_count=3, new_model_calls=0, new_parser_or_pit_runs=0)
    (OUTPUT / "verification.json").write_text(json.dumps(receipt, indent=2) + "\n", encoding="utf-8")
    print(json.dumps(dict(status=receipt["status"], figures=len(quality), source_files=len(data["sources"]))))


if __name__ == "__main__":
    main()
