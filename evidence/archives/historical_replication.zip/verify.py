"""Offline selection and score verification. Python 3.10+, standard library only.

No execution of generated Java, model loading, downloads or network access.
Validation outcomes are recorded observations, not revalidated here.
"""
from collections import Counter
import hashlib
import json
from pathlib import Path, PurePosixPath
import sys

sys.dont_write_bytecode = True
ROOT = Path(__file__).resolve().parent
sys.path.insert(0, str(ROOT / 'code'))
ARMS = ('generic', 'execution', 'mutation')
SLOTS = ('seed',) + tuple(a + '_' + str(i) for a in ARMS for i in (1, 2))


def require(condition, reason):
    if not condition:
        raise ValueError(reason)


def read(path):
    return json.loads(Path(path).read_text(encoding='utf-8'))


def check_manifest(root, manifest):
    root = Path(root).resolve()
    files = manifest['files']
    observed = {p.relative_to(root).as_posix() for p in root.rglob('*') if p.is_file()}
    require(observed - {'manifest.json'} == set(files), 'Missing or unlisted package file')
    for relative, expected in files.items():
        item = PurePosixPath(relative)
        require(not item.is_absolute() and '..' not in item.parts and '\\' not in relative
                and ':' not in relative, 'Unsafe manifest path')
        path = root.joinpath(*item.parts)
        require(path.resolve().is_relative_to(root) and not path.is_symlink(), 'Manifest path escape')
        require(not any(p.is_symlink() for p in path.parents if p != root.parent), 'Symlink in package path')
        data = path.read_bytes()
        require(len(data) == expected['bytes'] and hashlib.sha256(data).hexdigest() == expected['sha256'],
                'Checksum mismatch: ' + relative)
    return len(files)


def metrics(rows, split):
    values = {}
    for side in ('feedback', 'evaluation', 'all_mutants'):
        ids = {r['id'] for r in rows} if side == 'all_mutants' else set(split[side + '_ids'])
        selected = [r for r in rows if r['id'] in ids]
        require(len(selected) == len(ids), 'Missing mutation IDs')
        value = {'mutants': len(ids), 'killed': sum(r['status'] == 'KILLED' for r in selected),
                 'statuses': dict(Counter(r['status'] for r in selected))}
        if side != 'all_mutants':
            value['available'] = split['status'] == 'PARTITIONED'
        values[side] = value
    return values


def verify(root=ROOT):
    from pit_report import parse_report
    from protocol_boundary import partition
    from method_identity import method_body_key
    import count_selection as control
    import api_selection as api_control

    root = Path(root)
    manifest = read(root / 'manifest.json')
    file_count = check_manifest(root, manifest)
    index = read(root / 'data/report_index.json')
    historical = read(root / 'data/results/historical_replay.json')
    counts = read(root / 'data/results/count_control.json')
    apis = read(root / 'data/results/library_apis.json')
    corpus = read(root / 'data/historical/corpus.json')
    specifications = read(root / 'data/library/specifications.json')
    require(historical['status'] == counts['status'] == 'COMPLETE', 'Incomplete historical run')
    require(apis['status'] == 'COMPLETE_VALUE_REVIEW_PENDING', 'Incomplete API run')
    require(len(historical['subjects']) == len(counts['subjects']) == 14 and len(apis['apis']) == 6,
            'Unexpected study inventory')
    response_map = {}
    for response in corpus['responses']:
        require(hashlib.sha256(response['response'].encode()).hexdigest() == response['response_sha256'],
                'Raw response checksum mismatch')
        response_map.setdefault(response['subject'], {})[response['slot']] = response['response_sha256']
    require(len(corpus['responses']) == 98, 'Missing logical historical responses')
    reports = {}

    def xml(relative, target, split):
        if relative not in reports:
            rows = parse_report((root / relative).read_bytes(), target)
            require(partition(rows, split['seed']) == split, 'Mutation universe or site split changed')
            reports[relative] = rows
        return reports[relative]

    def method_check(methods, subject=None, api=None):
        for method in methods:
            if 'id' not in method:
                continue
            tokens = method_body_key(method['source'])
            if api is None:
                expected = 's' + str(subject) + '_' + hashlib.sha256(json.dumps(tokens).encode()).hexdigest()
            else:
                body = hashlib.sha256(json.dumps(tokens, separators=(',', ':')).encode()).hexdigest()
                expected = hashlib.sha256((api + body).encode()).hexdigest()[:32]
            require(method['id'] == expected, 'Method body identity changed')

    numbered = {s['number']: s for s in corpus['subjects']}
    checkpoints, splits = {}, {}
    comparison_count = 0
    old_unique, position_statuses = {}, {k: {} for k in (1, 4, 32)}
    for subject in historical['subjects']:
        number = subject['subject']
        prefix = root / 'data/historical' / ('subject_' + str(number))
        cp = read(prefix / 'responses.json')['checkpoints']
        split = read(prefix / 'partition.json')
        require(set(cp) == set(SLOTS) == set(response_map[number]), 'Missing historical checkpoints')
        checkpoints[number], splits[number] = cp, split
        target = 'original.' + numbered[number]['class_name']
        for checkpoint in cp.values():
            method_check(checkpoint['methods'], subject=number)
            require(checkpoint['structure_pass'] or not checkpoint['methods'], 'Rejected response retains methods')
            for method in checkpoint['methods']:
                if 'id' in method:
                    old_unique[(number, method['id'])] = method
                    for limit in (1, 4, 32):
                        if method['index'] < limit and 'validation_seconds' in method:
                            position_statuses[limit][(number, method['id'])] = method['status']
        commands = read(prefix / 'commands.json')
        require(all(c['seconds'] >= 0 for c in commands), 'Negative measured command cost')
        for row in subject['evaluations']:
            selected = [m for slot in ('seed', row['arm'] + '_1', row['arm'] + '_2')
                        for m in cp[slot]['methods'] if m['index'] < row['limit']]
            ids = sorted({m['id'] for m in selected if m['status'] == 'PASS'})
            require(row['retained_ids'] == ids and row['retained_methods'] == len(ids), 'Historical selection mismatch')
            require(row['suite_hash'] == control.suite_hash(ids), 'Historical suite hash mismatch')
            require(row['selected_statuses'] == dict(Counter(m['status'] for m in selected)), 'Rejection counts changed')
            seconds = sum({m['id']: m['validation_seconds'] for m in selected if 'validation_seconds' in m}.values())
            require(abs(seconds - row['attributed_method_validation_seconds']) < 1e-7, 'Validation cost mismatch')
            rows = xml(index['historical'][str(number)][row['suite_hash']], target, split)
            require(metrics(rows, split) == row['metrics'], 'Historical score mismatch')
            comparison_count += 1
    historical_xml = len(reports)
    require(historical_xml == sum(s['actual_pit_runs'] for s in historical['subjects']) == 83,
            'Historical XML inventory changed')
    for saved in counts['subjects']:
        number = saved['subject']
        plan = control.plan_subject(number, checkpoints[number], response_map[number])
        require(len(plan['rows']) == len(saved['rows']) == 36, 'Count-control row inventory')
        require(saved['matched_valid_count'] == plan['matched_valid_count']
                and saved['full_pool_cost'] == plan['full_pool_cost'], 'Matched count or pool costs changed')
        for expected, row in zip(plan['rows'], saved['rows']):
            require(all(row[k] == v for k, v in expected.items()), 'Count-control selection changed')
            rows = xml(index['count_control'][str(number)][row['suite_hash']],
                       'original.' + numbered[number]['class_name'], splits[number])
            require(metrics(rows, splits[number]) == row['metrics'], 'Count-control score mismatch')
            killed = sorted(r['id'] for r in rows if r['status'] == 'KILLED'
                            and r['id'] in splits[number]['evaluation_ids'])
            require(killed == row['evaluation_killed_ids'], 'Count-control killed IDs changed')
            comparison_count += 1
    count_new_xml = len(reports) - historical_xml
    require(count_new_xml == counts['planned_new_pit_runs'] == 237, 'New count-control report inventory')
    before_api = len(reports)
    api_statuses = Counter()
    api_calls = []
    for name, saved in apis['apis'].items():
        prefix = root / 'data/library' / name
        cp = read(prefix / 'checkpoints.json')
        split = read(prefix / 'partition.json')
        require(set(cp) == set(SLOTS), 'Missing API checkpoints')
        for slot in SLOTS:
            value = cp[slot]['validation']
            method_check(value['methods'], api=name)
            require(value['structure_pass'] or not value['methods'], 'Invalid API response retained methods')
            api_statuses.update(m['status'] for m in value['methods'])
            api_calls.append(read(prefix / 'calls' / (slot + '.json')))
        expected_rows, first, full = [], {}, {}
        for arm in ARMS:
            responses = [cp[s]['validation']['methods'] for s in ('seed', arm + '_1', arm + '_2')]
            for limit in (1, 4, 8):
                ids = api_control.prefix_ids(responses, limit)
                expected_rows.append({'arm': arm, 'rule': 'positions_' + str(limit), 'ids': ids})
                if limit == 4:
                    first[arm] = ids
                if limit == 8:
                    full[arm] = ids
        matched = api_control.matched(name, first, full)
        require(matched['k'] == saved['k'], 'API matched count changed')
        for arm in ARMS:
            expected_rows.append({'arm': arm, 'rule': 'matched_prefix', 'ids': matched['arms'][arm]['prefix']})
            for repeat, ids in enumerate(matched['arms'][arm]['random']):
                expected_rows.append({'arm': arm, 'rule': 'matched_random_' + str(repeat), 'ids': ids})
        require(len(expected_rows) == len(saved['rows']) == 27, 'API comparison inventory')
        for expected, row in zip(expected_rows, saved['rows']):
            require(all(row[k] == v for k, v in expected.items()), 'API selection changed')
            key = api_control.suite_hash(expected['ids'])
            require(key == row['suite_hash'] and row['valid_methods'] == len(expected['ids']), 'API suite identity changed')
            rows = xml(index['library'][name][key], specifications[name]['target'], split)
            selected = [r for r in rows if r['id'] in split['evaluation_ids']]
            require(row['evaluation_mutants'] == len(selected)
                    and row['statuses'] == dict(Counter(r['status'] for r in selected))
                    and row['killed_ids'] == sorted(r['id'] for r in selected if r['status'] == 'KILLED'),
                    'API score mismatch')
            comparison_count += 1
    api_final_xml = len(reports) - before_api
    require(api_final_xml == apis['actual_final_pit_runs'] == 53, 'API final report inventory')
    for item in index['feedback']:
        name = item['api']
        split = read(root / 'data/library' / name / 'partition.json')
        xml(item['xml'], specifications[name]['target'], split)
    require(len(reports) - before_api - api_final_xml == apis['generation_feedback_pit_runs'] == 12,
            'API feedback report inventory')
    costs = read(root / 'data/measurements/api_summary.json')
    commands = read(root / 'data/measurements/api_commands.json')
    require(len(commands) == costs['command_records'] == 395
            and abs(sum(c['seconds'] for c in commands) - costs['command_seconds']) < 1e-5, 'API command cost mismatch')
    require(dict(api_statuses) == costs['method_entries'] and len(api_calls) == costs['logical_calls'] == 42,
            'API entry/call counts changed')
    actual = [r for r in api_calls if r['status'] == 'RETURNED']
    cached = [r for r in api_calls if r['status'] != 'RETURNED']
    require(len(actual) == costs['actual_calls'] == 36 and len(cached) == costs['cache_hits'] == 6, 'Call/cache counts changed')
    require(abs(sum(c['seconds'] for c in actual) - costs['inference_seconds']) < 1e-6, 'Inference cost mismatch')
    signature = read(root / 'data/measurements/signature_check.json')
    require(signature['status'] == 'PASS' and signature['unique_variants'] == 3
            and all(c['compile_agrees_with_cached_status'] for c in signature['cases'].values()), 'Signature receipt changed')
    # Verify every figure source row against the already recomputed aggregate data.
    figure = read(root / 'figures/source_data.json')
    original_names = {'selection_replay/evidence/result.json': 'historical_replay',
                      'selection_count_control/outputs/results.json': 'count_control',
                      'external_confirmation/outputs/run/results.json': 'library_apis'}
    for original, digest in figure['sources'].items():
        suffix = original.split('/revision/', 1)[1]
        raw = (root / 'data/results' / (original_names[suffix] + '.json')).read_bytes()
        require(hashlib.sha256(raw).hexdigest() == digest, 'Figure input hash mismatch')
    verified_figure_rows = 0
    for name, case in figure['old_cases'].items():
        saved = next(s for s in historical['subjects'] if s['subject'] == case['subject'])
        for row in case['rows']:
            result = next(r for r in saved['evaluations'] if r['arm'] == row['arm'] and r['limit'] == row['limit'])
            require(row['killed'] == result['metrics']['evaluation']['killed']
                    and row['denominator'] == result['metrics']['evaluation']['mutants']
                    and row['valid_methods'] == result['retained_methods'], 'Historical figure row changed')
            verified_figure_rows += 1
    for name, case in figure['api_cases'].items():
        saved = apis['apis'][name]
        for row in case['rows']:
            result = next(r for r in saved['rows'] if r['arm'] == row['arm'] and r['rule'] == 'positions_' + str(row['limit']))
            require(row['killed'] == len(result['killed_ids']) and row['denominator'] == result['evaluation_mutants']
                    and row['valid_methods'] == result['valid_methods'], 'API figure row changed')
            verified_figure_rows += 1
    lookup = {'Form URL encoding': 'form_encode', 'Form URL decoding': 'form_decode'}
    for name, case in figure['matched'].items():
        for row in case['rows']:
            if name in figure['old_cases']:
                number = figure['old_cases'][name]['subject']
                saved = next(s for s in counts['subjects'] if s['subject'] == number)
                result = next(r for r in saved['rows'] if r['comparison'] == 'valid_count'
                              and all(r[k] == row[k] for k in ('arm', 'rule', 'repeat')))
                killed, denominator, k = len(result['evaluation_killed_ids']), result['metrics']['evaluation']['mutants'], saved['matched_valid_count']
            else:
                saved = apis['apis'][lookup[name]]
                rule = 'matched_prefix' if row['rule'] == 'prefix' else 'matched_random_' + str(row['repeat'])
                result = next(r for r in saved['rows'] if r['arm'] == row['arm'] and r['rule'] == rule)
                killed, denominator, k = len(result['killed_ids']), result['evaluation_mutants'], saved['k']
            require(case['k'] == k and row['killed'] == killed and row['denominator'] == denominator, 'Matched figure row changed')
            verified_figure_rows += 1
    require(comparison_count == 792, 'Missing logical comparisons')
    eligible = [s for s in historical['subjects'] if s['subject'] not in (0, 2)]
    gains = {}
    for low, high in ((1, 4), (4, 32)):
        changed = []
        for s in eligible:
            grid = {(r['arm'], r['limit']): r['metrics']['evaluation']['killed'] for r in s['evaluations']}
            if any(grid[a, high] > grid[a, low] for a in ARMS):
                changed.append(s['subject'])
        gains[str(low) + '_to_' + str(high)] = changed
    summary = {'status': 'VERIFIED_OFFLINE_SCORES_AND_SELECTIONS', 'manifest_files': file_count,
               'historical_functions': 14, 'eligible_historical_functions': 12, 'logical_comparisons': comparison_count,
               'historical_xml': historical_xml, 'additional_count_control_xml': count_new_xml,
               'api_final_xml': api_final_xml, 'api_feedback_xml': 12, 'raw_xml_reports': len(reports),
               'figure_rows_checked': verified_figure_rows, 'historical_gain_subjects': gains,
               'historical_method_statuses_by_limit': {str(k): dict(Counter(v.values())) for k, v in position_statuses.items()},
               'new_inference_calls': 0, 'new_java_or_pit_runs': 0,
               'scope': 'Recorded validation states, method identities, selections and saved XML; no correctness rerun or generation reproduction.'}
    return summary


if __name__ == '__main__':
    print(json.dumps(verify(), indent=2))
